<?php
namespace AweBooking\Simple_Reservation;

use AweBooking\Support\Service_Provider as Base_Service_Provider;

class Service_Provider extends Base_Service_Provider {
	/**
	 * Registers services on the awebooking.
	 *
	 * @return void
	 */
	public function register() {
		new Simple_Reservation_CF7;
		load_plugin_textdomain( 'awebooking-simple-reservation', false, basename( dirname( __DIR__ ) ) . '/languages' );
	}

	/**
	 * Init the addon.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'abrs_register_admin_settings', function ( $settings ) {
			$settings->register( $this->plugin->make( Simple_Reservation_Setting::class ) );
		});

		if ( 'on' === abrs_get_option( 'enable_simple_reservation', 'off' ) && abrs_get_option( 'simple_reservation_shortcode' ) ) {
			remove_action( 'abrs_single_room_sidebar', 'abrs_single_room_form' );
			add_action( 'abrs_single_room_sidebar', [ $this, 'add_template_shortcode' ] );
		}
	}

	/**
	 * Add template shortcode.
	 */
	public function add_template_shortcode() {
		echo do_shortcode( abrs_get_option( 'simple_reservation_shortcode' ) );
	}
}
