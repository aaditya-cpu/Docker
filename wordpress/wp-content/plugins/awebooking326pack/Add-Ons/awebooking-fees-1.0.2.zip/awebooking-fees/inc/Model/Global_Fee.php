<?php
namespace AweBooking\Fees\Model;

use AweBooking\Component\Ruler\Context;
use AweBooking\Model\Model;
use AweBooking\Reservation\Reservation;
use AweBooking\Support\Carbonate;

class Global_Fee extends Model {
	/**
	 * This is the name of this object type.
	 *
	 * @var string
	 */
	protected $object_type = 'hotel_fee';

	public function passed( Reservation $reservation ) {
		if ( ! function_exists( 'abrs_parse_rules' ) || ! $this->get( 'conditions' ) ) {
			return true;
		}

		if ( ! $res_request = $reservation->get_previous_request() ) {
			return true;
		}

		if ( ! $rule = abrs_parse_rules( $this->get( 'conditions' ) ) ) {
			return true;
		}

		return $rule->apply( $this->get_context( $reservation ) );
	}

	protected function get_context( Reservation $reservation ) {
		if ( function_exists( 'abrs_create_rules_context' ) ) {
			return abrs_create_rules_context( $reservation );
		}

		$res_request = $reservation->resolve_res_request();

		$today      = abrs_date( 'today' );
		$start_date = abrs_date( $res_request->get_timespan()->get_start_date() );
		$end_date   = abrs_date( $res_request->get_timespan()->get_end_date() );

		return new Context( [
			'booking_date'   => $today,
			'check_in_date'  => $start_date,
			'check_out_date' => $end_date,
			'booking_before' => $today->diffInDays( $start_date ),
			'check_in'       => $start_date->dayOfWeek,
			'check_out'      => $end_date->dayOfWeek,
			'stay_nights'    => $res_request->get( 'nights' ),
		] );
	}

	/**
	 * {@inheritdoc}
	 */
	protected function setup() {
		$this->set_attribute( 'name', $this->instance->post_title );
		$this->set_attribute( 'status', $this->instance->post_status );
		$this->set_attribute( 'date_created', $this->instance->post_date );
		$this->set_attribute( 'date_modified', $this->instance->post_modified );

		do_action( $this->prefix( 'after_setup' ), $this );
	}

	/**
	 * {@inheritdoc}
	 */
	protected function perform_insert() {
		$insert_id = wp_insert_post([
			'post_type'   => $this->object_type,
			'post_title'  => $this->get( 'name' ),
			'post_status' => $this->get( 'status' ) ?: 'publish',
			'post_date'   => $this->get( 'date_created' ) ?: current_time( 'mysql' ),
		], true );

		if ( ! is_wp_error( $insert_id ) ) {
			return $insert_id;
		}

		return 0;
	}

	/**
	 * {@inheritdoc}
	 */
	protected function perform_update( array $dirty ) {
		if ( $this->get_changes_only( $dirty, [ 'name', 'status', 'date_created' ] ) ) {
			$this->update_the_post([
				'post_title'    => $this->get( 'name' ),
				'post_status'   => $this->get( 'status' ),
				'post_date'     => $this->get( 'date_created' ),
			]);
		}
	}

	/**
	 * {@inheritdoc}
	 */
	protected function setup_attributes() {
		$this->attributes = apply_filters( $this->prefix( 'attributes' ), [
			'name'          => '',
			'amount'        => 0,
			'taxable'       => false,
			'tax_rate'      => 0,
			'conditions'    => null,
			'status'        => '',
			'date_created'  => null,
			'date_modified' => null,
		]);
	}

	/**
	 * {@inheritdoc}
	 */
	protected function map_attributes() {
		$this->maps = apply_filters( $this->prefix( 'map_attributes' ), [
			'amount'     => '_fee_amount',
			'taxable'    => '_fee_taxable',
			'tax_rate'   => '_fee_tax_rate',
			'conditions' => '_fee_conditions',
		]);
	}
}
