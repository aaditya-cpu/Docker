<?php
namespace AweBooking\Payment;

use AweBooking\Payment\Controllers\Payment_Controller;
use AweBooking\Support\Service_Provider as AweBooking_Service_Provider;

class Service_Provider extends AweBooking_Service_Provider {
	/**
	 * The gateways.
	 *
	 * @var array
	 */
	protected $gateways = [
		\AweBooking\Payment\Gateways\PayPal_Gateway::class,
		\AweBooking\Payment\Gateways\PayPal_Pro_Gateway::class,
		\AweBooking\Payment\Gateways\Stripe_Gateway::class,
		\AweBooking\Payment\Gateways\Unofficial\Paystack_Gateway::class,
		\AweBooking\Payment\Gateways\Unofficial\PayU_Gateway::class,
		\AweBooking\Payment\Gateways\Unofficial\PayU_Latam_Gateway::class,
		\AweBooking\Payment\Gateways\Unofficial\PayU_India_Gateway::class,
	];

	/**
	 * Registers services on the plugin.
	 *
	 * @return void
	 */
	public function register() {
		load_plugin_textdomain( 'awebooking-payment', false, basename( dirname( __DIR__ ) ) . '/languages' );

		$this->register_gateways( $this->gateways );
	}

	/**
	 * Register the gateway.
	 *
	 * @param array|string $gateways The gateways.
	 */
	protected function register_gateways( $gateways ) {
		$gateways = (array) $gateways;

		foreach ( $gateways as $gateway ) {
			$this->plugin->singleton( $gateway );
		}

		$this->plugin->tag( $gateways, 'gateways' );
	}

	/**
	 * Init service provider.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'abrs_register_routes', function ( $route ) {
			/* @var  \FastRoute\RouteCollector $route The route collector.*/
			$route->addRoute( [ 'POST', 'GET' ], '/payment/cancel/{booking:\d+}', Payment_Controller::class . '@cancel' );
			$route->addRoute( [ 'POST', 'GET' ], '/payment/complete/{gateway}/{booking:\d+}', Payment_Controller::class . '@complete' );
			$route->addRoute( [ 'POST', 'GET' ], '/payment/notify/{gateway}/{booking:\d+}', Payment_Controller::class . '@notify' );
		} );

		add_action( 'wp_enqueue_scripts', function () {
			if ( ! abrs_is_checkout_page() ) {
				return;
			}

			$assets = trailingslashit( ABRS_PAYMENT_PLUGIN_URL ) . 'assets/';
			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

			wp_enqueue_style( 'card', $assets . 'vendor/card/card.css', [], '2.4.0' );
			wp_register_script( 'card', $assets . 'vendor/card/card.js', [], '2.4.0', true );

			wp_enqueue_style( 'awebooking-payment', $assets . 'css/payment' . $suffix . '.css', [ 'awebooking', 'card' ], ABRS_PAYMENT_VERSION );
			wp_enqueue_script( 'awebooking-payment', $assets . 'js/payment' . $suffix . '.js', [ 'awebooking-checkout', 'card' ], ABRS_PAYMENT_VERSION, true );

			wp_register_script( 'awebooking-payment-stripe', $assets . 'js/stripe-gateway' . $suffix . '.js', [ 'awebooking-payment' ], ABRS_PAYMENT_VERSION, true );
		});
	}
}
