<?php
namespace AweBooking\Payment\Gateways\Traits;

use Awethemes\Http\Request;
use Omnipay\Common\CreditCard as Card;

trait CreditCard {
	/**
	 * Gets the card.
	 *
	 * @param \Awethemes\Http\Request $request The request instance.
	 * @return \Omnipay\Common\CreditCard
	 *
	 * @throws \InvalidArgumentException
	 */
	protected function get_card( Request $request ) {
		$data_name = "creditcard.{$this->method}";

		if ( ! $request->filled( $data_name ) ) {
			throw new \InvalidArgumentException( esc_html__( 'The credit card is required', 'awebooking-payment' ) );
		}

		if ( $request->filled( "{$data_name}.expiry" ) ) {
			$expiry = explode( '/', $request->input( "{$data_name}.expiry" ) );
		} else {
			$expiry = [ $request->input( "{$data_name}.expiry_month" ), $request->input( "{$data_name}.expiry_year" ) ];
		}

		return new Card( [
			'name'        => $request->input( "{$data_name}.name" ),
			'number'      => $request->input( "{$data_name}.number" ),
			'expiryMonth' => isset( $expiry[0] ) ? $expiry[0] : null,
			'expiryYear'  => isset( $expiry[1] ) ? $expiry[1] : null,
			'cvv'         => $request->input( "{$data_name}.cvc" ),
		] );
	}

	/**
	 * Showing the credit-card form.
	 *
	 * @return void
	 */
	protected function show_card_form() {
		$id_prefix   = 'creditcard_' . $this->method . '_';
		$name_prefix = 'creditcard[' . $this->method . ']';

		?>
		<div class="credit-card credit-card--visual">
		<div class="credit-card__display"></div>

		<div class="columns no-gutters">
			<div class="column-12">
				<label for="<?php echo esc_attr( $id_prefix . 'number' ); ?>"><?php esc_html_e( 'Card number', 'awebooking-payment' ); ?></label>
				<input type="text" class="form-input credit-card__number" id="<?php echo esc_attr( $id_prefix . 'number' ); ?>" name="<?php echo esc_attr( $name_prefix ); ?>[number]" autocomplete="cc-number"">
			</div>

			<div class="column-6">
				<label for="<?php echo esc_attr( $id_prefix . 'expiry' ); ?>"><?php esc_html_e( 'Expiry date', 'awebooking-payment' ); ?></label>
				<input type="text" class="form-input credit-card__expiry" id="<?php echo esc_attr( $id_prefix . 'expiry' ); ?>" name="<?php echo esc_attr( $name_prefix ); ?>[expiry]" autocomplete="cc-exp" placeholder="MM/YY">
			</div>

			<div class="column-6">
				<label for="<?php echo esc_attr( $id_prefix . 'cvc' ); ?>"><?php esc_html_e( 'Secure code', 'awebooking-payment' ); ?></label>
				<input type="text" class="form-input credit-card__cvc" id="<?php echo esc_attr( $id_prefix . 'cvc' ); ?>" name="<?php echo esc_attr( $name_prefix ); ?>[cvc]" autocomplete="cc-csc">
			</div>

			<div class="column-12">
				<label for="<?php echo esc_attr( $id_prefix . 'name' ); ?>"><?php esc_html_e( 'Name on card', 'awebooking-payment' ); ?></label>
				<input type="text" class="form-input credit-card__name" id="<?php echo esc_attr( $id_prefix . 'name' ); ?>" name="<?php echo esc_attr( $name_prefix ); ?>[name]" autocomplete="cc-name">
			</div>
		</div>
		</div><?php // @codingStandardsIgnoreLine
	}
}
