<?php

namespace AweBooking\WooCommerce;

use AweBooking\Model\Booking;
use AweBooking\Checkout\Url_Generator;
use AweBooking\Model\Booking\Payment_Item;
use AweBooking\Support\Service_Provider as AweBooking_Service_Provider;
use AweBooking\Component\Http\Exceptions\ValidationFailedException;

class Service_Provider extends AweBooking_Service_Provider {
	/**
	 * Registers services on the awebooking.
	 *
	 * @return void
	 */
	public function register() {
		load_plugin_textdomain( 'awebooking-woocommerce', false, basename( dirname( __DIR__ ) ) . '/languages' );
	}

	/**
	 * Init the addon.
	 */
	public function init() {
		if ( ! defined( 'WC_PLUGIN_FILE' ) ) {
			return;
		}

		add_filter( 'woocommerce_product_class', [ $this, 'register_product_class' ], 10, 4 );
		add_action( 'abrs_register_admin_settings', [ $this, 'admin_settings_fields' ] );

		remove_action( 'abrs_html_checkout_payments', 'abrs_checkout_payments', 10 );
		add_action( 'abrs_html_checkout_payments', [ $this, 'add_woocommerce_payment_template' ] );
		add_filter( 'abrs_checkout_show_terms', [ $this, 'remove_awebooking_terms' ] );
		add_filter( 'woocommerce_checkout_fields', [ $this, 'remove_required_fields' ] );

		$replace_options = [
			'currency'                 => get_woocommerce_currency(),
			'price_number_decimals'    => wc_get_price_decimals(),
			'price_decimal_separator'  => wc_get_price_decimal_separator(),
			'price_thousand_separator' => wc_get_price_thousand_separator(),
		];

		foreach ( $replace_options as $option => $value ) {
			add_filter( "abrs_pre_option_{$option}", function () use ( $value ) {
				return $value;
			}, 20 );
		}

		add_filter( 'abrs_format_price_args', [ $this, 'abrs_format_price_args' ] );

		add_action( 'wp', [ $this, 'add_awebooking_reservation' ] );
		add_action( 'woocommerce_before_checkout_process', [ $this, 'process_awebooking_reservation' ] );
		add_action( 'woocommerce_checkout_order_processed', [ $this, 'woocommerce_checkout_order_processed' ], 10, 3 );
		add_filter( 'woocommerce_checkout_no_payment_needed_redirect', [ $this, 'woocommerce_checkout_no_payment_needed_redirect' ], 10, 2 );
		add_filter( 'woocommerce_get_return_url', [ $this, 'woocommerce_get_return_url' ], 10, 2 );
		add_action( 'woocommerce_order_status_changed', [ $this, 'update_awebooking_status' ], 10, 3 );
		add_filter( 'abrs_base_payment_methods', [ $this, 'add_woocommerce_payment_method' ] );
		add_action( 'abrs_display_payment_woocommerce', [ $this, 'add_woocommerce_payment_link' ], 10, 2 );
		add_action( 'awebooking_thankyou', [ $this, 'add_woocommerce_thankyou_actions' ], 10 );
		add_filter( 'woocommerce_is_checkout', [ $this, 'woocommerce_is_checkout' ] );

		$this->disable_woocommerce_mails();
	}

	/**
	 * Register product booking class.
	 *
	 * @param  string $classname    Class name.
	 * @param  string $product_type The product type.
	 * @param  string $var          The variation product type product variation product.
	 * @param  int    $product_id   The product id.
	 *
	 * @return string
	 */
	public function register_product_class( $classname, $product_type, $var, $product_id ) {
		if ( 'room_type' === get_post_type( $product_id ) ) {
			$classname = Product_Booking_Room::class;
		}

		return $classname;
	}

	/**
	 * Hook abrs_format_price_args.
	 *
	 * @param array $args Agrs.
	 *
	 * @return array
	 */
	public function abrs_format_price_args( $args ) {
		$args['price_format'] = get_woocommerce_price_format();

		return $args;
	}

	/**
	 * Modify admin setting fields has been conflict.
	 *
	 * @param  object $admin_settings Admin settings instance.
	 *
	 * @return void
	 */
	public function admin_settings_fields( $admin_settings ) {
		$general_conflicts = [
			'currency',
			'currency_position',
			'price_thousand_separator',
			'price_decimal_separator',
			'price_number_decimals',
		];

		$admin_settings
			->get( 'general' )
			->get_field( '__title_currency' )
			->set_prop( 'description', abrs_esc_text( __( 'You are activating <strong>AweBooking WooCommerce</strong> plugin. You can set currency settings on <a href="admin.php?page=wc-settings#pricing_options-description">WooCommerce Checkout</a>.', 'awebooking-woocommerce' ) ) );

		foreach ( $general_conflicts as $key ) {
			$admin_settings
				->get( 'general' )
				->get_field( $key )
				->set_attribute( 'disabled', true );
		}

		$admin_settings
			->get( 'checkout' )
			->get_field( '__payments_title' )
			->set_prop( 'description', abrs_esc_text( __( 'You are activating <strong>AweBooking WooCommerce</strong> plugin. You can find more payment gateways on <a href="admin.php?page=wc-settings&tab=checkout">WooCommerce Checkout</a>.', 'awebooking-woocommerce' ) ) );

		$admin_settings
			->get( 'checkout' )
			->get_field( 'list_gateway_order' )
			->set_prop( 'render_row_cb', '__return_empty_string' );
	}

	/**
	 * Add WooCommerce payment.
	 */
	public function add_woocommerce_payment_template() {
		if ( ! defined( 'WOOCOMMERCE_CHECKOUT' ) ) {
			define( 'WOOCOMMERCE_CHECKOUT', true );
		}

		?>
		<div class="woocommerce">
			<div class="checkout woocommerce-checkout">
				<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

				<div id="order_review" class="woocommerce-checkout-review-order">
					<?php do_action( 'woocommerce_checkout_order_review' ); ?>
				</div>

				<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

				<input type="hidden" name="awebooking-checkout" value="1">
			</div>
		</div>
		<?php
	}

	/**
	 * Remove terms page ID.
	 *
	 * @param int $terms_page_id The page ID of terms.
	 *
	 * @return bool
	 */
	public function remove_awebooking_terms( $terms_page_id ) {
		return false;
	}

	/**
	 * Returns required fields.
	 *
	 * @param array $fields Fields.
	 *
	 * @return array
	 */
	public function remove_required_fields( $fields ) {
		if ( abrs_is_checkout_page() || ! empty( $_REQUEST['awebooking-checkout'] ) ) {
			$fields = [];
		}

		return $fields;
	}

	/**
	 * Add virtual product to AweBooking checkout page.
	 */
	public function add_awebooking_reservation() {
		$in_checkout = false;

		if ( abrs_is_checkout_page() ) {
			$in_checkout = true;
			abrs_session()->put( 'awebooking-inprocess-checkout', true );
		}

		if ( $in_checkout || ( isset( $_REQUEST['wc-ajax'] ) && $this->is_in_checkout() ) ) {
			$this->add_virtual_product();
		}
	}

	protected function is_in_checkout() {
		if ( abrs_is_checkout_page() ) {
			return true;
		}

		return abrs_session()->has( 'awebooking-inprocess-checkout' );
	}

	/**
	 * Before checkout process.
	 *
	 * @throws \Exception
	 */
	public function process_awebooking_reservation() {
		$request = abrs_http_request();

		if ( ! $request->has( 'awebooking-checkout' ) ) {
			return;
		}

		add_filter( 'abrs_booking_status_without_payment', function () {
			return 'pending';
		} );

		// Process awebooking.
		$request['payment_method'] = null; // Skip AweBooking payment method.

		try {
			$response = abrs_checkout()->process( $request );
		} catch ( ValidationFailedException $e ) {
			/* @var $errors \WP_Error */
			$errors = $e->get_errors();
			throw new \RuntimeException( $errors->get_error_message() );
		}

		$response_data = $response->get_data();

		if ( ! $response_data instanceof Booking ) {
			return;
		}

		$booking_id = $response_data->get_id();

		// Set the booking ID in the session.
		if ( $booking_id ) {
			abrs_session()->put( 'awebooking-booking', $booking_id );
			$this->add_virtual_product();
		}
	}

	/**
	 * Woocommerce checkout order processed.
	 *
	 * @param int       $order_id    Order ID.
	 * @param array     $posted_data Posted data.
	 * @param \WC_Order $order       The order.
	 */
	public function woocommerce_checkout_order_processed( $order_id, $posted_data, $order ) {
		$booking_id = abrs_session()->pull( 'awebooking-booking' );

		if ( ! $booking_id ) {
			return;
		}

		// Add woocommerce reference to booking.
		$booking = abrs_get_booking( $booking_id );
		$booking->add_meta( '_woocommerce_reference', $order_id );

		// Add awebooking reference to order.
		$order->add_meta_data( '_awebooking_reference', $booking_id );
		$this->update_order_meta_data( $order, $booking );
		$order->save();

		$this->create_new_payment( $booking, $order->get_total() );

		$this->purge_session_sign();
	}

	/**
	 * Update order metadata.
	 *
	 * @param \WC_Order $order   The Order.
	 * @param Booking   $booking The Booking.
	 */
	public function update_order_meta_data( $order, $booking ) {
		$data = [
			'billing_first_name' => 'customer_first_name',
			'billing_last_name'  => 'customer_last_name',
			'billing_company'    => 'customer_company',
			'billing_address_1'  => 'customer_address',
			'billing_address_2'  => 'customer_address_2',
			'billing_city'       => 'customer_city',
			'billing_state'      => 'customer_state',
			'billing_postcode'   => 'customer_postal_code',
			'billing_country'    => 'customer_country',
			'billing_email'      => 'customer_email',
			'billing_phone'      => 'customer_phone',
		];

		foreach ( $data as $key => $map ) {
			if ( ( $value = $booking->get( $map ) ) && is_callable( [ $order, "set_{$key}" ] ) ) {
				$order->{"set_{$key}"}( $value );
			}
		}
	}

	/**
	 * Woocommerce get return url.
	 *
	 * @param string    $return_url URL.
	 * @param \WC_Order $order      The order.
	 *
	 * @return string
	 */
	public function woocommerce_get_return_url( $return_url, $order ) {
		if ( ! $order ) {
			return $return_url;
		}

		if ( ! $booking_id = $order->get_meta( '_awebooking_reference' ) ) {
			return $return_url;
		}

		$this->purge_session_sign();

		return $this->get_thankyou_page_url( $booking_id );
	}

	/**
	 * WooCommerce checkout no payment redirect.
	 *
	 * @param string $received_url Received url.
	 * @param object $order        The order.
	 *
	 * @return string
	 */
	public function woocommerce_checkout_no_payment_needed_redirect( $received_url, $order ) {
		if ( ! $order ) {
			return $received_url;
		}

		if ( ! $booking_id = $order->get_meta( '_awebooking_reference' ) ) {
			return $received_url;
		}

		$this->purge_session_sign();

		return $this->get_thankyou_page_url( $booking_id );
	}

	/**
	 * Purge session sign.
	 */
	protected function purge_session_sign() {
		if ( abrs_session()->has( 'awebooking-inprocess-checkout' ) ) {
			abrs_session()->remove( 'awebooking-inprocess-checkout' );
		}
	}

	/**
	 * Add woocommerce thankyou actions.
	 *
	 * @param int $booking_id The booking ID.
	 */
	public function add_woocommerce_thankyou_actions( $booking_id ) {
		$booking = abrs_get_booking( $booking_id );

		if ( ! $order_id = $booking->get_meta( '_woocommerce_reference' ) ) {
			return;
		}

		WC()->payment_gateways();

		$order = wc_get_order( $order_id );

		do_action( 'woocommerce_thankyou_' . $order->get_payment_method(), $order->get_id() );
		do_action( 'woocommerce_thankyou', $order->get_id() );

		$this->purge_session_sign();
	}

	/**
	 * Add vitural product.
	 */
	protected function add_virtual_product() {
		if ( abrs_reservation()->is_empty() ) {
			return;
		}

		$cart = WC()->cart;
		$cart->empty_cart( false );

		$a = new Product_Booking_Room;

		$cart->cart_contents['awebooking_item_key'] = [
			'key'          => 'awebooking_item_key',
			'product_id'   => -1,
			'variation_id' => -1,
			'variation'    => [],
			'quantity'     => 1,
			'data'         => $a,
			'data_hash'    => wc_get_cart_item_data_hash( $a ),
		];

		$cart->calculate_totals();
	}

	/**
	 * Gets thank you page URL.
	 *
	 * @param int $booking_id The booking ID.
	 *
	 * @return string
	 */
	protected function get_thankyou_page_url( $booking_id ) {
		$booking = abrs_get_booking( $booking_id );

		return ( new Url_Generator( $booking ) )->get_booking_received_url();
	}

	/**
	 * Disable woocommerce mails.
	 */
	public function disable_woocommerce_mails() {
		$mail_ids = apply_filters( 'abrs_woocommerce_mail_ids_disabled', [
			'new_order',
			'cancelled_order',
			'customer_completed_order',
			'customer_invoice',
			'customer_on_hold_order',
			'customer_processing_order',
		] );

		foreach ( $mail_ids as $id ) {
			add_filter( 'woocommerce_email_enabled_' . $id, function ( $enabled, $order ) {
				if ( ! $order instanceof \WC_Order ) {
					return $enabled;
				}

				if ( ! $booking_id = $order->get_meta( '_awebooking_reference' ) ) {
					return $enabled;
				}

				return false;
			}, 10, 2 );
		}
	}

	/**
	 * Update awebooking status.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $from     From status.
	 * @param string $to       To status.
	 */
	public function update_awebooking_status( $order_id, $from, $to ) {
		$order = wc_get_order( $order_id );

		if ( ! $booking_id = $order->get_meta( '_awebooking_reference' ) ) {
			return;
		}

		$booking = abrs_get_booking( $booking_id );

		$booking_status = '';

		switch ( $to ) {
			case 'on-hold':
				$booking_status = 'awebooking-on-hold';
				break;

			case 'processing':
				$booking_status = 'awebooking-inprocess';
				break;

			case 'completed':
				$booking_status = 'awebooking-completed';
				break;

			case 'cancelled':
				$booking_status = 'awebooking-cancelled';
				break;
		}

		if ( ! $booking_status ) {
			return;
		}

		$booking->update_status( $booking_status );

		$booking->save();
	}

	/**
	 * Create the payment item.
	 *
	 * @param  Booking $booking The booking instance.
	 * @param  string  $amount  Amount.
	 *
	 * @return Payment_Item
	 */
	public function create_new_payment( $booking, $amount ) {
		if ( ! $booking instanceof Booking ) {
			$booking = abrs_get_booking( $booking );
		}

		$payment_item = ( new Payment_Item )->fill( [
			'booking_id' => $booking->get_id(),
			'method'     => 'woocommerce',
			'amount'     => $amount,
			'is_deposit' => 'off',
		] );

		try {
			$payment_item->save();
			$payment_item->add_meta( '_woocommerce_payment', 1 );
		} catch ( \Exception $e ) {
			abrs_report( $e );
		}

		return $payment_item;
	}

	/**
	 * Add woocommerce payment method.
	 *
	 * @param array $methods Payment methods.
	 *
	 * @return array
	 */
	public function add_woocommerce_payment_method( $methods ) {
		$methods['woocommerce'] = esc_html__( 'WooCommerce', 'awebooking-woocommerce' );

		return $methods;
	}

	/**
	 * Add WooCommerce payment link.
	 *
	 * @param Payment_Item $payment_item Payment item.
	 * @param Booking      $the_booking  The booking.
	 */
	public function add_woocommerce_payment_link( $payment_item, $the_booking ) {
		if ( ! $order_id = $the_booking->get_meta( '_woocommerce_reference' ) ) {
			return;
		}

		$order          = wc_get_order( $order_id );
		$payment_method = $order->get_payment_method();

		if ( ! $payment_method ) {
			return;
		}

		if ( WC()->payment_gateways() ) {
			$payment_gateways = WC()->payment_gateways->payment_gateways();
		} else {
			$payment_gateways = [];
		}

		/* translators: %s: payment method */
		$payment_method_string = sprintf(
			__( 'Payment via %s', 'awebooking-woocommerce' ),
			esc_html( isset( $payment_gateways[ $payment_method ] ) ? $payment_gateways[ $payment_method ]->get_title() : $payment_method )
		);

		echo '<a href="' . esc_url( get_edit_post_link( $order_id ) ) . '" target="_blank">' . $payment_method_string . '</a>'; // WPCS: XSS ok.
	}

	/**
	 * Fake woocommerce checkout page.
	 *
	 * @param bool $is_checkout Is checkout page?.
	 *
	 * @return bool
	 */
	public function woocommerce_is_checkout( $is_checkout ) {
		if ( abrs_is_checkout_page() ) {
			return true;
		}

		return $is_checkout;
	}
}
