<?php

namespace AweBooking\User_Profile;

use AweBooking\User_Profile\Controllers\Form_Handle;

class Guest_Checkout {
	/**
	 * Hook in methods.
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'abrs_print_notices', [ $this, 'checkout_notice' ], 10 );
		add_action( 'abrs_after_guest_details', [ $this, 'add_signup_field_to_checkout_page' ] );
		add_action( 'abrs_prepare_checkout_process', [ $this, 'handle_guest_checkout' ], 10 );
		add_action( 'abrs_checkout_process_customer_data', [ $this, 'handle_create_account' ], 10 );
	}

	/**
	 * Is guest checkout.
	 *
	 * @return boolean
	 */
	public function is_registration_required() {
		return ( 'on' !== abrs_get_option( 'user_checkout_guest', 'on' ) );
	}

	/**
	 * Is account creation.
	 *
	 * @return boolean
	 */
	public function is_registration_enabled() {
		return ( 'on' === abrs_get_option( 'user_signup_and_login_from_checkout', 'on' ) );
	}

	/**
	 * Handle checkout for guest.
	 */
	public function handle_guest_checkout() {
		if ( is_user_logged_in() ) {
			return;
		}

		if ( $this->is_registration_required() ) {
			wp_redirect( abrs_get_checkout_url() );
			exit;
		}
	}

	/**
	 * Handle create an account.
	 *
	 * @param  \AweBooking\Support\Fluent $data The posted data.
	 *
	 * @throws \Exception
	 */
	public function handle_create_account( $data ) {
		if ( $this->is_registration_required() || ! $this->is_registration_enabled() ) {
			return;
		}

		$createaccount = abrs_http_request()->get( 'createaccount' );

		if ( ! $createaccount ) {
			return;
		}

		$email    = $data->get( 'customer_email', '' );
		$username = '';
		$password = '';

		try {
			$validation_error = new \WP_Error();
			$validation_error = apply_filters( 'abrs_process_registration_errors', $validation_error, $username, $password, $email );

			if ( $validation_error->get_error_code() ) {
				throw new \Exception( $validation_error->get_error_message() );
			}

			$new_customer = Form_Handle::create_new_customer( sanitize_email( $email ), $username, $password );

			if ( is_wp_error( $new_customer ) ) {
				throw new \Exception( $new_customer->get_error_message() );
			}

			if ( apply_filters( 'abrs_registration_auth_new_customer', true, $new_customer ) ) {
				awebooking_user_set_user_auth_cookie( $new_customer );
			}
		} catch ( \Exception $e ) {
			abrs_add_notice( '<strong>' . __( 'Error:', 'awebooking-user-profile' ) . '</strong> ' . $e->getMessage(), 'error' );
		}
	}

	/**
	 * Require login to checkout in checkout page.
	 */
	public function checkout_notice() {
		if ( is_user_logged_in() || ! abrs_is_checkout_page() ) {
			return;
		}

		$login_url = add_query_arg( [
			'referer' => 'checkout',
		], awebooking_user_get_account_endpoint_url( 'profile' ) );

		if ( $this->is_registration_required() ) {
			$message = sprintf( __( 'Please login to checkout.<a href="%s"> Click here to login</a>.', 'awebooking-user-profile' ), esc_url( $login_url ) );
			$status  = 'error';
		} else {
			$message = sprintf( __( 'Returning customer?.<a href="%s"> Click here to login</a>.', 'awebooking-user-profile' ), esc_url( $login_url ) );
			$status  = 'info';
		}
		?>

		<div class="notification notification--<?php echo esc_attr( $status ); ?> dismissible">
			<?php echo wp_kses_post( $message ); ?>
		</div>
		<?php
	}

	/**
	 * Add signup field to checkout page.
	 */
	public function add_signup_field_to_checkout_page() {
		if ( is_user_logged_in() || ! abrs_is_checkout_page() || $this->is_registration_required() || ! $this->is_registration_enabled() ) {
			return;
		}
		?>
		<div class="cmb-row cmb-type-text cmb2-id-customer-createaccount table-layout" data-fieldtype="checkbox">
			<div class="cmb-td">
				<input class="regular-text" id="createaccount" type="checkbox" name="createaccount" value="1"> <span><?php esc_html_e( 'Create an account?', 'awebooking-user-profile' ); ?></span>
			</div>
		</div>
		<?php
	}
}
