<?php
namespace AweBooking\User_Profile;

use Exception;
use RuntimeException;

class Shortcodes {
	public static function init() {
		add_shortcode( apply_filters( "awebooking\user\shortcode_tag", 'awebooking_user_profile' ), __CLASS__ . '::output' );
	}

	/**
	 * Output the shortcode.
	 *
	 * @param array $atts Options Args
	 *
	 * @return void
	 */
	public static function output( $atts ) {
		global $wp;

		if ( ! is_user_logged_in() ) {
			if ( isset( $wp->query_vars['lost-password'] ) ) {
				self::lost_password();
			} else {
				abrs_get_template( 'user/form-login.php' );
			}
		} else {
			ob_start();
			self::account( $atts );
			ob_end_flush();
		}
	}

	/**
	 * Account page.
	 *
	 * @param array $atts Options Args
	 *
	 * @return void
	 */
	private static function account( $atts ) {
		abrs_get_template( 'user/account.php', [
			'current_user' => get_user_by( 'id', get_current_user_id() ),
		] );
	}

	/**
	 * Edit account details page.
	 *
	 * @return void
	 */
	public static function edit_account() {
		$user = get_userdata( get_current_user_id() );

		if ( $user ) {
			$user->filter = 'edit';
		}

		abrs_get_template( 'user/form-edit-profile.php', [ 'user' => $user ] );
	}

	/**
	 * Login page handling
	 *
	 * @return void
	 */
	public static function login() {
		if ( isset( $_POST[ 'pippin_user_login' ] ) && wp_verify_nonce( $_POST[ 'pippin_login_nonce' ], 'pippin-login-nonce' ) ) {
			// this returns the user ID and other info from the user name
			$user = get_user_by( 'login', $_POST['pippin_user_login'] );

			// if the user name doesn't exist
			if ( ! $user ) {
				awebooking_user_add_alert( __( 'Invalid username', 'awebooking-user-profile' ), 'error' );
			}

			// if no password was entered
			if ( ! isset( $_POST['password'] ) || $_POST['password'] === '' ) {
				awebooking_user_add_alert( __( 'Please enter a password', 'awebooking-user-profile' ), 'error' );
			}

			// check the user's login with their password
			if ( ! wp_check_password( $_POST['password'], $user->user_pass, $user->ID ) ) {
				// if the password is incorrect for the specified user
				awebooking_user_add_alert( __( 'Incorrect password', 'awebooking-user-profile' ), 'error' );
			}

			// retrieve all error messages
			$errors = awebooking_user_get_alerts( 'error' );

			// only log the user in if there are no errors
			if ( empty( $errors ) ) {
				wp_setcookie( $_POST['pippin_user_login'], $_POST['password'], true );
				wp_set_current_user( $user->ID, $_POST['pippin_user_login'] );
				do_action( 'wp_login', $_POST['pippin_user_login'] );

				wp_redirect( home_url() );
				exit;
			}
		}
	}

	/**
	 * Lost password page handling.
	 *
	 * @return void
	 */
	public static function lost_password() {
		if ( ! empty( $_GET['reset-link-sent'] ) ) {
			abrs_get_template( 'user/lost-password-confirmation.php' );
			return;
		}

		if ( ! empty( $_GET['reset'] ) ) {
			abrs_get_template( 'user/lost-password-reset-success.php' );
			return;
		}

		if ( ! empty( $_GET['show-reset-form'] ) ) {
			if ( isset( $_COOKIE[ 'wp-resetpass-' . COOKIEHASH ] ) && 0 < strpos( $_COOKIE[ 'wp-resetpass-' . COOKIEHASH ], ':' ) ) {
				list( $rp_login, $rp_key ) = array_map( 'awebooking_user_clean', explode( ':', wp_unslash( $_COOKIE[ 'wp-resetpass-' . COOKIEHASH ] ), 2 ) );

				try {
					$user = self::check_password_reset_key( $rp_key, $rp_login );
				} catch ( \Exception $ex ) {
					awebooking_user_add_alert( $ex->getMessage(), 'error' );
				}

				// reset key / login is correct, display reset password form with hidden key / login values
				if ( isset( $user ) && $user instanceof \WP_User ) {
					$rp_login = $user->user_login;
					return awebooking_user_get_template( 'user/form-reset-password.php', [ 'key' => $rp_key, 'login' => $rp_login ] );
				}
			}
		}

		// Show lost password form by default
		abrs_get_template( 'user/form-lost-password.php', [
			'form' => 'lost_password',
		] );
	}

	/**
	 * Handles sending password retrieval email to user.
	 *
	 * Based on retrieve_password() in core wp-login.php.
	 *
	 * @uses $wpdb WordPress Database object
	 * @return bool True: when finish. False: on error
	 */
	public static function retrieve_password() {
		global $wpdb, $wp_hasher;

		$login = trim( $_POST['user_login'] );

		if ( empty( $login ) ) {
			awebooking_user_add_alert( __( 'Enter a username or e-mail address.', 'awebooking-user-profile' ), 'error' );
			return false;
		}

		// Check on username first, as users can use emails as usernames.
		$user_data = get_user_by( 'login', $login );

		// If no user found, check if it login is email and lookup user based on email.
		if ( ! $user_data && is_email( $login ) ) {
			$user_data = get_user_by( 'email', $login );
		}

		do_action( 'lostpassword_post' );

		if ( ! $user_data ) {
			awebooking_user_add_alert( __( 'Invalid username or e-mail.', 'awebooking-user-profile' ), 'error' );

			return false;
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_data->ID, get_current_blog_id() ) ) {
			awebooking_user_add_alert( __( 'Invalid username or e-mail.', 'awebooking-user-profile' ), 'error' );

			return false;
		}

		$hashed = get_password_reset_key( $user_data );

		if ( is_wp_error( $hashed ) ) {
			awebooking_user_add_alert( $hashed->get_error_message(), 'error' );
			return false;
		}

		abrs_mailer( 'reset_password' )->build( $user_data->user_login, $hashed )->send();

		return true;
	}

	/**
	 * Retrieves a user row based on password reset key and login.
	 *
	 * @param string $key   Hash to validate sending user's password
	 * @param string $login The user login
	 *
	 * @return \WP_USER|bool User's database row on success, false for invalid keys
	 */
	public static function check_password_reset_key( $key, $login ) {
		if ( is_email( $login ) ) {
			$login = abrs_optional( get_user_by( 'email', $login ) )->user_login;
		}

		$user = check_password_reset_key( $key, $login );

		if ( is_wp_error( $user ) ) {
			throw new RuntimeException( $user->get_error_message() );
		}

		return $user;
	}

	/**
	 * Handles resetting the user's password.
	 *
	 * @param object $user     The user
	 * @param string $new_pass New password for the user in plaintext
	 */
	public static function reset_password( $user, $new_pass ) {
		do_action( 'password_reset', $user, $new_pass );
		/**
		 * Change password
		 */
		wp_set_password( $new_pass, $user->ID );

		/**
		 * Reset Password cookie
		 */
		self::set_reset_password_cookie();

		/**
		 * Send email
		 */
		wp_password_change_notification( $user );
	}

	/**
	 * Set or unset the cookie.
	 *
	 * @param string $value Cookie Value
	 *
	 * @return void
	 */
	public static function set_reset_password_cookie( $value = '' ) {
		$rp_cookie = 'wp-resetpass-' . COOKIEHASH;
		$rp_path   = current( explode( '?', wp_unslash( $_SERVER['REQUEST_URI'] ) ) );

		if ( $value ) {
			setcookie( $rp_cookie, $value, 0, $rp_path, COOKIE_DOMAIN, is_ssl(), true );
		} else {
			setcookie( $rp_cookie, ' ', time() - YEAR_IN_SECONDS, $rp_path, COOKIE_DOMAIN, is_ssl(), true );
		}
	}
}
