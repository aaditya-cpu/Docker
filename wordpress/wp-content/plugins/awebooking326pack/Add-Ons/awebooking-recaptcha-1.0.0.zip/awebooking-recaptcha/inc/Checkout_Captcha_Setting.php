<?php
namespace AweBooking\Captcha;

use AweBooking\Admin\Settings\Checkout_Setting;

class Checkout_Captcha_Setting {
	/**
	 * The checkout setting instance.
	 *
	 * @var \AweBooking\Admin\Settings\Checkout_Setting
	 */
	protected $setting;

	/**
	 * Constructor.
	 *
	 * @param \AweBooking\Admin\Settings\Checkout_Setting $setting The setting instance.
	 */
	public function __construct( Checkout_Setting $setting ) {
		$this->setting = $setting;
		$this->register();
	}

	/**
	 * Register the fields.
	 *
	 * @return void
	 */
	public function register() {
		$captcha = $this->setting->add_section( 'captcha', [
			'title' => esc_html__( 'reCAPTCHA', 'awebooking-captcha' ),
		]);

		$captcha->add_field([
			'id'   => '__recaptcha_title',
			'type' => 'title',
			'name' => esc_html__( 'reCAPTCHA', 'awebooking-captcha' ),
		]);

		$captcha->add_field([
			'id'   => 'recaptcha_site_key',
			'type' => 'text',
			'name' => esc_html__( 'Site Key', 'awebooking-captcha' ),
			'desc' => esc_html__( 'Get a site key for your domain by registering here', 'awebooking-captcha' ),
		]);

		$captcha->add_field([
			'id'   => 'recaptcha_secret_key',
			'type' => 'text',
			'name' => esc_html__( 'Secret Key', 'awebooking-captcha' ),
			'desc' => esc_html__( 'Get a site key for your domain by registering here', 'awebooking-captcha' ),
		]);

		/*$captcha->add_field([
			'id'   => 'recaptcha_language',
			'type' => 'select',
			'name' => esc_html__( 'Language', 'awebooking-captcha' ),
			'desc' => esc_html__( '', 'awebooking-captcha' ),
		]);*/

		$captcha->add_field([
			'id'      => 'recaptcha_theme',
			'type'    => 'select',
			'name'    => esc_html__( 'Theme', 'awebooking-captcha' ),
			'default' => 'light',
			'options' => [
				'light' => esc_html__( 'Light', 'awebooking-captcha' ),
				'dark'  => esc_html__( 'Dark', 'awebooking-captcha' ),
			],
		]);
	}
}
