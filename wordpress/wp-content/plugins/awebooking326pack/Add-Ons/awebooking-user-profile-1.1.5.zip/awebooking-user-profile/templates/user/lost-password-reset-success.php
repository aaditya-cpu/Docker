<?php
/**
 * Reset and change password successfully
 * @author 		Awethemes <awethemes.com>
 * @package 	AweBooking\User
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
awebooking_user_print_alerts();

awebooking_user_print_alert( __( 'Your password has been reset.', 'awebooking-user-profile' ) . ' <a class="button" href="' . esc_url( awebooking_user_get_page_permalink( 'profile' ) ) . '">' . __( 'Log in', 'awebooking-user-profile' ) . '</a>' );
