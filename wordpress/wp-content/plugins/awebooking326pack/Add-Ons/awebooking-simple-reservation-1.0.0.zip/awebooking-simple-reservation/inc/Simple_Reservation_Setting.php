<?php
namespace AweBooking\Simple_Reservation;

use AweBooking\Admin\Settings\Abstract_Setting;

class Simple_Reservation_Setting extends Abstract_Setting {
	/**
	 * {@inheritdoc}
	 */
	public function get_id() {
		return 'simple_reservation';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_label() {
		return esc_html__( 'Simple Reservation ', 'awebooking-simple-reservatio' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function setup_fields() {
		$this->add_field( [
			'id'       => '__simple_reservation__',
			'type'     => 'title',
			'name'     => esc_html__( 'Simple Reservation', 'awebooking-simple-reservation' ),
			'priority' => 65,
		] );

		$this->add_field( [
			'id'       => 'enable_simple_reservation',
			'name'     => esc_html__( 'Enable Simple Reservation', 'awebooking-simple-reservation' ),
			'type'     => 'toggle',
			'default'  => true,
			'priority' => 66,
		] );

		$this->add_field( [
			'id'       => 'simple_reservation_shortcode',
			'name'     => esc_html__( 'Shortcode', 'awebooking-simple-reservation' ),
			'type'     => 'text',
			'priority' => 67,
			'deps'     => [ 'enable_simple_reservation', '==', 'true' ],
		] );
	}
}
