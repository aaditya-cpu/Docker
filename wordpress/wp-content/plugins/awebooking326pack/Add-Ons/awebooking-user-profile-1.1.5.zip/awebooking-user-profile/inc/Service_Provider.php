<?php

namespace AweBooking\User_Profile;


class Service_Provider extends \AweBooking\Support\Service_Provider {
	/**
	 * Registers services on the plugin.
	 *
	 * @access private
	 */
	public function register() {
		// Load plugin text-domain.
		load_plugin_textdomain( 'awebooking-user-profile', false, basename( dirname( __DIR__ ) ) . '/languages' );

		$this->plugin->singleton( Admin_Settings::class );
		$this->plugin->tag( Admin_Settings::class, 'settings' );

		$this->plugin->singleton( Query::class );
		$this->plugin->make( Query::class );
	}

	/**
	 * Init service provider.
	 *
	 * @return void
	 */
	public function init() {
		new Guest_Checkout;

		Shortcodes::init();

		Controllers\Ajax_Handle::init();
		( new Controllers\Form_Handle )->init();
		( new Admin_Profile );

		add_filter( 'display_post_states', [ $this, 'page_state' ], 10, 2 );

		add_action( 'wp_enqueue_scripts', [ $this, 'load_scripts' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'load_scripts_property' ] );

		add_filter( 'abrs_email_templates', [ $this, 'add_mail_template' ] );
		add_action( 'abrs_register_admin_routes', [ $this, 'admin_route' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'register_admin_scripts' ], 9 );
	}

	/**
	 * Add template email.
	 *
	 * @param  array $templates abrs_email_templates.
	 *
	 * @return array
	 */
	public function add_mail_template( $templates ) {
		return array_merge( $templates, [
			'reset_password' => \AweBooking\User_Profile\Email\Reset_Password::class,
			'verify_user'    => \AweBooking\User_Profile\Email\Verify_User::class,
			'user_created'   => \AweBooking\User_Profile\Email\User_Created::class,
			'create_account' => \AweBooking\User_Profile\Email\Create_Account::class,
		] );
	}

	/**
	 * Add state for check availability page.
	 *
	 * @param  array $post_states post_states.
	 * @param  void  $post        post object.
	 *
	 * @return array
	 */
	public function page_state( $post_states, $post ) {
		if ( (int) abrs_get_option( 'user_page_id' ) === $post->ID ) {
			$post_states['page_check_availability'] = esc_html__( 'User Profile Page', 'awebooking-user-profile' );
		}

		return $post_states;
	}

	/**
	 * Register/queue frontend scripts.
	 *
	 * @return void
	 */
	public function load_scripts() {
		$assets = AWEBOOKING_USER_PROFILE_URL . 'assets';

		wp_enqueue_script( 'awebooking-user-functions', $assets . '/js/functions.js', [ 'jquery' ], AWEBOOKING_USER_PROFILE_VERSION, true );
		wp_enqueue_style( 'awebooking-user-style', $assets . '/css/style.css', [], AWEBOOKING_USER_PROFILE_VERSION );

		wp_register_script( 'awebooking_user', AWEBOOKING_USER_PROFILE_URL . 'assets/js/account-functions.js', [ 'password-strength-meter' ], AWEBOOKING_USER_PROFILE_VERSION );

		wp_localize_script( 'awebooking_user', 'awebooking_user', [
			'url'            => [
				'template_directory_uri' => get_template_directory_uri() . '/',
				'ajax'                   => esc_url( admin_url( 'admin-ajax.php' ) ),
				'img'                    => AWEBOOKING_USER_PROFILE_URL . 'assets/images',
			],
			'form'           => [
				'SUBMIT'              => esc_html__( 'Submit', 'awebooking-user-profile' ),
				'SENDING'             => esc_html__( 'Sending...', 'awebooking-user-profile' ),
				'CONFIRM_REMOVE'      => esc_html__( 'Do you want to delete this property?', 'awebooking-user-profile' ),
				'WARNING_GUEST_LIKE'  => esc_html__( 'You must login to like this propery.', 'awebooking-user-profile' ),
				'INVALID_EMAIL'       => esc_html__( 'Please, enter a valid email address.', 'awebooking-user-profile' ),
				'INVALID_USER'        => esc_html__( 'Please use between 6 and 32 characters.', 'awebooking-user-profile' ),
				'INVALID_CONFIRM_PWD' => esc_html__( 'Confirm password is not match.', 'awebooking-user-profile' ),
				'REMOVE'              => esc_html__( 'Remove', 'awebooking-user-profile' ),
				'INVALID_IMAGE'       => esc_html__( 'Please select a valid image', 'awebooking-user-profile' ),
				'OEMBED'              => esc_html__( 'This video url is invalid or not being supported by WP Oembed', 'awebooking-user-profile' ),
				'EMPTY_VIDEO'         => esc_html__( 'No video to display.', 'awebooking-user-profile' ),
			],
			'password_meter' => [
				'min_password_strength' => apply_filters( 'awebooking\user\min_password_strength', 3 ),
				'i18n_password_error'   => esc_attr__( 'Please enter a stronger password.', 'awebooking-user-profile' ),
				'i18n_password_label'   => esc_attr__( 'Password strength:', 'awebooking-user-profile' ),
				'i18n_password_hint'    => esc_attr__( 'The password should be at least seven characters long. To make it stronger, use upper and lower case letters, numbers and symbols like ! " ? $ % ^ &amp; ).', 'awebooking-user-profile' ),
			],
		] );

		wp_localize_script( 'password-strength-meter', 'pwsL10n', [
			'unknown'  => esc_html__( 'Password strength unknown', 'awebooking-user-profile' ),
			'short'    => esc_html__( 'Very weak', 'awebooking-user-profile' ),
			'bad'      => esc_html__( 'Weak', 'awebooking-user-profile' ),
			'good'     => esc_html__( 'Medium', 'awebooking-user-profile' ),
			'strong'   => esc_html__( 'Strong', 'awebooking-user-profile' ),
			'mismatch' => esc_html__( 'Mismatch', 'awebooking-user-profile' ),
		] );
	}

	/**
	 * Enqueue script property.
	 *
	 * @return void
	 */
	public static function load_scripts_property() {
		if ( is_awebooking_user_page() ) {
			if ( ! is_user_logged_in() ) {
				wp_enqueue_script( 'zxcvbn-async' );
				wp_enqueue_script( 'password-strength-meter' );
			}

			wp_enqueue_script( 'awebooking_user' );
		}

		if ( abrs_is_checkout_page() ) {
			wp_enqueue_script( 'awebooking_user_checkout' );
		}
	}

	/**
	 * Register admin scripts
	 */
	public function register_admin_scripts() {
		$screen = get_current_screen();

		wp_register_script( 'awebooking-customer-data', AWEBOOKING_USER_PROFILE_URL . 'assets/js/customer-data.js', [ 'jquery' ], AWEBOOKING_USER_PROFILE_VERSION, true );

		if ( 'awebooking' === $screen->id ) {
			wp_enqueue_script( 'awebooking-customer-data' );
		}
	}

	/**
	 * Register admin route
	 *
	 * @param object $route Admin route.
	 */
	public function admin_route( $route ) {
		$route->get( '/ajax/customer-data/{customer:\d+}', Controllers\Ajax_Controller::class . '@customer_data' );
	}
}
