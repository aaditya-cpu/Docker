<?php

/**
 * User Functions
 */

/**
 * Create a new user.
 *
 * @param  string $email    Customer email.
 * @param  string $username Customer username.
 * @param  string $password Customer password.
 *
 * @return int|WP_Error Returns \WP_Error on failure, Int (user ID) on success.
 */
function awebooking_user_create_user( $email, $username = '', $password = '' ) {

	// Check the email address.
	if ( empty( $email ) || ! is_email( $email ) ) {

		return new \WP_Error( 'registration-error-invalid-email',
			__( 'Please provide a valid email address.', 'awebooking-user-profile' ) );
	}

	if ( email_exists( $email ) ) {
		return new \WP_Error( 'registration-error-email-exists',
			__( 'An account is already registered with your email address. Please login.',
				'awebooking-user-profile' ) );
	}

	// Handle username creation.
	if ( ! empty( $username ) ) {

		$username = sanitize_user( $username );

		if ( empty( $username ) || ! validate_username( $username ) ) {
			return new \WP_Error( 'registration-error-invalid-username',
				__( 'Please enter a valid account username.', 'awebooking-user-profile' ) );
		}

		if ( username_exists( $username ) ) {
			return new \WP_Error( 'registration-error-username-exists',
				__( 'An account is already registered with that username. Please choose another.',
					'awebooking-user-profile' ) );
		}
	} else {

		$username = sanitize_user( current( explode( '@', $email ) ), true );

		// Ensure username is unique.
		$append = 1;

		$o_username = $username;

		while ( username_exists( $username ) ) {
			$username = $o_username . $append;
			$append ++;
		}
	}

	// Handle password creation.
	if ( empty( $password ) ) {
		return new \WP_Error( 'registration-error-missing-password',
			__( 'Please enter an account password.', 'awebooking-user-profile' ) );
	}

	// Use \WP_Error to handle registration errors.
	$errors = new \WP_Error();

	do_action( 'awebooking\user\register_post', $username, $email, $errors );

	$errors = apply_filters( 'awebooking\user\registration_errors', $errors, $username, $email );

	if ( $errors->get_error_code() ) {
		return $errors;
	}

	$new_user_data = apply_filters( 'awebooking\user\new_user_data', [
		'user_login' => $username,
		'user_pass'  => $password,
		'user_email' => $email,
		'role'       => 'author',
	] );

	$user_id = wp_insert_user( $new_user_data );

	if ( is_wp_error( $user_id ) ) {
		return new \WP_Error( 'registration-error', '<strong>' . __( 'ERROR',
				'awebooking-user-profile' ) . '</strong>: ' . __( 'Couldn&#8217;t register you&hellip; please contact us if you continue to have problems.',
				'awebooking-user-profile' ) );
	}

	/**
	 * Default order remind
	 */
	update_user_meta( $user_id, 'order_remind_email', 1 );
	update_user_meta( $user_id, 'order_remind_alert', 1 );

	//Call Mailer
	abrs_mailer( 'user_created' )->build( $user_id )->send();

	return $user_id;
}

/**
 * Verify a new user.
 *
 * @param  string $email       Customer email.
 * @param  string $username    Customer username.
 * @param  string $password    Customer password.
 * @param  string $confirm_pwd Confirm Customer password
 *
 * @return int|WP_Error Returns \WP_Error on failure, Int (user ID) on success.
 */
function awebooking_user_verify_user( $email, $username = '', $password = '', $confirm_pwd = '' ) {
	// Check the email address.
	if ( empty( $email ) || ! is_email( $email ) ) {

		return new \WP_Error( 'registration-error-invalid-email',
			__( 'Please provide a valid email address.', 'awebooking-user-profile' ) );
	}

	if ( email_exists( $email ) ) {
		return new \WP_Error( 'registration-error-email-exists',
			__( 'An account is already registered with your email address. Please login.',
				'awebooking-user-profile' ) );
	}

	// Handle username creation.
	if ( ! empty( $username ) ) {

		$username = sanitize_user( $username );

		if ( empty( $username ) || ! validate_username( $username ) ) {
			return new \WP_Error( 'registration-error-invalid-username',
				__( 'Please enter a valid account username.', 'awebooking-user-profile' ) );
		}

		if ( username_exists( $username ) ) {
			return new \WP_Error( 'registration-error-username-exists',
				__( 'An account is already registered with that username. Please choose another.',
					'awebooking-user-profile' ) );
		}
	} else {

		$username = sanitize_user( current( explode( '@', $email ) ), true );

		// Ensure username is unique.
		$append = 1;

		$o_username = $username;

		while ( username_exists( $username ) ) {
			$username = $o_username . $append;
			$append ++;
		}
	}

	// Handle password creation.
	if ( empty( $password ) ) {
		return new \WP_Error( 'registration-error-missing-password',
			__( 'Please enter an account password.', 'awebooking-user-profile' ) );
	} elseif ( empty( $confirm_pwd ) ) {
		return new \WP_Error( 'registration-error-missing-password',
			__( 'Please enter an confirm password.', 'awebooking-user-profile' ) );
	} elseif ( $confirm_pwd != $password ) {
		return new \WP_Error( 'registration-error-missing-password',
			__( 'Password and confirm password are not matched.', 'awebooking-user-profile' ) );
	}

	// Use \WP_Error to handle registration errors.
	$errors = new \WP_Error();

	$errors = apply_filters( 'awebooking\user\registration_errors', $errors, $username, $email );

	if ( $errors->get_error_code() ) {
		return $errors;
	}

	$new_user_data = apply_filters( 'awebooking\user\verify_user_data', [
		'user_login' => $username,
		'user_pass'  => base64_encode( $password ),
		'user_email' => $email,
	] );

	$hash = md5( json_encode( $new_user_data ) );

	/**
	 * Save hash and user data to transient
	 */
	set_transient( sprintf( 'awebooking_user_verify_%s', $hash ), $new_user_data, 1 * HOUR_IN_SECONDS );
	setcookie( 'awebooking_user_verify', $hash, time() + ( 1 * HOUR_IN_SECONDS ) );

	$new_user_data['user_hash'] = $hash;
	abrs_mailer( 'verify_user' )->build( $new_user_data )->send();

	return true;
}

/**
 * Login a user (set auth cookie and set global user object).
 *
 * @param int $user_id
 */
function awebooking_user_set_user_auth_cookie( $user_id ) {
	global $current_user;

	$current_user = get_user_by( 'id', $user_id );

	wp_set_auth_cookie( $user_id, true );
}

/**
 * Wrapper for @see get_avatar() which doesn't simply return
 * the URL so we need to pluck it from the HTML img tag.
 *
 * Kudos to https://github.com/WP-API/WP-API for offering a better solution.
 *
 * @since 1.0
 *
 * @param string $email the user's email.
 *
 * @return string the URL to the user's avatar.
 */
function awebooking_user_get_user_avatar_url( $email ) {
	$avatar_html = get_avatar( $email );

	// Get the URL of the avatar from the provided HTML.
	preg_match( '/src=["|\'](.+)[\&|"|\']/U', $avatar_html, $matches );

	if ( isset( $matches[1] ) && ! empty( $matches[1] ) ) {
		return esc_url_raw( $matches[1] );
	}

	return null;
}

/**
 * Get Account menu items.
 *
 * @since 1.0
 * @return array
 */
function awebooking_user_get_account_menu_items() {
	$items = [
		'dashboard'    => [
			'icon'  => 'fa fa-home',
			'label' => __( 'Dashboard', 'awebooking-user-profile' ),
		],
		'profile'      => [
			'icon'  => 'fa fa-user',
			'label' => __( 'Profile', 'awebooking-user-profile' ),
		],
		'edit-booking' => [
			'icon'  => '',
			'label' => __( 'Booking Information', 'awebooking-user-profile' ),
		],
		'orders'       => [
			'icon'  => '',
			'label' => __( 'Bookings', 'awebooking-user-profile' ),
		],
		'user-logout'  => [
			'icon'  => 'fa fa-sign-out',
			'label' => __( 'Logout', 'awebooking-user-profile' ),
		],
	];

	return apply_filters( 'awebooking\user\menu_items', $items );
}

/**
 * Get account menu item classes.
 *
 * @since 1.0
 *
 * @param string $endpoint
 *
 * @return string
 */
function awebooking_user_get_account_menu_item_classes( $endpoint ) {


	$classes = [
		'awebooking_user-navigation-link',
		'awebooking_user-navigation-link--' . $endpoint,
	];

	// Set current item class.
	global $wp;

	$current = isset( $wp->query_vars[ $endpoint ] );

	if ( $endpoint == 'dashboard' && count( $wp->query_vars ) <= 1 ) {
		$current = true;
	}

	if ( $current ) {
		$classes[] = 'active';
	}

	$classes = apply_filters( 'awebooking\user\menu_item_classes', $classes, $endpoint );

	return implode( ' ', array_map( 'sanitize_html_class', $classes ) );
}

/**
 * Get account endpoint URL.
 *
 * @since 1.0
 *
 * @param string $endpoint
 *
 * @return string
 */
function awebooking_user_get_account_endpoint_url( $endpoint, $value = '' ) {

	if ( 'dashboard' === $endpoint ) {
		return awebooking_user_get_page_permalink( 'user-profile' );
	}

	return awebooking_user_get_endpoint_url( $endpoint, $value, awebooking_user_get_page_permalink( 'user-profile' ) );
}

/**
 * Returns the url to the lost password endpoint url.
 *
 * @access public
 *
 * @param  string $default_url
 *
 * @return string
 */
function awebooking_user_lostpassword_url( $default_url = '' ) {

	$reset_url = awebooking_user_get_page_permalink( 'user-profile' );

	if ( false !== $reset_url ) {
		return awebooking_user_get_endpoint_url( 'lost-password', '', $reset_url );
	}

	return $default_url;
}

add_filter( 'lostpassword_url', 'awebooking_user_lostpassword_url', 10, 1 );

/**
 * Change avatar image url
 *
 * @access public
 *
 * @param array      $args
 * @param int|string $id_or_email
 * @param array      $args
 *
 * @return string
 */
function awebooking_user_pre_get_avatar_data( $args, $id_or_email ) {

	$image_avatar = get_user_meta( $id_or_email, 'image_avatar', true );

	$image_url = wp_get_attachment_image_url( $image_avatar,
		apply_filters( 'awebooking_user_user_avatar_size', 'thumbnail' ) );

	if ( ! empty( $image_url ) ) {
		$args['url']          = $image_url;
		$args['found_avatar'] = true;
	}

	return $args;
}

add_filter( 'pre_get_avatar_data', 'awebooking_user_pre_get_avatar_data', 10, 2 );

/**
 * Process the login form.
 *
 * @return bool
 */
function awebooking_user_login( $username, $password, $rememberme = false ) {

	$creds = [];

	$validation_error = new \WP_Error();
	$validation_error = apply_filters( 'awebooking\user\process_login_errors', $validation_error, $username,
		$password );

	if ( $validation_error->get_error_code() ) {
		throw new Exception( '<strong>' . __( 'Error',
				'awebooking-user-profile' ) . ':</strong> ' . $validation_error->get_error_message() );
	}

	if ( empty( $username ) ) {
		throw new Exception( '<strong>' . __( 'Error',
				'awebooking-user-profile' ) . ':</strong> ' . __( 'Username is required.',
				'awebooking-user-profile' ) );
	}

	if ( empty( $password ) ) {
		throw new Exception( '<strong>' . __( 'Error',
				'awebooking-user-profile' ) . ':</strong> ' . __( 'Password is required.',
				'awebooking-user-profile' ) );
	}

	if ( is_email( $username ) && apply_filters( 'awebooking\user\get_username_from_email', true ) ) {
		$user = get_user_by( 'email', $username );

		if ( isset( $user->user_login ) ) {
			$creds['user_login'] = $user->user_login;
		} else {
			throw new Exception( '<strong>' . __( 'Error',
					'awebooking-user-profile' ) . ':</strong> ' . __( 'A user could not be found with this email address.',
					'awebooking-user-profile' ) );
		}
	} else {
		$creds['user_login'] = $username;
	}

	$creds['user_password'] = $password;
	$creds['remember']      = $rememberme;
	$secure_cookie          = is_ssl() ? true : false;

	$user = wp_signon( apply_filters( 'awebooking\user\login_credentials', $creds ), $secure_cookie );

	if ( ! is_wp_error( $user ) ) {
		return $user;
	} else {
		$message = $user->get_error_message();
		$message = str_replace( '<strong>' . esc_html( $creds['user_login'] ) . '</strong>',
			'<strong>' . esc_html( $username ) . '</strong>', $message );
		throw new Exception( $message );
	}

	return false;
}

/**
 * Save customer id when booking completed
 */
function awebooking_user_booking_save_customer( $booking ) {
	if ( $booking->get_id() ) {
		$uid = is_user_logged_in() ? get_current_user_id() : 0;
		update_post_meta( $booking->get_id(), '_customer_id', $uid );
	}
}

add_action( 'awebooking/checkout_completed', 'awebooking_user_booking_save_customer' );

/**
 * Gets default user meta keys.
 *
 * @return array
 */
function abrs_get_default_user_meta_keys() {
	return apply_filters( 'abrs_get_default_user_meta_key', [
		'customer_title',
		'customer_first_name',
		'customer_last_name',
		'customer_company',
		'customer_address',
		'customer_address_2',
		'customer_city',
		'customer_state',
		'customer_country',
		'customer_postal_code',
		'customer_phone',
		'customer_email',
	] );
}

/**
 * Get user meta for a given key, with fallbacks to core user info for pre-existing fields.
 *
 * @param int    $user_id User ID of the user being edited.
 * @param string $key     Key for user meta field.
 *
 * @return string
 */
function abrs_get_user_meta( $user_id, $key ) {
	$value           = get_user_meta( $user_id, $key, true );
	$existing_fields = [ 'customer_first_name', 'customer_last_name' ];
	if ( ! $value && in_array( $key, $existing_fields ) ) {
		$value = get_user_meta( $user_id, str_replace( 'customer_', '', $key ), true );
	} elseif ( ! $value && ( 'customer_email' === $key ) ) {
		$user  = get_userdata( $user_id );
		$value = $user->user_email;
	}

	return $value;
}

/**
 * Gets default user meta data.
 *
 * @param int $user_id User ID.
 *
 * @return array
 */
function abrs_get_default_user_meta_data( $user_id ) {
	$meta_keys = abrs_get_default_user_meta_keys();

	$data = [];

	foreach ( $meta_keys as $key ) {
		$data[ $key ] = abrs_get_user_meta( $user_id, $key );
	}

	return apply_filters( 'abrs_get_default_user_meta_data', $data, $meta_keys );
}
