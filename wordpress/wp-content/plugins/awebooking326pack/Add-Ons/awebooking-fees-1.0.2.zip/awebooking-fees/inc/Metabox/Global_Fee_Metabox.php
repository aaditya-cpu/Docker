<?php

namespace AweBooking\Fees\Metabox;

use AweBooking\Support\WP_Data;
use Awethemes\Http\Request;
use AweBooking\Admin\Metabox;
use AweBooking\Fees\Model\Global_Fee;

class Global_Fee_Metabox extends Metabox {
	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id       = 'awebooking-fee-data';
		$this->title    = esc_html__( 'Fee', 'awebooking-fees' );
		$this->screen   = 'hotel_fee';
		$this->priority = 'high';
	}

	/**
	 * Output the metabox.
	 *
	 * @param \WP_Post $post The WP_Post object.
	 */
	public function output( $post ) {
		$controls = $this->get_form(
			$fee = new Global_Fee( $post->ID )
		);

		echo '<div class="cmb2-wrap awebooking-wrap abrs-cmb2-float">
			<div class="cmb2-metabox cmb2-block-metabox">';

		foreach ( $controls->prop( 'fields' ) as $control ) {
			$controls->show_field( $control );
		}

		echo '</div></div>';
		wp_nonce_field( 'awebooking_save_data', '_awebooking_nonce' );
	}

	/**
	 * Gets the form controls.
	 *
	 * @param \AweBooking\Fees\Model\Global_Fee $fee The fee object instance.
	 * @return \AweBooking\Component\Form\Form
	 */
	public function get_form( $fee ) {
		$form = abrs_create_form( 'global_fee_data', $fee );

		/*$form->add_field( [
			'id'           => 'public_label',
			'type'         => 'text',
			'name'         => esc_html__( 'Label', 'awebooking-fees' ),
			'tooltip'      => esc_html__( 'This will be shown in the front-end, and emails content.', 'awebooking-fees' ),
			'translatable' => true,
		] );*/

		$form->add_field( [
			'id'           => 'amount',
			'type'         => 'abrs_amount',
			'name'         => esc_html__( 'Fee amount', 'awebooking-fees' ),
			// 'tooltip'      => 'E.g. -5 or 5%',
			'translatable' => true,
		] );

		/*$form->add_field( [
			'id'               => 'tax_rate',
			'type'             => 'select',
			'name'             => esc_html__( 'Tax', 'awebooking-fees' ),
			'classes'          => 'with-selectize',
			'options_cb'       => 'abrs_get_tax_rates_for_dropdown',
			'show_option_none' => esc_html__( 'No Tax', 'awebooking-fees' ),
			'translatable'     => true,
			'show_on_cb'       => function () {
				return abrs_tax_enabled() && ( 'per_room' === abrs_get_tax_rate_model() );
			},
		] );*/

		$form->add_field( [
			'id'                => '_room_types',
			'type'              => 'multicheck',
			'name'              => esc_html__( 'Applicable', 'awebooking-fees' ),
			'classes'           => 'with-selectize',
			'save_field'        => false,
			'translatable'      => true,
			'show_option_none'  => false,
			'select_all_button' => false,
			'options_cb'        => WP_Data::cb( 'posts', [
				'post_type'      => 'room_type',
				'posts_per_page' => -1,
			] ),
			'default_cb' => function() {
				$rel = awebooking()->relationships()->get( 'abrs_fees_to_rooms' );

				return $rel->get_connected( get_the_ID() );
			},
		] );

		return $form;
	}

	/**
	 * Handle save the the metabox.
	 *
	 * @param \WP_Post                $post    The WP_Post object instance.
	 * @param \Awethemes\Http\Request $request The HTTP Request.
	 */
	public function save( $post, Request $request ) {
		$fee = new Global_Fee( $post->ID );
		$controls = $this->get_form( $fee );

		// ...
		$fee->fill( $controls->handle( $request )->all() );
		$fee->save();

		// ...
		$rel     = awebooking()->relationships()->get( 'abrs_fees_to_rooms' );
		$new_ids = array_map( 'absint', $request->get( '_room_types' ) );

		$current_ids = wp_list_pluck( $rel->find( [
			'from' => $fee->get_id(),
		] ), 'rel_to' );

		$delete_ids = ! $new_ids ? $current_ids : array_diff( $current_ids, $new_ids );

		foreach ( $delete_ids as $_delete_id ) {
			$rel->disconnect( $fee->get_id(), $_delete_id );
		}

		if ( $new_ids ) {
			foreach ( $new_ids as $new_id ) {
				if ( in_array( $new_ids, $current_ids ) ) {
					continue;
				}

				$rel->connect( $fee->get_id(), $new_id );
			}
		}
	}
}
