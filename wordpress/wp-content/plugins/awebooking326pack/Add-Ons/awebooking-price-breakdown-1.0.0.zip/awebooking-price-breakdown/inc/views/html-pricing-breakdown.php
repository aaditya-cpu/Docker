<a href="#awebooking-breakdown-<?php echo esc_attr( $dialogid ); ?>" data-a11y-dialog-show="awebooking-breakdown-<?php echo esc_attr( $dialogid ); ?>">
	<?php esc_html_e( 'Show breakdown', 'awebooking-breakdown' ); ?>
</a>

<div id="awebooking-breakdown-<?php echo esc_attr( $dialogid ); ?>" class="awebooking-dialog awebooking-breakdown" data-init="awebooking-dialog">
	<div class="awebooking-dialog__overlay" tabindex="-1" data-a11y-dialog-hide></div>

	<div class="awebooking-dialog__dialog" role="dialog">
		<a href="#" class="awebooking-dialog__close" data-a11y-dialog-hide aria-label="Close this dialog window">&times;</a>
		<h2><?php echo esc_html( $room_type->get_title() ); ?></h2>

		<div class="awebooking-breakdown__table">
			<table>
				<tbody>
				<?php foreach( $breakdowns['room_only'] as $date => $amount ): ?>
					<tr>
						<td><?php echo abrs_format_date( $date ); ?></td>
						<td><?php abrs_price( $amount ); ?></td>
					</tr>
				<?php endforeach ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
