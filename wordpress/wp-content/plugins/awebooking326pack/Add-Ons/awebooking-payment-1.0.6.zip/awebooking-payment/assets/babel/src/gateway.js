const Gateway = (function ($) {
  class Gateway {
    constructor() {
      this.card = void 0
      Gateway.register(this.getName(), this)
    }

    on(e) {}
    off() {}
    setup(config) {}

    getName() {
      return this.name
    }

    forceSubmit() {
      this.getCheckoutFormElement().submit()
    }

    getCard() {
      return this.card
    }

    getCardData() {
      const data = {}

      if (this.card) {
        const _clean = (str) => (String(str)).trim().replace(/\s/g,'')
        let expiry = _clean($(this.card.$expiryInput).val())

        data.cvc = _clean($(this.card.$cvcInput).val())
        data.name = _clean($(this.card.$nameInput).val())
        data.number = _clean($(this.card.$numberInput).val())
        data.expiry = expiry.split('/').map(_clean)
      }

      return data
    }

    createCard() {
      const cardElement = this.getCardElement()

      if (cardElement.classList.contains('disabled') ||
        ! cardElement.classList.contains('credit-card--visual')) {
        return;
      }

      this.card = new Card({
        form: this.getCheckoutFormElement(),
        container: cardElement.querySelector('.credit-card__display'),
        width: 350,
        formatting: true,
        formSelectors: {
          cvcInput: '.credit-card__cvc',
          nameInput: '.credit-card__name',
          numberInput: '.credit-card__number',
          expiryInput: '.credit-card__expiry'
        },
      })

      $(cardElement).data('card', this.card)
    }

    isAvailable() {
      return !! this.getRootElement()
    }

    getRootElement() {
      const input = $('#payment-methods').find('input[type="radio"][name="payment_method"][value="' + this.getName() + '"]')

      return input.length
        ? input.closest('li')[0]
        : void 0
    }

    getCardElement() {
      const rootElement = this.getRootElement()
      return rootElement ? rootElement.querySelector('.credit-card') : void 0
    }

    getSubmitButton() {
      return this
        .getCheckoutFormElement()
        .querySelector('button[name=awebooking_submit]')
    }

    getCheckoutFormElement() {
      return document.getElementById('checkout-form');
    }
  }

  /**
   * Store all instance of gateways.
   *
   * @type {Object}
   */
  Gateway.instances = {}

  /**
   * Retrive gateway instance.
   *
   * @param {string} name
   * @return {Gateway|null}
   */
  Gateway.get = function (name) {
    return Gateway.instances.hasOwnProperty(name) ? Gateway.instances[name] : null
  }

  /**
   * Register a gateway instance.
   *
   * @param {string}  name
   * @param {Gateway} instance
   */
  Gateway.register = function (name, instance) {
    Gateway.instances[name] = instance
  }

  return Gateway
})(jQuery)

export default Gateway
