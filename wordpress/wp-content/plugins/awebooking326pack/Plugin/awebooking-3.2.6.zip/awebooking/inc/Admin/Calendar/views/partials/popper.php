<div class="scheduler__popper" style="display: none;">
	<ul class="scheduler__actions">
		<?php $calendar->call( 'display_actions' ); ?>
	</ul>
</div>
