<?php

namespace AweBooking\Reservation\Exceptions;

class RoomRateException extends \Exception {}
