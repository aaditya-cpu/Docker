<?php

add_filter( 'body_class', 'awebooking_user_body_class' );
add_action( 'template_redirect', 'awebooking_user_template_redirect' );

add_action( 'awebooking\user\navigation', 'awebooking_user_navigation' );
add_action( 'awebooking\user\content', 'awebooking_user_content' );
add_action( 'awebooking\user\user_dropdown', 'awebooking_user_user_dropdown' );

add_action( 'awebooking\user\edit-booking_endpoint', 'awebooking_user_edit_booking' );
add_action( 'awebooking\user\profile_endpoint', [ AweBooking\User_Profile\Shortcodes::class, 'edit_account' ], 20 );
add_action( 'awebooking\user\orders_endpoint', 'awebooking_user_orders' );
add_action( 'awebooking\user\view-booking_endpoint', 'awebooking_user_view_booking' );

add_action( 'awebooking\user\content', 'awebooking_user_print_alerts', 5 );
