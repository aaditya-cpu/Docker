<?php
/**
 * Lost password confirmation text.
 * 
 * @author 		Awethemes <awethemes.com>
 * @package 	AweBooking\User
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

awebooking_user_print_alerts();
awebooking_user_print_alert( __( 'Password reset email has been sent.', 'awebooking-user-profile' ));
?>

<p><?php echo apply_filters( 'awebooking\user\lost_password_message', __( 'A password reset email has been sent to the email address on file for your account, but may take several minutes to show up in your inbox. Please wait at least 10 minutes before attempting another reset.', 'awebooking-user-profile' ) ); ?></p>
