<?php
namespace AweBooking\Rules\Rules;

interface Filters {
	/**
	 * List of groups in the filters and operators dropdowns.
	 *
	 * @return array
	 */
	public function get_groups();

	/**
	 * Array of available filters in the builder.
	 *
	 * @return array
	 */
	public function get_filters();
}
