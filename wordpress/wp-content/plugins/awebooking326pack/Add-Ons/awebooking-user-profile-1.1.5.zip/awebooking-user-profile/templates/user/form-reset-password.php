<?php
/**
 * Lost Password reset form
 *
 * @author 		Awethemes <awethemes.com>
 * @package 	AweBooking\User
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

awebooking_user_print_alerts(); ?>


<form method="post" class="lost_reset_password">

	<p><?php echo apply_filters( 'awebooking\user\reset_password_message', __( 'Enter a new password below.', 'awebooking-user-profile') ); ?></p>

	<p class="form-row form-row-first">
		<label for="password_1"><?php _e( 'New password', 'awebooking-user-profile' ); ?> <span class="required">*</span></label>
		<input type="password" class="input-text" name="password_1" id="password_1" />
	</p>
	<p class="form-row form-row-last">
		<label for="password_2"><?php _e( 'Re-enter new password', 'awebooking-user-profile' ); ?> <span class="required">*</span></label>
		<input type="password" class="input-text" name="password_2" id="password_2" />
	</p>

	<input type="hidden" name="reset_key" value="<?php echo esc_attr( $key); ?>" />
	<input type="hidden" name="reset_login" value="<?php echo esc_attr( $login ); ?>" />

	<div class="clear"></div>

	<?php do_action( 'awebooking\user\resetpassword_form' ); ?>

	<p class="form-row">
		<input type="hidden" name="awebooking_user_reset_password" value="true" />
		<input type="submit" class="button" value="<?php esc_attr_e( 'Save', 'awebooking-user-profile' ); ?>" />
	</p>

	<?php wp_nonce_field( 'reset_password' ); ?>

</form
<?php die(); ?>
