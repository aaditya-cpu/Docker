<?php

/**
 * Template Functions
 *
 * @package   AweBooking\User
 * @category  Core
 * @author    Awethemes <awethemes.com>
 * @license   GPLv3
 * @version   1.0
 */

use AweBooking\User_Profile\Booking_List;
use AweBooking\User_Profile\Booking_Detail;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Handle redirects before content is output - hooked into template_redirect so is_page works.
 *
 * @since 1.0
 * @global object $wp_query
 * @global object $wp
 * @return void
 */
function awebooking_user_template_redirect() {
	global $wp_query, $wp;

	if ( isset( $wp->query_vars['user-logout'] ) ) {
		wp_redirect( str_replace( '&amp;', '&', wp_logout_url( awebooking_user_get_page_permalink( 'account' ) ) ) );
		exit;
	}
}

/**
 * Add body classes for Account pages.
 *
 * @since 1.0
 *
 * @param  array $classes
 *
 * @return array
 */
function awebooking_user_body_class( $classes ) {

	$classes = (array) $classes;

	if ( is_awebooking_user_page() ) {
		$classes[] = 'awebooking_user-account';
		$classes[] = 'awebooking_user-page';
	}

	foreach ( awebooking_user()->query->query_vars as $key => $value ) {
		if ( is_awebooking_user_endpoint_url( $key ) ) {
			$classes[] = 'awebooking_user-' . sanitize_html_class( $key );
		}
	}

	return array_unique( $classes );
}

/** Login **************************************************************** */

/**
 * Output the User Login Form.
 *
 * @since         1.0
 *
 * @subpackage    Forms
 *
 * @param array $args
 */
function awebooking_user_login_form( $args = [] ) {

	$defaults = [
		'message'  => '',
		'redirect' => '',
		'hidden'   => false,
	];

	$args = wp_parse_args( $args, $defaults );

	abrs_get_template( 'form-login.php', $args );
}

/**
 * Account content output.
 *
 * @since 1.0
 * @global object $wp
 */
function awebooking_user_content() {

	global $wp;

	foreach ( $wp->query_vars as $key => $value ) {

		// Ignore pagename param.
		if ( 'pagename' == $key && 'page_id' == $key ) {
			continue;
		}

		if ( has_action( 'awebooking\user\\' . $key . '_endpoint' ) ) {
			do_action( 'awebooking\user\\' . $key . '_endpoint', $value );

			return;
		}
	}

	// No endpoint found? Default to dashboard.
	abrs_get_template( 'user/dashboard.php', [
		'current_user' => get_user_by( 'id', get_current_user_id() ),
	] );
}

/**
 * Account navigation template.
 *
 * @since 1.0
 */
function awebooking_user_navigation() {
	abrs_get_template( 'user/navigation.php' );
}

/**
 * Edit Password
 *
 * @since 1.0
 */
function awebooking_user_edit_password() {
	abrs_get_template( 'user/form-edit-password.php' );
}

/**
 * User dropdown in header
 *
 * @since 1.0
 */
function awebooking_user_dropdown() {
	abrs_get_template( 'user/user-dropdown.php' );
}

function awebooking_user_edit_booking() {
	$user = get_userdata( get_current_user_id() );

	if ( $user ) {
		$user->filter = 'edit';
	}
	abrs_get_template( 'user/form-edit-booking.php', [ 'user' => $user ] );
}

function awebooking_user_orders() {

	$booking_list = new Booking_List();

	abrs_get_template( 'user/orders.php', [
		'customer_bookings' => $booking_list->get_list(),
		'booking_columns'   => $booking_list->columns(),
		'booking_list'      => $booking_list,
	] );
}

function awebooking_user_view_booking() {

	$id      = get_query_var( 'view-booking' );
	$booking = false;
	if ( $id ) {
		$booking = new Booking_Detail( $id );
	}

	abrs_get_template( 'user/view-booking.php', [ 'the_booking' => $booking ] );
}
