<?php
/**
 * Edit booking info form
 * 
 * @author 		Awethemes <awethemes.com>
 * @package 	AweBooking\User
 * @since 1.0
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( isset( $_GET['action'] ) && $_GET['action'] == 'updated' ) {
	awebooking_user_print_alert( esc_attr__( 'Billing address details changed successfully.', 'awebooking-user-profile' ) );
}

do_action( 'awebooking\user\before_edit_booking' );
?>

<form method="post" class="awebooking_user-form">

	<?php do_action( "awebooking\user\before_profile_form_profile" ); ?>

	<div class="awebooking_user-edit_booking">
		
		<h3 class="awebooking_user-form-title"><?php esc_html_e( 'Booking details', 'awebooking-user-profile' ); ?></h3>
		
		<div class="awebooking-field">
			<label><?php esc_html_e( 'First Name', 'awebooking-user-profile' ); ?> <abbr class="required" title="required">*</abbr></label>
			<input type="text" name="customer_first_name" class="awebooking-input" required="required" value="<?php echo esc_attr( isset( $_POST['customer_first_name'] ) ? $_POST['customer_first_name'] : $user->customer_first_name  ) ?>">
		</div>

		<div class="awebooking-field">
			<label><?php esc_html_e( 'Last Name', 'awebooking-user-profile' ); ?> <abbr class="required" title="required">*</abbr></label>
			<input type="text" name="customer_last_name" class="awebooking-input" required="required" value="<?php echo esc_attr( isset( $_POST['customer_last_name'] ) ? $_POST['customer_last_name'] : $user->customer_last_name  ) ?>">
		</div>

		<div class="awebooking-field">
			<label><?php esc_html_e( 'Email Address', 'awebooking-user-profile' ); ?> <abbr class="required" title="required">*</abbr></label>
			<input type="email" name="customer_email" class="awebooking-input" required="required" value="<?php echo esc_attr( isset( $_POST['customer_email'] ) ? $_POST['customer_email'] : $user->customer_email  ) ?>">
		</div>

		<div class="awebooking-field">
			<label><?php esc_html_e( 'Phone', 'awebooking-user-profile' ); ?> <abbr class="required" title="required">*</abbr></label>
			<input type="text" name="customer_phone" class="awebooking-input" required="required" value="<?php echo esc_attr( isset( $_POST['customer_phone'] ) ? $_POST['customer_phone'] : $user->customer_phone  ) ?>">
		</div>

		<div class="awebooking-field">
			<label><?php esc_html_e( 'Company Name', 'awebooking-user-profile' ); ?></label>
			<input type="text" name="customer_company" class="awebooking-input" value="<?php echo esc_attr( isset( $_POST['customer_company'] ) ? $_POST['customer_company'] : $user->customer_company  ) ?>">
		</div>
	</div>
	
	<?php do_action( "awebooking\user\after_form_edit_booking" ); ?>

	<div>
		<button type="submit" class="button" name="save_address"><?php esc_attr_e( 'Save change', 'awebooking-user-profile' ); ?></button>
		<?php wp_nonce_field( 'awebooking_user_edit_booking' ); ?>
		<input type="hidden" name="action" value="edit-booking" />
	</div>

</form>

<?php
do_action( 'awebooking\user\after_edit_booking' );
