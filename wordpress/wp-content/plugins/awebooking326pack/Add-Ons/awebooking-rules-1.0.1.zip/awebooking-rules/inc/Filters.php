<?php
namespace AweBooking\Rules;

use AweBooking\Rules\Rules\Filters as Query_Builer_Filters;

class Filters implements Query_Builer_Filters {
	/* Constants */
	const VALUE_SEPARATOR = ',';
	const JS_DATE_FORMAT  = 'YYYY-MM-DD';

	/**
	 * The filters.
	 *
	 * @var array
	 */
	protected $filters = [];

	/**
	 * The groups.
	 *
	 * @var array
	 */
	protected $groups = [];

	/**
	 * List operators frequent use.
	 *
	 * @var array
	 */
	public static $operators = [
		'date'    => [ 'equal', 'not_equal', 'less', 'less_or_equal', 'greater', 'greater_or_equal', 'between', 'not_between' ],
		'integer' => [ 'equal', 'not_equal', 'in', 'not_in', 'less', 'less_or_equal', 'greater', 'greater_or_equal', 'between', 'not_between' ],
		'choices' => [ 'in', 'not_in' ],
	];

	/**
	 * Constructor.
	 *
	 * @param array $filters The filters.
	 * @param array $groups  The groups.
	 */
	public function __construct( $filters = [], $groups = [] ) {
		$this->filters = $filters;
		$this->groups  = $groups;
	}

	/**
	 * Add a group into the list.
	 *
	 * @param string $key   The group key name.
	 * @param string $label The group label.
	 *
	 * @return $this
	 */
	public function add_group( $key, $label ) {
		$this->groups[ $key ] = $label;

		return $this;
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_groups() {
		return $this->groups;
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_filters() {
		return $this->filters;
	}

	/**
	 * Merge default filters & groups.
	 *
	 * @return $this
	 */
	public function with_defaults() {
		$this->groups  = array_unique(
			array_merge( $this->get_default_groups(), $this->groups )
		);

		$this->filters = abrs_collect( $this->get_default_filters() )
			->merge( $this->filters )
			->unique( 'id' )
			->all();

		return $this;
	}

	/**
	 * Returns the default groups.
	 *
	 * @return array
	 */
	public function get_default_groups() {
		return [
			'basic' => esc_html__( 'Reservation', 'awebooking-rules' ),
			'guest' => esc_html__( 'Guest', 'awebooking-rules' ),
		];
	}

	/**
	 * Returns the default filters.
	 *
	 * @return array
	 */
	public function get_default_filters() {
		global $wp_locale;

		return [
			[
				'id'              => 'booking_date',
				'label'           => esc_html__( 'Booking date', 'awebooking-rules' ),
				'type'            => 'date',
				'input'           => 'text',
				'optgroup'        => 'basic',
				// 'default_value'   => Carbonate::today()->toDateString(),
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['date'],
				'validation'      => [
					'format' => static::JS_DATE_FORMAT,
					'allow_empty_value' => false,
				],
			],
			[
				'id'              => 'check_in_date',
				'label'           => esc_html__( 'Check-in date', 'awebooking-rules' ),
				'type'            => 'date',
				'input'           => 'text',
				'optgroup'        => 'basic',
				// 'default_value'   => Carbonate::today()->toDateString(),
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['date'],
				'validation'      => [
					'format' => static::JS_DATE_FORMAT,
					'allow_empty_value' => false,
				],
			],
			[
				'id'              => 'check_out_date',
				'label'           => esc_html__( 'Check-out date', 'awebooking-rules' ),
				'type'            => 'date',
				'input'           => 'text',
				'optgroup'        => 'basic',
				// 'default_value'   => Carbonate::today()->toDateString(),
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['date'],
				'validation'      => [
					'format' => static::JS_DATE_FORMAT,
					'allow_empty_value' => false,
				],
			],
			[
				'id'              => 'booking_before',
				'type'            => 'integer',
				'input'           => 'text',
				'optgroup'        => 'basic',
				'label'           => esc_html__( 'Booking before days', 'awebooking-rules' ),
				'default_value'   => 1,
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['integer'],
				'validation'      => [
					'min' => 0,
					'step' => 1,
					'allow_empty_value' => false,
				],
			],
			[
				'id'        => 'check_in',
				'label'     => esc_html__( 'Check-in day', 'awebooking-rules' ),
				'type'      => 'integer',
				'input'     => 'checkbox',
				'optgroup'  => 'basic',
				'values'    => (object) $wp_locale->weekday,
				'operators' => static::$operators['choices'],
			],
			[
				'id'        => 'check_out',
				'label'     => esc_html__( 'Check-out day', 'awebooking-rules' ),
				'type'      => 'integer',
				'input'     => 'checkbox',
				'optgroup'  => 'basic',
				'values'    => (object) $wp_locale->weekday,
				'operators' => static::$operators['choices'],
			],
			[
				'id'              => 'stay_nights',
				'label'           => esc_html__( 'Stay nights', 'awebooking-rules' ),
				'type'            => 'integer',
				'input'           => 'text',
				'optgroup'        => 'basic',
				'default_value'   => 2,
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['integer'],
				'validation'      => [
					'min'  => 1,
					'step' => 1,
					'allow_empty_value' => false,
				],
			],
			/*[
				'id'              => 'payment_gateway',
				'label'           => esc_html__( 'Payment Gateway', 'awebooking-rules' ),
				'type'            => 'string',
				'input'           => 'select',
				'optgroup'        => 'basic',
				'values'          => abrs_list_payment_methods(),
				'multiple'        => true,
				'default_value'   => '',
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['choices'],
			],*/
			[
				'id'              => 'number_adults',
				'type'            => 'integer',
				'input'           => 'text',
				'optgroup'        => 'guest',
				'label'           => esc_html__( 'Adults', 'awebooking-rules' ),
				'default_value'   => 1,
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['integer'],
				'validation'      => [
					'min'  => 1,
					'step' => 1,
					'allow_empty_value' => false,
				],
			],
			[
				'id'              => 'number_children',
				'type'            => 'integer',
				'input'           => 'text',
				'optgroup'        => 'guest',
				'label'           => esc_html__( 'Children', 'awebooking-rules' ),
				'default_value'   => 1,
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['integer'],
				'validation'      => [
					'min'  => 0,
					'step' => 1,
					'allow_empty_value' => false,
				],
			],
			[
				'id'              => 'number_people',
				'type'            => 'integer',
				'input'           => 'text',
				'optgroup'        => 'guest',
				'label'           => esc_html__( 'People', 'awebooking-rules' ),
				'default_value'   => 1,
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['integer'],
				'validation'      => [
					'min'  => 1,
					'step' => 1,
					'allow_empty_value' => false,
				],
			],
			/*[
				'id'              => 'overflow_adults',
				'type'            => 'integer',
				'input'           => 'text',
				'optgroup'        => 'guest',
				'label'           => esc_html__( 'Overflow adults', 'awebooking-rules' ),
				'default_value'   => 1,
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['integer'],
				'validation'      => [
					'min'  => 1,
					'step' => 1,
					'allow_empty_value' => false,
				],
			],
			[
				'id'              => 'overflow_children',
				'type'            => 'integer',
				'input'           => 'text',
				'optgroup'        => 'guest',
				'label'           => esc_html__( 'Overflow children', 'awebooking-rules' ),
				'default_value'   => 1,
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['integer'],
				'validation'      => [
					'min'  => 1,
					'step' => 1,
					'allow_empty_value' => false,
				],
			],
			[
				'id'              => 'overflow_people',
				'type'            => 'integer',
				'input'           => 'text',
				'optgroup'        => 'guest',
				'label'           => esc_html__( 'Overflow people', 'awebooking-rules' ),
				'default_value'   => 1,
				'value_separator' => static::VALUE_SEPARATOR,
				'operators'       => static::$operators['integer'],
				'validation'      => [
					'min'  => 1,
					'step' => 1,
					'allow_empty_value' => false,
				],
			],*/
		]; // End.
	}
}
