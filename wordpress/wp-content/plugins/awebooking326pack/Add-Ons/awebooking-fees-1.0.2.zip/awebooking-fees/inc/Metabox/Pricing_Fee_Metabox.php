<?php
namespace AweBooking\Fees\Metabox;

class Pricing_Fee_Metabox {

}
