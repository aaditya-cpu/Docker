<?php
namespace AweBooking\WooCommerce;

class Product_Booking_Room extends \WC_Product {
	/**
	 * Booking room-type instance.
	 *
	 * @var Room_Type
	 */
	protected $room_type;

	/**
	 * Constructor.
	 *
	 * @param mixed $room_type //.
	 */
	public function __construct() {
	}

	/**
	 * Get internal type.
	 *
	 * @return string
	 */
	public function get_type() {
		return 'awebooking';
	}

	/**
	 * Bookings can always be purchased regardless of price.
	 *
	 * @return true
	 */
	public function is_purchasable() {
		return true;
	}

	/**
	 * This is virtual product (has no shipping).
	 *
	 * @return true
	 */
	public function is_virtual() {
		return true;
	}

	/**
	 * We want to sell bookings one at a time (no quantities).
	 *
	 * @return boolean
	 */
	public function is_sold_individually() {
		return false;
	}

	/**
	 * Returns whether or not the product post exists.
	 *
	 * @return bool
	 */
	public function exists() {
		return true;
	}

	/**
	 * Return the stock status (for this, it alway instock).
	 *
	 * @param  string $context The context, default 'view'.
	 *
	 * @return string
	 */
	public function get_stock_status( $context = 'view' ) {
		return 'instock';
	}

	/**
	 * Returns booking room type name.
	 *
	 * @param  string $context The context, default 'view'.
	 *
	 * @return string
	 */
	public function get_name( $context = 'view' ) {
		return sprintf( esc_html__( 'Pay at %s', 'awebooking-woocommerce' ), abrs_get_option( 'hotel_name' ) ?: get_bloginfo( 'name' ) );
	}

	/**
	 * Get product price.
	 *
	 * @param  string $context The context, default 'view'.
	 *
	 * @return float
	 */
	public function get_price( $context = 'view' ) {
		return abrs_reservation()->get_total();
	}
}
