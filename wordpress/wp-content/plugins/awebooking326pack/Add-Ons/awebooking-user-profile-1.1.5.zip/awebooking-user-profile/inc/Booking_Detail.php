<?php

namespace AweBooking\User_Profile;

use AweBooking\Model\Booking;
use AweBooking\Support\Date_Period;

class Booking_Detail extends Booking {
	public function get_status_label() {
		return abrs_get_booking_status_name( $this->get_status() );
	}

	public function booking_detail_status() {
		$status_color = '';
		$status_label = $this->get_status_label();

		switch ( $this->get_status() ) {
			case 'pending':
				$status_color = 'awebooking-label--info';
				break;
			case 'inprocess':
				$status_color = 'awebooking-label--warning';
				break;
			case 'cancelled':
				$status_color = 'awebooking-label--danger';
				break;
			case 'completed':
				$status_color = 'awebooking-label--success';
				break;
		}

		echo apply_filters( 'awebooking\ser\get_booking_status',
			sprintf( '<span class="awebooking-label %2$s">%1$s</span>', $status_label, $status_color ), $status_label,
			$status_color );
	}

	public function booking_detail_total() {
		$html = abrs_format_price( $this->get_total() );

		if ( $this['payment_method_title'] ) {
			$html .= '<small class="meta">' . esc_html__( 'Via', 'awebooking-user-profile' ) . ' ' . esc_html( $this->get_payment_method_title() ) . '</small>';
		}

		echo apply_filters( 'awebooking\user\get_booking_total', $html );
	}
}
