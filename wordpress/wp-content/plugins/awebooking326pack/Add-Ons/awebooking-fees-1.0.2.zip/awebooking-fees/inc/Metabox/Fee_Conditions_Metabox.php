<?php
namespace AweBooking\Fees\Metabox;

use AweBooking\Admin\Metabox;
use Awethemes\Http\Request;

class Fee_Conditions_Metabox extends Metabox {
	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id       = 'awebooking-fee-conditions';
		$this->title    = esc_html__( 'Conditions', 'awebooking-fees' );
		$this->screen   = 'hotel_fee';
		$this->priority = 'default';
	}

	/**
	 * Output the metabox.
	 *
	 * @param \WP_Post $post The WP_Post object.
	 */
	public function output( $post ) {
		if ( ! defined( 'AWEBOOKING_RULES_VERSION' ) ) {
			echo '<div class="abrs-ptb1 abrs-text-center"><p>' . esc_html__( 'Please install or activate the "awebooking-rules" to use the conditions.', 'awebooking-fees' ) . '</p></div>';
			return;
		}

		wp_enqueue_style( 'awebooking-rules' );
		wp_enqueue_script( 'awebooking-rules' );

		$value = get_post_meta( $post->ID, '_fee_conditions', true );

		echo '<div class="awebooking-rules" data-init="awebooking-rules">';
		echo '<input type="hidden" name="conditions" value="' . esc_attr( json_encode( $value ) ) . '">';
		echo '</div>';
	}

	/**
	 * Handle save the the metabox.
	 *
	 * @param \WP_Post                $post    The WP_Post object instance.
	 * @param \Awethemes\Http\Request $request The HTTP Request.
	 */
	public function save( $post, Request $request ) {
		if ( ! defined( 'AWEBOOKING_RULES_VERSION' ) ) {
			return;
		}

		$data = wp_unslash( $request->get( 'conditions' ) );
		$data = abrs_sanitize_rules( json_decode( $data, true ) );

		update_post_meta( $post->ID, '_fee_conditions', $data );
	}
}
