<?php
/**
 * Account navigation
 *
 * @author        Awethemes <awethemes.com>
 * @package       AweBooking\User
 * @since         1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'awebooking\user\before_account_navigation' );
?>
	<nav class="awebooking_user-account-navigation">
		<ul>
			<?php foreach ( awebooking_user_get_account_menu_items() as $endpoint => $arr ) : ?>
				<li class="<?php echo awebooking_user_get_account_menu_item_classes( $endpoint ); ?>">
					<a href="<?php echo esc_url( awebooking_user_get_account_endpoint_url( $endpoint ) ); ?>">
						<?php echo esc_html( $arr['label'] ); ?>
					</a>
					<?php do_action( 'awebooking\user\menu_item_after_' . $endpoint, $endpoint ) ?>
				</li>
			<?php endforeach; ?>
		</ul>
	</nav>
<?php
do_action( 'awebooking\user\after_account_navigation' );
