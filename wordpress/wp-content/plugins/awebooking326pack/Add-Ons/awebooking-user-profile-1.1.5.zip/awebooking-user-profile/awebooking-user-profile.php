<?php
/**
 * Plugin Name:     AweBooking User Profile
 * Plugin URI:      http://awethemes.com/plugins/awebooking
 * Description:     Customers can manage log-in credentials, personal information and more in their own profile page. Even more, they can check and manage their bookings quickly and easily
 * Author:          awethemes
 * Author URI:      http://awethemes.com
 * Text Domain:     awebooking-user-profile
 * Domain Path:     /languages
 * Version:         1.1.5
 *
 * @package         AweBooking/User_Profile
 */

define( 'AWEBOOKING_USER_PROFILE_URL', plugin_dir_url( __FILE__ ) );
define( 'AWEBOOKING_USER_PROFILE_DIR', plugin_dir_path( __FILE__ ) );
define( 'AWEBOOKING_USER_PROFILE_VERSION', '1.1.5' );

add_action( 'awebooking_init', function ( $awebooking ) {
	require __DIR__ . '/vendor/autoload.php';
	require __DIR__ . '/inc/Core/functions.php';

	$awebooking->provider( \AweBooking\User_Profile\Service_Provider::class );
} );

function awebooking_user() {
	static $object;

	if ( ! $object ) {
		$object        = new stdClass();
		$object->query = awebooking( \AweBooking\User_Profile\Query::class );
	}

	return $object;
}
