<?php
/**
 * User new account email template.
 *
 * @see      http://docs.awethemes.com/awebooking/developers/theme-developers/
 * @author   awethemes
 * @package  AweBooking
 * @version  3.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abrs_mailer()->header( $email );

?>

<p><?php printf( __( 'Thanks for creating an account on %s. Your username is <strong>%s</strong>', 'awebooking-user-profile' ), esc_html( $email->get_blogname() ), esc_html( $user_login ) ); ?></p>

<p><?php printf( __( 'You can access your account area to view your orders and change your password here: %s.', 'awebooking-user-profile' ), make_clickable( esc_url( awebooking_user_get_page_permalink( 'user-profile' ) ) ) ); ?></p>

<?php abrs_mailer()->footer( $email );
