<?php

use AweBooking\Rules\Rules\Parser;
use AweBooking\Rules\Rules\Sanitizer;
use AweBooking\Reservation\Reservation;
use AweBooking\Component\Ruler\Context;

/**
 * Parse the rules.
 *
 * @param array $rules   The rules.
 * @param null  $filters Optional, the fillters.
 *
 * @return \AweBooking\Component\Ruler\Rule
 */
function abrs_parse_rules( $query, $filters = null ) {
	if ( ! is_array( $query ) ) {
		return null;
	}

	try {
		return ( new Parser( $filters ) )->parse( $query );
	} catch ( \Exception $e ) {
		return null;
	}
}

/**
 * Sanitize the rules.
 *
 * @param array $rules   The rules.
 * @param null  $filters Optional, the fillters.
 *
 * @return array|null
 */
function abrs_sanitize_rules( $rules, $filters = null ) {
	if ( ! is_array( $rules ) ) {
		return null;
	}

	return ( new Sanitizer( $filters ) )->sanitize( $rules );
}

/**
 * Gets a array of JSQueryBuilder translation strings.
 *
 * @see http://querybuilder.js.org/index.html#options
 *
 * @return array
 */
function abrs_get_query_builder_i18n() {
	return [
		'add_rule'     => esc_html__( 'Add rule', 'awebooking-rules' ),
		'add_group'    => esc_html__( 'Add group', 'awebooking-rules' ),
		'delete_rule'  => esc_html__( 'Delete', 'awebooking-rules' ),
		'delete_group' => esc_html__( 'Delete', 'awebooking-rules' ),
		'invert'       => esc_html__( 'Invert', 'awebooking-rules' ),
		'NOT'          => esc_html__( 'NOT', 'awebooking-rules' ),
		'conditions' => [
			'AND'      => esc_html__( 'AND', 'awebooking-rules' ),
			'OR'       => esc_html__( 'OR', 'awebooking-rules' ),
		],
		'operators' => [
			'equal'            => esc_html__( 'equal', 'awebooking-rules' ),
			'not_equal'        => esc_html__( 'not equal', 'awebooking-rules' ),
			'in'               => esc_html__( 'in', 'awebooking-rules' ),
			'not_in'           => esc_html__( 'not in', 'awebooking-rules' ),
			'less'             => esc_html__( 'less', 'awebooking-rules' ),
			'less_or_equal'    => esc_html__( 'less or equal', 'awebooking-rules' ),
			'greater'          => esc_html__( 'greater', 'awebooking-rules' ),
			'greater_or_equal' => esc_html__( 'greater or equal', 'awebooking-rules' ),
			'between'          => esc_html__( 'between', 'awebooking-rules' ),
			'not_between'      => esc_html__( 'not between', 'awebooking-rules' ),
			'begins_with'      => esc_html__( 'begins with', 'awebooking-rules' ),
			'not_begins_with'  => esc_html__( 'doesn\'t begin with', 'awebooking-rules' ),
			'contains'         => esc_html__( 'contains', 'awebooking-rules' ),
			'not_contains'     => esc_html__( 'doesn\'t contain', 'awebooking-rules' ),
			'ends_with'        => esc_html__( 'ends with', 'awebooking-rules' ),
			'not_ends_with'    => esc_html__( 'doesn\'t end with', 'awebooking-rules' ),
			'is_empty'         => esc_html__( 'is empty', 'awebooking-rules' ),
			'is_not_empty'     => esc_html__( 'is not empty', 'awebooking-rules' ),
			'is_null'          => esc_html__( 'is null', 'awebooking-rules' ),
			'is_not_null'      => esc_html__( 'is not null', 'awebooking-rules' ),
		],
		'errors' => [
			'no_filter'                => esc_html__( 'No filter selected', 'awebooking-rules' ),
			'empty_group'              => esc_html__( 'The group is empty', 'awebooking-rules' ),
			'radio_empty'              => esc_html__( 'No value selected', 'awebooking-rules' ),
			'checkbox_empty'           => esc_html__( 'No value selected', 'awebooking-rules' ),
			'select_empty'             => esc_html__( 'No value selected', 'awebooking-rules' ),
			'string_empty'             => esc_html__( 'Empty value', 'awebooking-rules' ),
			'string_exceed_min_length' => esc_html__( 'Must contain at least {0} characters', 'awebooking-rules' ),
			'string_exceed_max_length' => esc_html__( 'Must not contain more than {0} characters', 'awebooking-rules' ),
			'string_invalid_format'    => esc_html__( 'Invalid format ({0})', 'awebooking-rules' ),
			'number_nan'               => esc_html__( 'Not a number', 'awebooking-rules' ),
			'number_not_integer'       => esc_html__( 'Not an integer', 'awebooking-rules' ),
			'number_not_double'        => esc_html__( 'Not a real number', 'awebooking-rules' ),
			'number_exceed_min'        => esc_html__( 'Must be greater than {0}', 'awebooking-rules' ),
			'number_exceed_max'        => esc_html__( 'Must be lower than {0}', 'awebooking-rules' ),
			'number_wrong_step'        => esc_html__( 'Must be a multiple of {0}', 'awebooking-rules' ),
			'datetime_empty'           => esc_html__( 'Empty value', 'awebooking-rules' ),
			'datetime_invalid'         => esc_html__( 'Invalid date format ({0})', 'awebooking-rules' ),
			'datetime_exceed_min'      => esc_html__( 'Must be after {0}', 'awebooking-rules' ),
			'datetime_exceed_max'      => esc_html__( 'Must be before {0}', 'awebooking-rules' ),
			'boolean_not_valid'        => esc_html__( 'Not a boolean', 'awebooking-rules' ),
			'operator_not_multiple'    => esc_html__( 'Operator "{1}" cannot accept multiple values', 'awebooking-rules' ),
		],
	];
}

/**
 * Create rules context from the reservation.
 *
 * @param \AweBooking\Reservation\Reservation $reservation The reservation instance.
 * @return \AweBooking\Component\Ruler\Context
 *
 * @throws \RuntimeException
 */
function abrs_create_rules_context( Reservation $reservation ) {
	$res_request = $reservation->resolve_res_request();

	if ( ! $res_request ) {
		throw new \RuntimeException( 'Unable resolve the reservation request' );
	}

	$today      = abrs_date( 'today' );
	$start_date = abrs_date( $res_request->get_timespan()->get_start_date() );
	$end_date   = abrs_date( $res_request->get_timespan()->get_end_date() );

	return new Context( [
		'booking_date'      => $today,
		'check_in_date'     => $start_date,
		'check_out_date'    => $end_date,
		'booking_before'    => $today->diffInDays( $start_date ),
		'check_in'          => $start_date->dayOfWeek,
		'check_out'         => $end_date->dayOfWeek,
		'stay_nights'       => $res_request->get( 'nights' ),
		'number_adults'     => $res_request->get( 'adults' ),
		'number_children'   => $res_request->get( 'children' ),
		'number_people'     => $res_request->get( 'adults' ) + $res_request->get( 'children' ),
		// 'overflow_adults'   => $reservation->get( 'adults' ) + $reservation->get( 'adults' ),
		// 'overflow_children' => $reservation->get( 'adults' ) + $reservation->get( 'adults' ),
		// 'overflow_people'   => $reservation->get( 'adults' ) + $reservation->get( 'adults' ),
	] );
}
