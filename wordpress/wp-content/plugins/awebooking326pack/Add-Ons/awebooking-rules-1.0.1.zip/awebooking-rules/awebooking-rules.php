<?php
/**
 * Plugin Name:     Awebooking Rules
 * Plugin URI:      http://awethemes.com/plugins/awebooking
 * Description:     Build complex rules for pricing and availability.
 * Author:          awethemes
 * Author URI:      http://awethemes.com
 * Text Domain:     awebooking-rules
 * Domain Path:     /languages
 * Version:         1.0.1
 *
 * @package         Awebooking/Rules
 */

if ( ! defined( 'AWEBOOKING_RULES_VERSION' ) ) {
	require trailingslashit( __DIR__ ) . 'vendor/autoload.php';
	require trailingslashit( __DIR__ ) . 'inc/functions.php';

	/* Define the premium constant */
	if ( ! defined( 'ABRS_PREMIUM' ) ) {
		define( 'ABRS_PREMIUM', true );
	}

	/* Constants */
	define( 'AWEBOOKING_RULES_VERSION', '1.0.1' );
	define( 'AWEBOOKING_RULES_PLUGIN_FILE', __FILE__ );
	define( 'AWEBOOKING_RULES_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
	define( 'AWEBOOKING_RULES_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

	add_action( 'awebooking_init', function( $plugin ) {
		/* @var \AweBooking\Plugin $plugin */
		$plugin->provider( \AweBooking\Rules\Service_Provider::class );
	});
}
