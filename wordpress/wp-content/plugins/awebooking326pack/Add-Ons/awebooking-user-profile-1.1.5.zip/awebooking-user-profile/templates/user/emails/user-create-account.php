<?php
/**
 * User new account email template.
 *
 * @see      http://docs.awethemes.com/awebooking/developers/theme-developers/
 * @author   awethemes
 * @package  AweBooking
 * @version  3.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abrs_mailer()->header( $email );

?>
<p><?php printf( __( 'Thanks for creating an account on %s. Your username is <strong>%s</strong>', 'awebooking-user-profile' ), esc_html( $email->get_blogname() ), esc_html( $user_login ) ); ?></p>

<?php /* translators: %s Auto generated password */ ?>
<p><?php printf( esc_html__( 'Your password has been automatically generated: %s', 'awebooking-user-profile' ), '<strong></br>' . esc_html( $user_pass ) . '</strong>' ); ?></p>

<p><?php esc_html_e( 'We look forward to seeing you soon.', 'awebooking-user-profile' ); ?></p>

<?php abrs_mailer()->footer( $email );
