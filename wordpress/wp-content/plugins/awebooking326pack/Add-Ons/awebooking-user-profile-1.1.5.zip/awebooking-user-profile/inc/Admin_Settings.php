<?php

namespace AweBooking\User_Profile;

use AweBooking\Support\WP_Data;
use AweBooking\Admin\Settings\Abstract_Setting;

class Admin_Settings extends Abstract_Setting {
	/**
	 * {@inheritdoc}
	 */
	protected function setup() {
		$this->form_id = 'user_profile';
		$this->label   = esc_html__( 'User Profile', 'awebooking' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function setup_fields() {
		$this->add_field( [
			'id'       => 'user_page_group',
			'type'     => 'title',
			'name'     => esc_html__( 'Page Settings', 'awebooking-user-profile' ),
			'priority' => 10,
		] );

		$this->add_field( [
			'id'               => 'user_page_id',
			'type'             => 'select',
			'name'             => esc_html__( 'User Profile page', 'awebooking-user-profile' ),
			'description'      => esc_html__( 'Selected page to display user profile.', 'awebooking-user-profile' ),
			'default'          => '',
			'options_cb'       => WP_Data::cb( 'pages', [ 'post_status' => 'publish' ] ),
			'validate'         => 'integer',
			'priority'         => 10,
			'show_option_none' => true,
		] );

		$this->add_field( [
			'id'          => 'user_enpoint_group',
			'type'        => 'title',
			'name'        => esc_html__( 'Enpoint Settings', 'awebooking-user-profile' ),
			'priority'    => 10,
			'description' => esc_html__( 'Endpoints are appended to your page URLs to handle specific actions on the accounts pages. They should be unique and can be left blank to disable the endpoint.',
				'awebooking-user-profile' ),
		] );

		$this->add_field( [
			'id'      => 'user_enpoint_profile',
			'type'    => 'text',
			'name'    => esc_html__( 'Profile', 'awebooking-user-profile' ),
			'default' => 'profile',
		] );

		$this->add_field( [
			'id'      => 'user_enpoint_lost_password',
			'type'    => 'text',
			'name'    => esc_html__( 'Lost Password', 'awebooking-user-profile' ),
			'default' => 'lost-password',
		] );

		$this->add_field( [
			'id'      => 'user_enpoint_edit_booking',
			'type'    => 'text',
			'name'    => esc_html__( 'Edit User Booking', 'awebooking-user-profile' ),
			'default' => 'edit-booking',
		] );

		$this->add_field( [
			'id'      => 'user_enpoint_order',
			'type'    => 'text',
			'name'    => esc_html__( 'Bookings', 'awebooking-user-profile' ),
			'default' => 'orders',
		] );

		$this->add_field( [
			'id'      => 'user_enpoint_view_booking',
			'type'    => 'text',
			'name'    => esc_html__( 'View Booking detail', 'awebooking-user-profile' ),
			'default' => 'view-booking',
		] );

		$this->add_field( [
			'id'      => 'user_enpoint_user_logout',
			'type'    => 'text',
			'name'    => esc_html__( 'User logout', 'awebooking-user-profile' ),
			'default' => 'user-logout',
		] );

		// Checkout settings.
		$this->add_field( [
			'id'       => 'user_checkout_group',
			'type'     => 'title',
			'name'     => esc_html__( 'Checkout Settings', 'awebooking-user-profile' ),
			'priority' => 10,
		] );

		$this->add_field( [
			'id'          => 'user_checkout_guest',
			'type'        => 'abrs_toggle',
			'name'        => esc_html__( 'Enable guest checkout', 'awebooking-user-profile' ),
			'description' => esc_html__( 'Allows customers to checkout without creating an account.', 'awebooking-user-profile' ),
			'default'     => 'on',
		] );

		$this->add_field( [
			'id'          => 'user_signup_and_login_from_checkout',
			'type'        => 'abrs_toggle',
			'name'        => esc_html__( 'Account creation', 'awebooking-user-profile' ),
			'description' => esc_html__( 'Allow customers to create an account during checkout', 'awebooking-user-profile' ),
			'default'     => 'on',
			'show_on_cb'  => function () {
				return 'on' === abrs_get_option( 'user_checkout_guest' );
			},
		] );
	}
}
