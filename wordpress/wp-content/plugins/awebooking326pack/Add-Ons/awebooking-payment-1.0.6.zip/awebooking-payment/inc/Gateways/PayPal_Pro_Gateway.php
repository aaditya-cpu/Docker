<?php
namespace AweBooking\Payment\Gateways;

use Awethemes\Http\Request;
use AweBooking\Model\Booking;

class PayPal_Pro_Gateway extends Omnipay_Gateway {
	/**
	 * The gateway unique ID.
	 *
	 * @var string
	 */
	protected $method = 'paypal_pro';

	/**
	 * The extra metadata this gateway support.
	 *
	 * @var array
	 */
	public $supports = [ 'transaction_id', 'card' ];

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->method_title       = esc_html__( 'PayPal Pro', 'awebooking-payment' );
		$this->method_description = esc_html__( 'Allows take credit card payments via PayPal directly on your site. SSL Certificate required.', 'awebooking-payment' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function setup() {
		$this->setting_fields();

		$this->enabled     = $this->get_option( 'enabled' );
		$this->title       = esc_html( $this->get_option( 'title' ) );
		$this->description = esc_textarea( $this->get_option( 'description' ) );

		$this->gateway = $this->create_gateway( 'PayPal_Pro', [
			'username'  => $this->get_option( 'api_username' ),
			'password'  => $this->get_option( 'api_password' ),
			'signature' => $this->get_option( 'api_signature' ),
			'testMode'  => 'on' === $this->get_option( 'sandbox', 'off' ),
		]);
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_purchase_parameters( Booking $booking, Request $request ) {
		return [
			'card'       => $this->get_card( $request ),
			'noShipping' => true,
		];
	}

	/**
	 * Set the gateway settings fields.
	 *
	 * @return void
	 */
	protected function setting_fields() {
		$this->setting_fields = [
			'enabled'       => [
				'name'    => esc_html__( 'Enable / Disable', 'awebooking-payment' ),
				'type'    => 'toggle',
				'label'   => esc_html__( 'Enable check payments', 'awebooking-payment' ),
				'default' => 'off',
			],
			'title'         => [
				'name'        => esc_html__( 'Title', 'awebooking-payment' ),
				'type'        => 'text',
				'description' => esc_html__( 'This controls the title which the user sees during checkout.', 'awebooking-payment' ),
				'default'     => _x( 'PayPal', 'PayPal payment method', 'awebooking-payment' ),
			],
			'description'   => [
				'name'        => esc_html__( 'Description', 'awebooking-payment' ),
				'type'        => 'textarea',
				'description' => esc_html__( 'Payment method description that the customer will see on your checkout.', 'awebooking-payment' ),
				'default'     => esc_html__( 'Pay via PayPal. You can pay with your credit card if you dont have a PayPal account.', 'awebooking-payment' ),
			],
			'sandbox'       => [
				'type'    => 'toggle',
				'name'    => esc_html__( 'PayPal Sandbox', 'awebooking-payment' ),
				'default' => 'off',
			],
			'api_username'  => [
				'type' => 'text',
				'name' => esc_html__( 'API Username', 'awebooking-payment' ),
			],
			'api_password'  => [
				'type'       => 'text',
				'name'       => esc_html__( 'API Password', 'awebooking-payment' ),
				'attributes' => [ 'type' => 'password' ],
			],
			'api_signature' => [
				'type' => 'text',
				'name' => esc_html__( 'API Signature', 'awebooking-payment' ),
			],
		];
	}
}
