<?php
namespace AweBooking\MailChimp;

class Service_Provider extends \AweBooking\Support\Service_Provider {
	/**
	 * Registers services on the plugin.
	 *
	 * @return void
	 */
	public function register() {
		$this->plugin->tag( Setting::class, 'setting.checkout' );

		$this->plugin->singleton( 'mailchimp', function () {
			return new MailChimp( $this->plugin->get_option( 'mailchimp_api_key' ) );
		} );
	}

	/**
	 * Init service provider.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'abrs_before_submit_button', [ $this, 'display_checkbox' ] );
		add_action( 'abrs_checkout_processed', [ $this, 'handle_subscribe' ] );

		$this->mailchimp = new MailChimp( abrs_get_option( 'mailchimp_control_api_key' ) );
		$this->list_id = abrs_get_option( 'mailchimp_control_list_mail' );
	}

	/**
	 * Create checkbox subcribes.
	 *
	 * @return void
	 */
	public function display_checkbox() {
		if ( 'off' === abrs_get_option( 'mailchimp_control_enable' ) || ! abrs_get_option( 'mailchimp_list_mail' ) ) {
			return;
		}

		?><div class="subscribe-mailchimp">
			<input type="checkbox" id="subscribe_mailchimp" name="subscribe_mailchimp" value="1" <?php echo 'on' === abrs_get_option( 'mailchimp_checked_default', 'off' ) ? 'checked="checked"' : ''; ?>>
			<label for="subscribe_mailchimp"><?php echo esc_html( abrs_get_option( 'mailchimp_checkbox_label_text' ) ?: esc_html__( 'Subscribe Us!', 'awebooking-mailchimp' ) ) ; ?></label>
		</div><?php // @codingStandardsIgnoreLine
	}

	/**
	 * Handle the subscribe.
	 *
	 * @param int $booking_id The booking ID.
	 * @return void
	 */
	public function handle_subscribe( $booking_id ) {
		if ( 'off' === abrs_get_option( 'mailchimp_control_enable' ) ) {
			return;
		}

		$request = abrs_http_request();
		if ( ! $request->filled( 'subscribe_mailchimp' ) ) {
			return;
		}

		$booking = abrs_get_booking( $booking_id );

		$subscribed = awebooking( 'mailchimp' )->subscribe(
			$booking->get( 'customer_email' ),
			abrs_get_option( 'mailchimp_list_mail' ),
			[
				'merge_fields' => [
					'FNAME' => $booking->get( 'customer_first_name' ),
					'LNAME' => $booking->get( 'customer_last_name' ),
				],
			]
		);
	}
}
