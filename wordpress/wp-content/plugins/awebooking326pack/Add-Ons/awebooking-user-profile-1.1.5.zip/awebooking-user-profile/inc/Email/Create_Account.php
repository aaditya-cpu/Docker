<?php

namespace AweBooking\User_Profile\Email;

use AweBooking\Email\Mailable;

class Create_Account extends Mailable {
	/**
	 * The user data.
	 *
	 * @var \WP_User
	 */
	protected $user;

	/**
	 * The user password.
	 *
	 * @var $user_pass
	 */
	protected $user_pass;

	/**
	 * {@inheritdoc}
	 */
	public function setup() {
		$this->id             = 'create_account';
		$this->title          = esc_html__( 'Create account', 'awebooking-user-profile' );
		$this->description    = esc_html__( 'User created emails are sent to user when their bookings are created.', 'awebooking-user-profile' );
		$this->customer_email = true;
		$this->placeholders   = [];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function prepare_data( $customer_id, $new_customer_data ) {
		if ( $user = get_user_by( 'ID', $customer_id ) ) {
			$this->user      = $user;
			$this->user_pass = ! empty( $new_customer_data['user_pass'] ) ? $new_customer_data['user_pass'] : '';
			$this->recipient = $user->user_email;
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_subject() {
		return esc_html__( 'Your {site_title} username and password', 'awebooking-user-profile' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_heading() {
		return esc_html__( 'Account info', 'awebooking-user-profile' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_content_html() {
		return awebooking_user_get_template( 'user/emails/user-create-account.php', [
			'email'      => $this,
			'content'    => $this->format_string( $this->get_option( 'content' ) ),
			'user_login' => $this->user->user_login,
			'user_pass'  => $this->user_pass,
		] );
	}
}
