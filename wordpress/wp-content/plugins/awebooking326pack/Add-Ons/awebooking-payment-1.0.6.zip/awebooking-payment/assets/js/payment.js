(function () {
  'use strict';

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  var Gateway = function ($) {
    var Gateway =
    /*#__PURE__*/
    function () {
      function Gateway() {
        _classCallCheck(this, Gateway);

        this.card = void 0;
        Gateway.register(this.getName(), this);
      }

      _createClass(Gateway, [{
        key: "on",
        value: function on(e) {}
      }, {
        key: "off",
        value: function off() {}
      }, {
        key: "setup",
        value: function setup(config) {}
      }, {
        key: "getName",
        value: function getName() {
          return this.name;
        }
      }, {
        key: "forceSubmit",
        value: function forceSubmit() {
          this.getCheckoutFormElement().submit();
        }
      }, {
        key: "getCard",
        value: function getCard() {
          return this.card;
        }
      }, {
        key: "getCardData",
        value: function getCardData() {
          var data = {};

          if (this.card) {
            var _clean = function _clean(str) {
              return String(str).trim().replace(/\s/g, '');
            };

            var expiry = _clean($(this.card.$expiryInput).val());

            data.cvc = _clean($(this.card.$cvcInput).val());
            data.name = _clean($(this.card.$nameInput).val());
            data.number = _clean($(this.card.$numberInput).val());
            data.expiry = expiry.split('/').map(_clean);
          }

          return data;
        }
      }, {
        key: "createCard",
        value: function createCard() {
          var cardElement = this.getCardElement();

          if (cardElement.classList.contains('disabled') || !cardElement.classList.contains('credit-card--visual')) {
            return;
          }

          this.card = new Card({
            form: this.getCheckoutFormElement(),
            container: cardElement.querySelector('.credit-card__display'),
            width: 350,
            formatting: true,
            formSelectors: {
              cvcInput: '.credit-card__cvc',
              nameInput: '.credit-card__name',
              numberInput: '.credit-card__number',
              expiryInput: '.credit-card__expiry'
            }
          });
          $(cardElement).data('card', this.card);
        }
      }, {
        key: "isAvailable",
        value: function isAvailable() {
          return !!this.getRootElement();
        }
      }, {
        key: "getRootElement",
        value: function getRootElement() {
          var input = $('#payment-methods').find('input[type="radio"][name="payment_method"][value="' + this.getName() + '"]');
          return input.length ? input.closest('li')[0] : void 0;
        }
      }, {
        key: "getCardElement",
        value: function getCardElement() {
          var rootElement = this.getRootElement();
          return rootElement ? rootElement.querySelector('.credit-card') : void 0;
        }
      }, {
        key: "getSubmitButton",
        value: function getSubmitButton() {
          return this.getCheckoutFormElement().querySelector('button[name=awebooking_submit]');
        }
      }, {
        key: "getCheckoutFormElement",
        value: function getCheckoutFormElement() {
          return document.getElementById('checkout-form');
        }
      }]);

      return Gateway;
    }();
    /**
     * Store all instance of gateways.
     *
     * @type {Object}
     */


    Gateway.instances = {};
    /**
     * Retrive gateway instance.
     *
     * @param {string} name
     * @return {Gateway|null}
     */

    Gateway.get = function (name) {
      return Gateway.instances.hasOwnProperty(name) ? Gateway.instances[name] : null;
    };
    /**
     * Register a gateway instance.
     *
     * @param {string}  name
     * @param {Gateway} instance
     */


    Gateway.register = function (name, instance) {
      Gateway.instances[name] = instance;
    };

    return Gateway;
  }(jQuery);

  (function ($, awebooking) {

    awebooking.checkout = {};
    awebooking.checkout.Gateway = Gateway;
    awebooking.checkout.selected = void 0;
    awebooking.checkout.selectedGateway = void 0;
    $(function () {
      $(document).trigger('abrs_checkout_init', awebooking.checkout); // Setup the gateways.

      $.each(Gateway.instances, function (name, gateway) {
        if (gateway.isAvailable()) {
          gateway.setup({});
          gateway.getCardElement() && gateway.createCard();
        }
      }); // Handle selected payment.

      $('#payment-methods').on('selected.awebooking.gateway', function (e, gateway) {
        awebooking.checkout.selected = gateway;

        if (awebooking.checkout.selectedGateway) {
          awebooking.checkout.selectedGateway.off();
        }

        awebooking.checkout.selectedGateway = Gateway.get(gateway);
      }); // Handle checkout form.

      $('#checkout-form').on('submit', function (e) {
        if (awebooking.checkout.selected && awebooking.checkout.selectedGateway) {
          e.preventDefault();
          awebooking.checkout.selectedGateway.on(e);
        }
      });
    });
  })(window.jQuery, window.awebooking || {});

}());

//# sourceMappingURL=payment.js.map
