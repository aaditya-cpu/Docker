<?php
/**
 * Plugin Name:     AweBooking WooCommerce
 * Plugin URI:      https://awethemes.com/awebooking/addon/woocommerce-payment
 * Description:     Seamlessly connects with Woocommerce to benefit from all variety of Woocommerce extensions and payment gateways.
 * Author:          awethemes
 * Author URI:      http://awethemes.com
 * Text Domain:     awebooking-woocommerce
 * Domain Path:     /languages
 * Version:         1.0.9
 *
 * @package         AweBooking/WooCommerce
 */

if ( ! defined( 'ABRS_WOOCOMMERCE_VERSION' ) ) {
	require trailingslashit( __DIR__ ) . 'vendor/autoload.php';

	/* Constants */
	define( 'ABRS_WOOCOMMERCE_VERSION', '1.0.9' );
	define( 'ABRS_WOOCOMMERCE_PLUGIN_FILE', __FILE__ );
	define( 'ABRS_WOOCOMMERCE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
	define( 'ABRS_WOOCOMMERCE_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

	/* Define the premium constant */
	if ( ! defined( 'ABRS_PREMIUM' ) ) {
		define( 'ABRS_PREMIUM', true );
	}

	/* Init the addon */
	add_action( 'awebooking_init', function( $plugin ) {
		/* @var \AweBooking\Plugin $plugin */
		$plugin->provider( \AweBooking\WooCommerce\Service_Provider::class );
	});
}

