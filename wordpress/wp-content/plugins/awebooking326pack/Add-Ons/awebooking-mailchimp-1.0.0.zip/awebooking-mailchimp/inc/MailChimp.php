<?php
namespace AweBooking\Mailchimp;

use WP_Error;

class MailChimp {
	/* Constants */
	const API_URL = 'https://<dc>.api.mailchimp.com/3.0';

	/**
	 * The mailchimp api key.
	 *
	 * @var string
	 */
	protected $api_key;

	/**
	 * Construct
	 *
	 * @param string $api_key The api key.
	 */
	public function __construct( $api_key ) {
		$this->api_key = $api_key;
	}

	/**
	 * Verify the API key.
	 *
	 * @return bool|WP_Error
	 */
	public function verify() {
		$response = $this->request( '/' );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return is_array( $response ) && isset( $response['account_id'] );
	}

	/**
	 * Retrieve the list.
	 *
	 * @link https://developer.mailchimp.com/documentation/mailchimp/reference/lists/#read-get_lists
	 *
	 * @param  array $parameters The query parameters.
	 * @return array|WP_Error
	 */
	public function get_list( $parameters = [] ) {
		$response = $this->request( '/lists', wp_parse_args( $parameters, [
			'count' => 100,
		] ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return isset( $response['lists'] ) ? $response['lists'] : [];
	}

	/**
	 * Retrieve the list for the dropdown.
	 *
	 * @param array $parameters The query parameters.
	 *
	 * @return array
	 */
	public function get_list_dropdown( $parameters = [] ) {
		$list = $this->get_list( $parameters );

		if ( is_wp_error( $list ) ) {
			return [];
		}

		return wp_list_pluck( $list, 'name', 'id' );
	}

	/**
	 * Subcribe an mail into a list.
	 *
	 * @param string $email   The customer email address.
	 * @param string $list_id The list ID.
	 * @param array  $data    The request data.
	 *
	 * @return array|WP_ERROR
	 */
	public function subscribe( $email, $list_id, $data = [] ) {
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'email', esc_html__( 'Please enter a valid email address', 'awebooking-mailchimp' ) );
		}

		$response = $this->request( "/lists/{$list_id}/members", [], 'POST', array_merge( $data, [
			'email_address' => $email,
			'status'        => 'subscribed',
		] ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return $response;
	}

	/**
	 * Returns the request URL.
	 *
	 * @param string $endpoint   The endpoint path.
	 * @param array  $parameters Optional, the parameters.
	 *
	 * @return string
	 */
	public function get_url( $endpoint = '/', $parameters = [] ) {
		$dc = explode( '-', $this->api_key );

		if ( ! isset( $dc[1] ) ) {
			throw new \InvalidArgumentException( 'Invalid API key' );
		}

		$url = str_replace( '<dc>', $dc[1], static::API_URL ) . $endpoint;

		if ( $parameters ) {
			$url = add_query_arg( $parameters, $url );
		}

		return $url;
	}

	/**
	 * Create new request.
	 *
	 * @param string       $endpoint   The endpoint.
	 * @param array        $parameters Optional, the parameters.
	 * @param string       $method     Method request, default GET.
	 * @param array|string $body       The data send to.
	 *
	 * @return array|\WP_Error
	 */
	public function request( $endpoint, $parameters = [], $method = 'GET', $body = null ) {
		try {
			$request_url = $this->get_url( $endpoint, $parameters );
		} catch ( \Exception $e ) {
			return new WP_Error( 'api_error', $e->getMessage() );
		}

		$response = wp_remote_request(
			$request_url,
			[
				'body'        => $body ? json_encode( $body ) : null,
				'method'      => $method,
				'sslverify'   => false,
				'timeout'     => 30,
				'redirection' => 1,
				'headers'     => [
					'Content-Type'  => 'application/json',
					'Authorization' => 'awebooking ' . $this->api_key,
				],
			]
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status   = wp_remote_retrieve_response_code( $response );
		$response = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $status || empty( $response ) ) {
			return new WP_Error( 'response_error', isset( $response['detail'] ) ? $response['detail'] : '', $response );
		}

		return $response;
	}
}
