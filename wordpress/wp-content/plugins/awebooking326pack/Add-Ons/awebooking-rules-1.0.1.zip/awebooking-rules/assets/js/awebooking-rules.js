(function ($) {
  'use strict';

  $ = $ && $.hasOwnProperty('default') ? $['default'] : $;

  function _typeof(obj) {
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
      _typeof = function (obj) {
        return typeof obj;
      };
    } else {
      _typeof = function (obj) {
        return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
      };
    }

    return _typeof(obj);
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  var groupTemplate = "\n    <dl id=\"{{= it.group_id }}\" class=\"rules-group-container\">\n      <dt class=\"rules-group-header\">\n        <div class=\"button-group pull-right group-actions\">\n          <button type=\"button\" class=\"button\" data-add=\"rule\">\n            <i class=\"{{= it.icons.add_rule }}\"></i> {{= it.translate(\"add_rule\") }}\n          </button>\n\n          {{? it.settings.allow_groups===-1 || it.settings.allow_groups>=it.level }}\n            <button type=\"button\" class=\"button\" data-add=\"group\">\n              <i class=\"{{= it.icons.add_group }}\"></i> {{= it.translate(\"add_group\") }}\n            </button>\n          {{?}}\n\n          {{? it.level>1 }}\n            <button type=\"button\" class=\"button\" data-delete=\"group\">\n              <i class=\"{{= it.icons.remove_group }}\"></i> <span class=\"screen-reader-text\">{{= it.translate(\"delete_group\") }}</span>\n            </button>\n          {{?}}\n        </div>\n\n        <div class=\"button-group group-conditions\">\n          {{~ it.conditions: condition }}\n            <label class=\"button\">\n              <input type=\"radio\" name=\"{{= it.group_id }}_cond\" value=\"{{= condition }}\"> {{= it.translate(\"conditions\", condition) }}\n            </label>\n          {{~}}\n        </div>\n\n        {{? it.settings.display_errors }}\n          <div class=\"error-container\"><i class=\"{{= it.icons.error }}\"></i></div>\n        {{?}}\n      </dt>\n\n      <dd class=rules-group-body>\n        <ul class=rules-list></ul>\n      </dd>\n    </dl>";
  var ruleTemplate = "\n    <li id=\"{{= it.rule_id }}\" class=\"rule-container\">\n      <div class=\"rule-header\"></div>\n\n      {{? it.settings.display_errors }}\n        <div class=\"error-container\"><i class=\"{{= it.icons.error }}\"></i></div>\n      {{?}}\n\n      <div class=\"rule-filter-container\"></div>\n      <div class=\"rule-operator-container\"></div>\n      <div class=\"rule-value-container\"></div>\n\n      <div class=\"rule-actions\">\n        <button type=\"button\" class=\"button-link awebooking-button-dashicons\" data-delete=\"rule\">\n          <i class=\"{{= it.icons.remove_rule }}\"></i> <span class=\"screen-reader-text\">{{= it.translate(\"delete_rule\") }}</span>\n        </button>\n      </div>\n    </li>";
  var templates = {
    group: groupTemplate,
    rule: ruleTemplate
  };

  var Builder = $.fn.queryBuilder;
  var Selectors = Builder.constructor.selectors;
  var data = window._awebookingRules || {};
  var Defaults = {
    rules: null,
    groups: data.groups || [],
    filters: data.filters || [],
    strings: data.strings || {},
    defaultFilter: null,
    inputSelector: 'input[type="hidden"]',
    autoUpdate: true
  };

  var QueryBuilder =
  /*#__PURE__*/
  function () {
    function QueryBuilder(el) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      _classCallCheck(this, QueryBuilder);

      this.options = $.extend({}, Defaults, options);
      this.el = el;
      this.input = el.querySelector(this.options.inputSelector);

      this._addEventListener();

      this.builder = this._createQueryBuilder();

      if (!this.builder instanceof QueryBuilder) {
        throw new Error('Cannot create the builder');
      }

      QueryBuilder.instances.push(this);
    }

    _createClass(QueryBuilder, [{
      key: "validate",
      value: function validate() {
        return this.builder.validate({
          allow_empty_value: true
        });
      }
    }, {
      key: "getRules",
      value: function getRules() {
        var jsonRules = this.builder.getRules({
          allow_invalid: true
        });

        if (jsonRules && _typeof(jsonRules) === 'object') {
          return jsonRules;
        }

        return {};
      }
    }, {
      key: "getInputRules",
      value: function getInputRules() {
        if (!this.input) {
          return null;
        }

        try {
          return JSON.parse(this.input.value);
        } catch (e) {
          return null;
        }
      }
    }, {
      key: "updateInputRules",
      value: function updateInputRules() {
        if (this.input) {
          this.input.value = JSON.stringify(this.getRules());
          $(this.input).trigger('change');
        }
      }
    }, {
      key: "getDateFilters",
      value: function getDateFilters() {
        var filters = new Object(this.options.filters || {}).filter(function (f) {
          return f.type === 'date';
        }).map(function (f) {
          return f.id;
        });
        return filters ? filters : [];
      }
    }, {
      key: "_addEventListener",
      value: function _addEventListener() {
        var _this = this;

        $(this.el).on('afterCreateRuleInput.queryBuilder', function (e, rule) {
          _this._initPlugins(rule);
        }).on('afterUpdateRuleValue.queryBuilder', function (e, rule) {
          _this._updatePlugins(rule);
        }).on('beforeDeleteRule.queryBuilder', function (e, rule) {
          _this._destroyPlugins(rule);
        });
      }
    }, {
      key: "_initPlugins",
      value: function _initPlugins(rule) {
        if (!rule.filter) {
          return;
        }

        var $input = rule.$el.find(Selectors.rule_value);

        if (window.flatpickr && this.getDateFilters().includes(rule.filter.id)) {
          $input.each(function (i, el) {
            flatpickr(el, {
              allowInput: true,
              dateFormat: 'Y-m-d'
            });
          });
        }
      }
    }, {
      key: "_updatePlugins",
      value: function _updatePlugins(rule) {
        if (!rule.filter) {
          return;
        }

        var $input = rule.$el.find(Selectors.rule_value);

        if (window.flatpickr && this.getDateFilters().includes(rule.filter.id)) {
          $input.each(function (i, el) {
            return el._flatpickr && el._flatpickr.redraw();
          });
        }
      }
    }, {
      key: "_destroyPlugins",
      value: function _destroyPlugins(rule) {
        if (!rule.filter) {
          return;
        }

        var $input = rule.$el.find(Selectors.rule_value);

        if (window.flatpickr && this.getDateFilters().includes(rule.filter.id)) {
          $input.each(function (i, el) {
            return el._flatpickr && el._flatpickr.destroy();
          });
        }
      }
    }, {
      key: "_createQueryBuilder",
      value: function _createQueryBuilder() {
        $(this.el).queryBuilder({
          templates: templates,
          rules: this.options.rules || this.getInputRules(),
          filters: this.options.filters,
          optgroups: this.options.groups,
          lang: this.options.strings,
          default_filter: this.options.defaultFilter,
          inputs_separator: '<span class="query-builder-separator"></span>',
          allow_groups: 5,
          allow_empty: true,
          icons: {
            add_rule: 'dashicons dashicons-plus',
            add_group: 'dashicons dashicons-plus-alt',
            remove_rule: 'dashicons dashicons-no-alt',
            remove_group: 'dashicons dashicons-trash',
            error: 'dashicons dashicons-warning'
          }
        });
        return $(this.el).data('query-builder');
      }
    }]);

    return QueryBuilder;
  }();
  /**
   * Store all instances of the builder.
   *
   * @type {Array}
   */


  QueryBuilder.instances = [];

  $(function () {
    $('[data-init="awebooking-rules"]').each(function (index, element) {
      $(element).data('query-builder', new QueryBuilder(element));
    }); // Support saving in edit-post.php

    var $post = $('#post');

    if ($post.length > 0) {
      $post.on('submit', function (e) {
        var isValid = false;
        QueryBuilder.instances.forEach(function (e) {
          return isValid = e.validate();
        });

        if (!isValid) {
          e.preventDefault();
        }

        QueryBuilder.instances.forEach(function (e) {
          return isValid = e.updateInputRules();
        });
      });
    }
  });

}(jQuery));

//# sourceMappingURL=awebooking-rules.js.map
