<?php
namespace AweBooking\Rules\Rules;

class Rule {
	/* Constants */
	const COR  = 'OR';
	const CAND = 'AND';

	/**
	 * The rule ID.
	 *
	 * @var string
	 */
	protected $id;

	/**
	 * The rule field name.
	 *
	 * @var string
	 */
	protected $field;

	/**
	 * The type of the field rule.
	 *
	 * Available types: 'string', 'integer', 'double', 'date', 'time', 'datetime', 'boolean'
	 *
	 * @var string
	 */
	protected $type;

	/**
	 * The type of input used.
	 *
	 * @var string
	 */
	protected $input;

	/**
	 * The rule operator.
	 *
	 * @see Rule::$operators keys.
	 *
	 * @var string
	 */
	protected $operator;

	/**
	 * The rule value.
	 *
	 * @var mixed
	 */
	protected $value;

	/**
	 * Rule types.
	 *
	 * @var array
	 */
	protected static $types = [
		'string'   => 'string',
		'integer'  => 'number',
		'double'   => 'number',
		'date'     => 'datetime',
		'time'     => 'datetime',
		'datetime' => 'datetime',
		'boolean'  => 'boolean',
	];

	/**
	 * An array of valid operators.
	 *
	 * @var array
	 */
	static protected $operators = [ // @codingStandardsIgnoreStart
		'equal'            => [ 'multiple' => false, 'apply_to' => [ 'string', 'number', 'datetime', 'boolean' ] ],
		'not_equal'        => [ 'multiple' => false, 'apply_to' => [ 'string', 'number', 'datetime', 'boolean' ] ],
		'in'               => [ 'multiple' => true,  'apply_to' => [ 'string', 'number', 'datetime' ] ],
		'not_in'           => [ 'multiple' => true,  'apply_to' => [ 'string', 'number', 'datetime' ] ],
		'less'             => [ 'multiple' => false, 'apply_to' => [ 'number', 'datetime' ] ],
		'less_or_equal'    => [ 'multiple' => false, 'apply_to' => [ 'number', 'datetime' ] ],
		'greater'          => [ 'multiple' => false, 'apply_to' => [ 'number', 'datetime' ] ],
		'greater_or_equal' => [ 'multiple' => false, 'apply_to' => [ 'number', 'datetime' ] ],
		'between'          => [ 'multiple' => false, 'apply_to' => [ 'number', 'datetime' ] ],
		'not_between'      => [ 'multiple' => false, 'apply_to' => [ 'number', 'datetime' ] ],
		'begins_with'      => [ 'multiple' => false, 'apply_to' => [ 'string' ] ],
		'not_begins_with'  => [ 'multiple' => false, 'apply_to' => [ 'string' ] ],
		'contains'         => [ 'multiple' => false, 'apply_to' => [ 'string' ] ],
		'not_contains'     => [ 'multiple' => false, 'apply_to' => [ 'string' ] ],
		'ends_with'        => [ 'multiple' => false, 'apply_to' => [ 'string' ] ],
		'not_ends_with'    => [ 'multiple' => false, 'apply_to' => [ 'string' ] ],
		'is_empty'         => [ 'multiple' => false, 'apply_to' => [ 'string' ] ],
		'is_not_empty'     => [ 'multiple' => false, 'apply_to' => [ 'string' ] ],
		'is_null'          => [ 'multiple' => false, 'apply_to' => [ 'string', 'number', 'datetime', 'boolean' ] ],
		'is_not_null'      => [ 'multiple' => false, 'apply_to' => [ 'string', 'number', 'datetime', 'boolean' ] ],
	]; // @codingStandardsIgnoreEnd

	/**
	 * Create rule from array.
	 *
	 * @param  array $rule The rule array.
	 * @return static
	 *
	 * @throws \InvalidArgumentException
	 */
	public static function from_array( array $rule ) {
		foreach ( [ 'id', 'field', 'type', 'input', 'operator', 'value' ] as $require_key ) {
			if ( ! array_key_exists( $require_key, $rule ) ) {
				throw new \InvalidArgumentException( 'Keys given: ' . implode( ', ', array_keys( $rule ) ) . '. Expected id, field, type, input, operator, value in rule.' );
			}
		}

		return new static( $rule['id'], $rule['field'], $rule['type'], $rule['input'], $rule['operator'], $rule['value'] );
	}

	/**
	 * Create a rule.
	 *
	 * @link http://querybuilder.js.org/index.html#filters
	 *
	 * @param string $id       The rule ID.
	 * @param string $field    The rule field name.
	 * @param string $type     The rule type.
	 * @param string $input    The rule input type name.
	 * @param string $operator The rule operator.
	 * @param mixed  $value    The rule value.
	 *
	 * @throws \InvalidArgumentException
	 */
	public function __construct( $id, $field, $type, $input, $operator, $value ) {
		$this->validate_operator( $operator );
		$this->validate_type( $type, $operator );

		$this->id       = $id;
		$this->field    = $field;
		$this->type     = $type;
		$this->input    = $input;
		$this->operator = $operator;
		$this->value    = $this->normalize_value( $value, $operator, $type );

		$this->revalidate();
	}

	/**
	 * Gets the rule ID.
	 *
	 * @return string
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Gets the rule field.
	 *
	 * @return string
	 */
	public function get_field() {
		return $this->field;
	}

	/**
	 * Gets the type of rule (integer, boolean, etc..).
	 *
	 * @return string
	 */
	public function get_type() {
		return $this->type;
	}

	/**
	 * Gets the rule input field.
	 *
	 * @return string
	 */
	public function get_input() {
		return $this->input;
	}

	/**
	 * Gets the rule operator.
	 *
	 * @return string
	 */
	public function get_operator() {
		return $this->operator;
	}

	/**
	 * Gets the rule value.
	 *
	 * @return mixed
	 */
	public function get_value() {
		return $this->value;
	}

	/**
	 * Get rule data as array.
	 *
	 * @return array
	 */
	public function to_array() {
		return [
			'id'       => $this->get_id(),
			'field'    => $this->get_field(),
			'type'     => $this->get_type(),
			'input'    => $this->get_input(),
			'operator' => $this->get_operator(),
			'value'    => $this->stringify_value( $this->get_value() ),
		];
	}

	/**
	 * Determine if an operator requires an array.
	 *
	 * @param  string $operator The operator to check.
	 * @return bool
	 */
	public function requires_array( $operator ) {
		return in_array( $operator, [ 'in', 'not_in', 'between', 'not_between' ] );
	}

	/**
	 * Determine if an operator uses null as value.
	 *
	 * @param  string $operator The operator to check.
	 * @return bool
	 */
	public function operator_uses_null( $operator ) {
		return in_array( $operator, [ 'is_empty', 'is_not_empty', 'is_null', 'is_not_null' ] );
	}

	/**
	 * Stringify some value.
	 *
	 * @param  string $value The rule value.
	 * @return mixed
	 */
	protected function stringify_value( $value ) {
		$type = $this->get_type();

		// Some operators not require any parameter, just return null.
		if ( $this->operator_uses_null( $this->get_operator() ) ) {
			return null;
		}

		if ( is_array( $value ) ) {
			return array_map( function( $val ) {
				return $this->stringify_value( $val );
			}, $value );
		}

		switch ( $type ) {
			case 'date':
				$value = $value->toDateString();
				break;
			case 'time':
				$value = $value->toTimeString();
				break;
			case 'datetime':
				$value = $value->toDateTimeString();
				break;
		}

		return $value;
	}

	/**
	 * Cast value to correct type.
	 *
	 * @param  mixed  $value    Raw value.
	 * @param  string $operator The rule operator.
	 * @param  string $type     Valid rule type.
	 * @return mixed
	 */
	protected function normalize_value( $value, $operator, $type ) {
		// Some operators not require any parameter, just return null.
		if ( $this->operator_uses_null( $operator ) ) {
			return null;
		}

		if ( $this->requires_array( $operator ) ) {
			$value = is_array( $value ) ? $value : [ $value ];
		}

		if ( is_array( $value ) ) {
			return array_values(
				array_unique( array_map( function( $val ) use ( $type ) {
					return $this->cast_value( $val, $type );
				}, $value ) )
			);
		}

		return $this->cast_value( $value, $type );
	}

	/**
	 * Cast value to correct type.
	 *
	 * @param  mixed  $value Raw value.
	 * @param  string $type  Valid rule type.
	 * @return mixed
	 */
	protected function cast_value( $value, $type ) {
		$value = abrs_clean( $value );

		if ( is_null( $value ) || 'null' === $value || 'NULL' === $value ) {
			return null; // nulls shouldn't be converted.
		}

		switch ( $type ) {
			case 'string':
				return trim( (string) $value );
			case 'integer':
				return (int) $value;
			case 'double':
				return (float) $value;
			case 'boolean':
				return (bool) $value;
			case 'date':
				return abrs_date( $value );
			case 'time':
				return abrs_optional( abrs_date_time( $value ) )->format( 'H:i:s' );
			case 'datetime':
				return abrs_date_time( $value );
			default:
				return $value;
		}
	}

	/**
	 * Validate operator of rule.
	 *
	 * @param string $operator The operator to check.
	 *
	 * @throws \InvalidArgumentException
	 */
	protected function validate_operator( $operator ) {
		if ( ! array_key_exists( $operator, static::$operators ) ) {
			throw new \InvalidArgumentException( 'Invalid rule operator' );
		}
	}

	/**
	 * Validate type of rule.
	 *
	 * @param  string $type     The type of rule.
	 * @param  string $operator The operator of rule.
	 * @return void
	 *
	 * @throws \InvalidArgumentException
	 */
	protected function validate_type( $type, $operator ) {
		$type = array_key_exists( $type, static::$types ) ? static::$types[ $type ] : $type;

		if ( ! in_array( $type, static::$operators[ $operator ]['apply_to'] ) ) {
			throw new \InvalidArgumentException( 'Invalid rule type' );
		}
	}

	/**
	 * Re-validate some case.
	 *
	 * @throws \InvalidArgumentException
	 */
	protected function revalidate() {
		if ( in_array( $this->operator, [ 'between', 'not_between' ] ) ) {
			if ( 2 !== count( $this->value ) ) {
				throw new \InvalidArgumentException( "Operator '{$this->operator}' requires two operands" );
			}

			// Sort data value, in case like a range.
			sort( $this->value );
		}
	}
}
