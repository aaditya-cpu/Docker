<?php
namespace AweBooking\Payment\Gateways\Traits;

use Awethemes\Http\Request;
use Psr\Log\LoggerInterface;
use AweBooking\Model\Booking;
use AweBooking\Model\Booking\Payment_Item;
use AweBooking\Gateway\Response;

trait Process_Actions {
	/**
	 * {@inheritdoc}
	 *
	 * @throws \RuntimeException
	 */
	public function process( Booking $booking, Request $request ) {
		$parameters = array_merge([
			'amount'    => $booking->get( 'total' ),
			'currency'  => $booking->get( 'currency' ),
			'returnUrl' => $this->get_complete_purchase_url( $booking ),
			'cancelUrl' => $this->get_cancel_purchase_url( $booking ),
			/* translators: %s site name */
			'description' => sprintf( esc_html__( 'Reservation on %s', 'awebooking-payment' ), esc_html( get_bloginfo( 'name' ) ) ),
		], $this->get_purchase_parameters( $booking, $request ) );

		/* @var \Omnipay\Common\Message\AbstractResponse $response */
		$response = $this->get_gateway()
			->purchase( $parameters )
			->send();

		// Store the transaction reference if available.
		if ( $transaction_refer = $response->getTransactionReference() ) {
			$booking->update_meta( "_payment_{$this->get_method()}_transaction_refer", $transaction_refer );
		}

		// Response redirect.
		if ( $response->isRedirect() ) {
			$status = apply_filters( 'abrs_booking_status_payment_processing', 'inprocess', $this->get_method() );

			// Redirect to payment, before that
			// we will update the booking status to "processing".
			$booking->update_status( $status );

			$response->redirect();
			exit;
		}

		// Response successfull.
		if ( $response->isSuccessful() ) {
			// Mark the booking is complete.
			$this->complete_booking( $booking, $response );

			return new Response( 'success', false, $booking );
		}

		$message = $response->getMessage() ?: esc_html__( 'Sorry, but something went wrong. Please contact the administrator.', 'awebooking-payment' );
		throw new \RuntimeException( $this->method_title . ': ' . $message );
	}

	/**
	 * Listen the payment notification.
	 *
	 * @param \AweBooking\Model\Booking     $booking The booking instance.
	 * @param \Awethemes\Http\Request       $request The http request instance.
	 * @param \Psr\Log\LoggerInterface|null $logger  The logger instance.
	 *
	 * @throws \RuntimeException
	 * @throws \Omnipay\Common\Exception\InvalidRequestException
	 */
	public function listen( Booking $booking, Request $request, LoggerInterface $logger = null ) {
		$logger  = $logger ?: abrs_logger();
		$omnipay = $this->get_gateway();

		if ( ! $omnipay->supportsAcceptNotification() ) {
			throw new \RuntimeException( esc_html__( 'Gateway does not support notifications.', 'awebooking-payment' ) );
		}

		$logger->debug( "[{$this->get_method()}] Capture the notification message" );

		/* @var $response \Omnipay\PayU\Messages\Notification */
		$response = $omnipay->acceptNotification();

		$transaction_status = $response->getTransactionStatus();
		$transaction_id     = $response->getTransactionReference();

		$logger->debug( "[{$this->get_method()}] Transaction status: {$transaction_status}" );

		if ( ! $transaction_id ) {
			throw new \RuntimeException( esc_html__( 'No transaction found', 'awebooking-payment' ) );
		}

		// Prevent working on completed.
		if ( 'completed' !== $booking->get_status() ) {
			switch ( $transaction_status ) {
				case 'completed':
					$logger->debug( "[{$this->get_method()}] Notification: Complete the reservation" );
					$this->complete_booking( $booking, $response );
					break;

				case 'on-hold':
					$logger->debug( "[{$this->get_method()}] Notification: Update on-hold status" );
					$booking->update_status( 'on-hold', esc_html__( 'Payment has been put on hold - merchant must approve this payment manually.', 'awebooking-payment' ) );
					break;

				case 'failed':
					$logger->debug( "[{$this->get_method()}] Notification: Update failed status" );
					$booking->update_status( 'cancelled', esc_html__( 'Payment has been rejected.', 'awebooking-payment' ) );
					break;
			}
		}

		$logger->debug( "[{$this->get_method()}] End capture notification message" );
	}

	/**
	 * Complete the purchase.
	 *
	 * @param  \AweBooking\Model\Booking $booking The booking instance.
	 * @return void
	 *
	 * @throws \RuntimeException
	 */
	public function complete( Booking $booking ) {
		if ( 'completed' === $booking->get_status() ) {
			return;
		}

		if ( ! $this->get_gateway()->supportsCompletePurchase() ) {
			return;
		}

		$parameters = array_merge([
			'amount'   => $booking->get( 'total' ),
			'currency' => $booking->get( 'currency' ),
		], $this->get_complete_purchase_parameters( $booking ) );

		/* @var $response \Omnipay\Common\Message\AbstractResponse */
		$response = $this->get_gateway()
			->completePurchase( $parameters )
			->send();

		// If redirect repsonse, just redirect immediately.
		if ( $response->isRedirect() ) {
			$response->redirect();
			exit;
		}

		if ( $response->isCancelled() ) {
			$this->cancel_booking( $booking );
		} elseif ( $response->isSuccessful() ) {
			$this->complete_booking( $booking, $response );
		} else {
			$error_message = esc_html__( 'Sorry, there was an error processing your payment.', 'awebooking-payment' );
			throw new \RuntimeException( "<p>{$error_message}</p><p>{$response->getMessage()}</p>" );
		}
	}

	/**
	 * Cancel the booking.
	 *
	 * @param  \AweBooking\Model\Booking $booking The booking instance.
	 */
	protected function cancel_booking( Booking $booking ) {
		$booking->update_status( 'cancelled' );

		// Delete logging transaction reference.
		if ( $booking->get_meta( "_payment_{$this->get_method()}_transaction_refer" ) ) {
			$booking->delete_meta( "_payment_{$this->get_method()}_transaction_refer" );
		}

		abrs_session()->remove( 'booking_awaiting_payment' );
	}

	/**
	 * Complete the booking.
	 *
	 * @param  \AweBooking\Model\Booking                $booking  The booking instance.
	 * @param  \Omnipay\Common\Message\AbstractResponse $response The gateway response.
	 */
	protected function complete_booking( Booking $booking, $response ) {
		// Update the booking status.
		$booking->update_status( 'completed' );

		// Create the payment item, store the log data.
		$this->create_payment_item( $booking, $response );

		// Delete logging transaction reference.
		if ( $booking->get_meta( "_payment_{$this->get_method()}_transaction_refer" ) ) {
			$booking->delete_meta( "_payment_{$this->get_method()}_transaction_refer" );
		}

		// Flush the session.
		abrs_session()->remove( 'booking_awaiting_payment' );
		abrs_reservation()->flush();
	}

	/**
	 * Create the payment item.
	 *
	 * @param  \AweBooking\Model\Booking                $booking  The booking instance.
	 * @param  \Omnipay\Common\Message\AbstractResponse $response The gateway response.
	 */
	protected function create_payment_item( Booking $booking, $response ) {
		$payment_item = abrs_get_last_payment( $booking );

		// Check the last payment to avoid duplicate items.
		if ( ! $payment_item ) {
			$payment_item = ( new Payment_Item )->fill([
				'method'     => $this->get_method(),
				'amount'     => $booking->get( 'total' ), // TODO: ...
				'booking_id' => $booking->get_id(),
				'is_deposit' => 'off',
			]);
		}

		// Sets the transaction ID & log.
		$payment_item['transaction_id']  = $response->getTransactionReference();
		$payment_item['transaction_log'] = $response->getData();

		$payment_item->save();
	}

	/**
	 * Returns the complete purchase url.
	 *
	 * @param \AweBooking\Model\Booking|int $booking The booking instance.
	 * @return string
	 */
	public function get_complete_purchase_url( $booking ) {
		$booking = abrs_get_booking( $booking );

		$purchase_url = abrs_url()->route( "/payment/complete/{$this->get_method()}/{$booking->get_id()}" );

		return apply_filters( 'abrs_get_complete_purchase_url', $purchase_url, $this );
	}

	/**
	 * Returns the notify purchase url.
	 *
	 * @param \AweBooking\Model\Booking|int $booking The booking instance.
	 * @return string
	 */
	public function get_notify_purchase_url( $booking ) {
		$booking = abrs_get_booking( $booking );

		$purchase_url = abrs_url()->route( "/payment/notify/{$this->get_method()}/{$booking->get_id()}" );

		return apply_filters( 'abrs_get_notify_purchase_url', $purchase_url, $this );
	}

	/**
	 * Returns the complete purchase url.
	 *
	 * @param \AweBooking\Model\Booking|int $booking The booking instance.
	 * @return string
	 */
	public function get_cancel_purchase_url( $booking ) {
		$booking = abrs_get_booking( $booking );

		$purchase_url = abrs_url()->route( "/payment/cancel/{$booking->get_id()}" );

		return apply_filters( 'abrs_get_cancel_purchase_url', $purchase_url, $this );
	}

	/**
	 * Gets the extra purchase parameters.
	 *
	 * @param  \AweBooking\Model\Booking $booking The booking instance.
	 * @param  \Awethemes\Http\Request   $request The http request.
	 *
	 * @return array
	 */
	protected function get_purchase_parameters( Booking $booking, Request $request ) {
		return [];
	}

	/**
	 * Gets the extra complete purchase parameters.
	 *
	 * @param  \AweBooking\Model\Booking $booking The booking instance.
	 *
	 * @return array
	 */
	protected function get_complete_purchase_parameters( Booking $booking ) {
		return [];
	}
}
