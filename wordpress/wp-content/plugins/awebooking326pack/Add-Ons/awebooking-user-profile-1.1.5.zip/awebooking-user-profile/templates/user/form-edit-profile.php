<?php
/**
 * Edit address form
 * 
 * @author 		Awethemes <awethemes.com>
 * @package 	AweBooking\User
 * @since 1.0
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( isset( $_GET['action'] ) && $_GET['action'] == 'updated' ) {
	awebooking_user_print_alert( esc_attr__( 'Profile details changed successfully.', 'awebooking-user-profile' ) );
}

do_action( 'awebooking\user\before_profile' );
?>

<form method="post" enctype="multipart/form-data">

	<?php do_action( "awebooking\user\before_profile_form_profile" ); ?>

	<div class="awebooking_user-user-profile-settings">

		<div class="user-avatar js-user-avatar">
			<?php
			$has_image = '';

			$args = get_avatar_data( $user->ID, array( 'size' => 240 ) );

			$image = $args['url'];

			if ( !empty( $image ) ) {
				$image = sprintf( 'style="background-image:url(%s)"', $image );
				$has_image = 'has-image';
			}
			?>

			<div class="awebooking_user-file-drag user-avatar-image <?php echo esc_attr( $has_image ) ?>" <?php print $image; ?> >
				<a href="remove-avatar" class="remove"><?php echo esc_attr__( 'Change', 'awebooking-user-profile' ) ?></a>
				<div class="box__input">
					<svg class="box__icon" xmlns="http://www.w3.org/2000/svg" width="50" height="43" viewBox="0 0 50 43"><path d="M48.4 26.5c-.9 0-1.7.7-1.7 1.7v11.6h-43.3v-11.6c0-.9-.7-1.7-1.7-1.7s-1.7.7-1.7 1.7v13.2c0 .9.7 1.7 1.7 1.7h46.7c.9 0 1.7-.7 1.7-1.7v-13.2c0-1-.7-1.7-1.7-1.7zm-24.5 6.1c.3.3.8.5 1.2.5.4 0 .9-.2 1.2-.5l10-11.6c.7-.7.7-1.7 0-2.4s-1.7-.7-2.4 0l-7.1 8.3v-25.3c0-.9-.7-1.7-1.7-1.7s-1.7.7-1.7 1.7v25.3l-7.1-8.3c-.7-.7-1.7-.7-2.4 0s-.7 1.7 0 2.4l10 11.6z"></path></svg>
					<input id="user_avatar" name="user_avatar" type="file" accept="image/*"/>
					<label for="user_avatar"><strong><?php echo esc_attr__( 'Choose an image', 'awebooking-user-profile' ) ?></strong><span class="box__dragndrop"> <?php echo esc_attr__( 'or drag it here', 'awebooking-user-profile' ) ?></span>.</label>
				</div>
			</div>

			<input id="user_remove_avatar" name="user_remove_avatar" type="hidden" value="0"/>
			<input name="user_curent_avatar" type="hidden" value="<?php echo esc_attr( $user->image_avatar ) ?>"/>

			<span class="user-avatar-note">
				<?php echo apply_filters( 'awebooking\user\user_avatar_note', sprintf( wp_kses( __( 'Default use avatar on %s.', 'awebooking-user-profile' ), wp_kses_allowed_html() ), '<a href="//en.gravatar.com/">Gravatar</a>' ) ) ?>
			</span>

		</div>

		<h3 class="awebooking_user-form-title"><?php echo esc_attr__( 'Information', 'awebooking-user-profile' ) ?></h3>

		<div class="awebooking-field">
			<label for="first_name"><?php echo esc_attr__( 'First Name', 'awebooking-user-profile' ) ?><abbr class="required" title="required">*</abbr></label>
			<input type="text" name="first_name" id="first_name" class="form-control" value="<?php echo esc_attr( isset( $_POST['first_name'] ) ? $_POST['first_name'] : $user->first_name  ) ?>">
		</div>

		<div class="awebooking-field">
			<label for="last_name"><?php echo esc_attr__( 'Last Name', 'awebooking-user-profile' ) ?><abbr class="required" title="required">*</abbr></label>
			<input type="text" name="last_name" id="last_name" class="form-control" value="<?php echo esc_attr( isset( $_POST['last_name'] ) ? $_POST['last_name'] : $user->last_name  ) ?>">
		</div>

		<div class="awebooking-field">
			<label for="email"><?php echo esc_attr__( 'Email', 'awebooking-user-profile' ) ?><abbr class="required" title="required">*</abbr></label>
			<input type="email" id="email" class="form-control" value="<?php echo esc_attr( isset( $_POST['email'] ) ? $_POST['email'] : $user->user_email  ) ?>" name="email">
		</div>
		
		<div class="awebooking-field">
			<label for="url"><?php echo esc_attr__( 'Website', 'awebooking-user-profile' ) ?></label>
			<input type="url" id="url" class="form-control" value="<?php echo esc_attr( $user->user_url ) ?>" name="url">
		</div>

		<div class="awebooking-field">
			<label for="description"><?php echo esc_attr__( 'About me', 'awebooking-user-profile' ) ?></label>
			<textarea id="description" name="description" class="form-control" rows="4"><?php echo esc_textarea( $user->description ); ?></textarea>
		</div>
		
	</div>


	<?php
	/**
	 * Get Wordpress User Contact mothods
	 */
	$contact_methods = wp_get_user_contact_methods( $user );


	foreach ( $contact_methods as $name => $desc ) :?>
		<div class="awebooking-field">
			<label for="<?php echo esc_attr( $name ); ?>">
				<?php
				/**
				 * Filter a user contactmethod label.
				 *
				 * The dynamic portion of the filter hook, `$name`, refers to
				 * each of the keys in the contactmethods array.
				 *
				 * @since WordPress 2.9.0
				 *
				 * @param string $desc The translatable label for the contactmethod.
				 */
				echo apply_filters( "user_{$name}_label", $desc );
				?>
			</label>
			<input type="text" name="<?php echo esc_attr( $name ); ?>" id="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $user->$name ) ?>" class="form-control" />
		</div>
	<?php endforeach; ?>

	<?php do_action( "awebooking\user\after_form_profile" ); ?>

	<div class="awebooking_user-user-password-change">

		<h3 class="awebooking_user-form-title"><?php echo esc_attr__( 'Password Change', 'awebooking-user-profile' ); ?></h3>

		<div class="awebooking-field">
			<label for="password_current"><?php echo esc_attr__( 'Current Password', 'awebooking-user-profile' ); ?></label>
			<input type="password" class="form-control" name="password_current" id="password_current" />
		</div>
		<div class="awebooking-field">
			<label for="password_1"><?php echo esc_attr__( 'New Password', 'awebooking-user-profile' ); ?></label>
			<input type="password" class="form-control" name="password_1" id="password_1" />
		</div>
		<div class="awebooking-field">
			<label for="password_2"><?php echo esc_attr__( 'Confirm New Password', 'awebooking-user-profile' ); ?></label>
			<input type="password" class="form-control" name="password_2" id="password_2" />
		</div>
	</div>

	<div>
		<button type="submit" class="button" name="save_address"><?php esc_attr_e( 'Update Profile', 'awebooking-user-profile' ); ?></button>
		<?php wp_nonce_field( 'awebooking_user-user-profile' ); ?>
		<input type="hidden" name="action" value="user-profile" />
	</div>

</form>

<?php
do_action( 'awebooking\user\after_profile' );
