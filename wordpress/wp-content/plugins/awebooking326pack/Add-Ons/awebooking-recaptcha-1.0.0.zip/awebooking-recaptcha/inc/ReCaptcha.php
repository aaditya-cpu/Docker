<?php
namespace AweBooking\Captcha;

use Symfony\Component\HttpFoundation\Request;

class ReCaptcha {
	const CLIENT_API = 'https://www.google.com/recaptcha/api.js';
	const VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify';

	/**
	 * The recaptcha secret key.
	 *
	 * @var string
	 */
	protected $secret;

	/**
	 * The recaptcha sitekey key.
	 *
	 * @var string
	 */
	protected $sitekey;

	/**
	 * Constructor.
	 *
	 * @param string $secret  The recaptcha secret key.
	 * @param string $sitekey The recaptcha sitekey key.
	 */
	public function __construct( $secret, $sitekey ) {
		$this->secret  = $secret;
		$this->sitekey = $sitekey;
	}

	/**
	 * Render HTML captcha.
	 *
	 * @param array $attributes The attributes.
	 *
	 * @return string
	 */
	public function display( $attributes = [] ) {
		$attributes['data-sitekey'] = $this->sitekey;

		return '<div class="g-recaptcha"' . $this->build_attributes( $attributes ) . '></div>';
	}

	/**
	 * Render js source.
	 *
	 * @param string|null $lang            The language.
	 * @param bool        $callback        The callback.
	 * @param string      $onload_callback The onload_callback.
	 *
	 * @return string
	 */
	public function render_js( $lang = null, $callback = false, $onload_callback = 'onloadCallBack' ) {
		return '<script src="' . $this->get_js_link( $lang, $callback, $onload_callback ) . '" async defer></script>' . "\n";
	}

	/**
	 * Verify no-captcha response.
	 *
	 * @param string $response  The response.
	 * @param string $client_ip The client IP.
	 *
	 * @return bool
	 */
	public function verify_response( $response, $client_ip = null ) {
		if ( empty( $response ) ) {
			return false;
		}

		$verify_response = $this->send_request_verify( [
			'secret'   => $this->secret,
			'response' => $response,
			'remoteip' => $client_ip,
		] );

		return isset( $verify_response['success'] ) && true === $verify_response['success'];
	}

	/**
	 * Verify no-captcha response by Symfony Request.
	 *
	 * @param Request $request The symfony request instance.
	 * @return bool
	 */
	public function verify_request( Request $request ) {
		return $this->verify_response(
			$request->get( 'g-recaptcha-response' ), $request->getClientIp()
		);
	}

	/**
	 * Get recaptcha js link.
	 *
	 * @param string|null $lang            The language.
	 * @param bool        $callback        The callback.
	 * @param string      $onload_callback The onload_callback.
	 *
	 * @return string
	 */
	public function get_js_link( $lang = null, $callback = false, $onload_callback = 'onloadCallBack' ) {
		$client_api = static::CLIENT_API;
		$params     = [];

		if ( $callback ) {
			$params['render'] = 'explicit';
			$params['onload'] = $onload_callback;
		}

		if ( $lang ) {
			$params['hl'] = $lang;
		}

		return $client_api . '?' . http_build_query( $params );
	}

	/**
	 * Send verify request.
	 *
	 * @param array $query The query args.
	 * @return array
	 */
	protected function send_request_verify( array $query = [] ) {
		$response = wp_remote_post( static::VERIFY_URL, [
			'timeout' => 30,
			'body'    => $query,
		] );

		return json_decode( wp_remote_retrieve_body( $response ), true );
	}

	/**
	 * Build HTML attributes.
	 *
	 * @param array $attributes The attributes.
	 * @return string
	 */
	protected function build_attributes( array $attributes ) {
		$html = [];

		foreach ( $attributes as $key => $value ) {
			$html[] = $key . '="' . $value . '"';
		}

		return count( $html ) ? ' ' . implode( ' ', $html ) : '';
	}
}
