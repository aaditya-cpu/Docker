<?php
namespace AweBooking\Payment\Controllers;

use Awethemes\Http\Request;
use Awethemes\Http\Json_Response;
use Awethemes\Http\Exception\BadRequestException;
use AweBooking\Model\Booking;
use AweBooking\Checkout\Checkout;
use AweBooking\Payment\Gateways\Omnipay_Gateway;

class Payment_Controller {
	/**
	 * The checkout instance.
	 *
	 * @var \AweBooking\Checkout\Checkout
	 */
	protected $checkout;

	/**
	 * Constructor.
	 *
	 * @param \AweBooking\Checkout\Checkout $checkout The checkout instance.
	 */
	public function __construct( Checkout $checkout ) {
		$this->checkout = $checkout;
	}

	/**
	 * Capture the notify from payment gateway
	 *
	 * @param \Awethemes\Http\Request   $request The request instance.
	 * @param string                    $gateway The gateway name.
	 * @param \AweBooking\Model\Booking $booking The booking instance.
	 *
	 * @return mixed
	 */
	public function notify( Request $request, $gateway, Booking $booking ) {
		$logger = abrs_logger();

		$this->prepare_request( $booking,
			$gateway = abrs_payment_gateways()->get( $gateway )
		);

		try {
			$gateway->listen( $booking, $request, $logger );
		} catch ( \Exception $e ) {
			$logger->debug( "[{$gateway->get_method()}] Notification is rejected, an exception was throw", [ 'exception' => $e->getMessage() ] );
			return new Json_Response( [ 'error' => $e->getMessage() ], 500 );
		}

		return new Json_Response( [ 'message' => 'OK' ], 200 );
	}

	/**
	 * Handle complete the purchase.
	 *
	 * @param \Awethemes\Http\Request   $request The request instance.
	 * @param string                    $gateway The gateway name.
	 * @param \AweBooking\Model\Booking $booking The booking instance.
	 *
	 * @return mixed
	 */
	public function complete( Request $request, $gateway, Booking $booking ) {
		$this->prepare_request( $booking,
			$gateway = abrs_payment_gateways()->get( $gateway )
		);

		// Gets the return url (thank you page).
		$return_url = $gateway->get_return_url( $booking );

		try {
			/* @var $gateway \AweBooking\Payment\Gateways\Omnipay_Gateway */
			$gateway->complete( $booking );
		} catch ( \Exception $e ) {
			abrs_add_notice( $e->getMessage(), 'error' )->important();
			return abrs_redirector()->to( add_query_arg( 'error', 1, $return_url ) );
		}

		return abrs_redirector()->to( $return_url );
	}

	/**
	 * Handle cancel the payment.
	 *
	 * @param \Awethemes\Http\Request   $request The request instance.
	 * @param \AweBooking\Model\Booking $booking The booking instance.
	 *
	 * @return mixed
	 */
	public function cancel( Request $request, Booking $booking ) {
		// Check valid hash. TODO: ...
		$booking->update_status( 'cancelled' );

		return abrs_redirector()->to( abrs_get_checkout_url() );
	}

	/**
	 * Prepare checking the request.
	 *
	 * @param \AweBooking\Model\Booking $booking The booking instance.
	 * @param mixed                     $gateway The gateway instance.
	 *
	 * @throws BadRequestException
	 */
	protected function prepare_request( $booking, $gateway ) {
		if ( ! $gateway || ! $gateway instanceof Omnipay_Gateway ) {
			throw new BadRequestException( esc_html__( 'That payment method is unsupported. Please choose another one.', 'awebooking-payment' ) );
		}

		if ( 'trash' === $booking->get_status() ) {
			throw new BadRequestException( esc_html__( 'Payment could not be processed. Please try again.', 'awebooking-payment' ) );
		}
	}
}
