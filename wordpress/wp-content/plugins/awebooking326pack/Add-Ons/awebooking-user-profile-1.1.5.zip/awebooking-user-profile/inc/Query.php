<?php
namespace AweBooking\User_Profile;

class Query {
	/** @public array Query vars to add to wp */
	public $query_vars = [];

	/**
	 * Constructor for the query class. Hooks in methods.
	 *
	 * @access public
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'add_endpoints' ] );
		add_filter( 'query_vars', [ $this, 'add_query_vars' ] );

		add_action( 'parse_request', [ $this, 'parse_request' ] );
		add_action( 'wp_loaded', [ $this, 'get_errors' ], 20 );
	}

	/**
	 * Get any errors from querystring.
	 */
	public function get_errors() {
		if ( ! empty( $_GET['awebooking_user_error'] ) && ( $error = sanitize_text_field( $_GET['awebooking_user_error'] ) ) && ! awebooking_user_has_alert( $error, 'error' ) ) {
			awebooking_user_add_alert( $error, 'error' );
		}
	}

	/**
	 * Init query vars by loading options.
	 */
	public function init_query_vars() {
		// Query vars to add to WP.
		$this->query_vars = apply_filters( 'awebooking/user/query_vars', [
			// My account actions.
			'profile'       => abrs_get_option( 'user_enpoint_profile', 'profile' ),
			'lost-password' => abrs_get_option( 'user_enpoint_lost_password', 'lost-password' ),
			'edit-booking'  => abrs_get_option( 'user_enpoint_edit_booking', 'edit-booking' ),
			'orders'        => abrs_get_option( 'user_enpoint_order', 'orders' ),
			'view-booking'  => abrs_get_option( 'user_enpoint_view_booking', 'view-booking' ),
			'user-logout'   => abrs_get_option( 'user_enpoint_user_logout', 'user-logout' ),
		] );
	}

	/**
	 * Get page title for an endpoint.
	 *
	 * @param  string
	 *
	 * @return string
	 */
	public function get_endpoint_title( $endpoint ) {
		switch ( $endpoint ) {
			case 'profile' :
				$title = __( 'Profile', 'awebooking-user-profile' );
				break;

			case 'lost-password' :
				$title = __( 'Lost Password', 'awebooking-user-profile' );
				break;

			case 'billing-address' :
				$title = __( 'Billing Address', 'awebooking-user-profile' );
				break;

			case 'order' :
				$title = __( 'Bookings', 'awebooking-user-profile' );
				break;

			default :
				$title = apply_filters( 'awebooking/user/endpoint_' . $endpoint . '_title', '' );
				break;
		}

		return apply_filters( 'awebooking/user/endpoint_title', $title );
	}

	/**
	 * Endpoint mask describing the places the endpoint should be added.
	 *
	 * @since 1.0
	 * @return int
	 */
	protected function get_endpoints_mask() {
		if ( 'page' === get_option( 'show_on_front' ) ) {
			$page_on_front   = get_option( 'page_on_front' );
			$account_page_id = abrs_get_option( 'user_page_id' );

			if ( $page_on_front === $account_page_id ) {
				return EP_ROOT | EP_PAGES;
			}
		}

		return EP_PAGES;
	}

	/**
	 * Add endpoints for query vars.
	 */
	public function add_endpoints() {
		$this->init_query_vars();

		$mask = $this->get_endpoints_mask();

		foreach ( $this->query_vars as $key => $var ) {
			if ( ! empty( $var ) ) {
				add_rewrite_endpoint( $var, $mask );
			}
		}
	}

	/**
	 * Add query vars.
	 *
	 * @access public
	 *
	 * @param array $vars
	 *
	 * @return array
	 */
	public function add_query_vars( $vars ) {
		foreach ( $this->query_vars as $key => $var ) {
			$vars[] = $key;
		}

		return $vars;
	}

	/**
	 * Get query vars.
	 *
	 * @return array
	 */
	public function get_query_vars() {
		return $this->query_vars;
	}

	/**
	 * Get query current active query var.
	 *
	 * @return string
	 */
	public function get_current_endpoint() {
		global $wp;

		$current_enpoint = '';

		foreach ( $this->get_query_vars() as $key => $value ) {
			if ( isset( $wp->query_vars[ $key ] ) ) {
				$current_enpoint = $key;
				break;
			}
		}

		return apply_filters( 'awebooking/user/current_enpoint', $current_enpoint );
	}

	/**
	 * Parse the request and look for query vars - endpoints may not be supported.
	 */
	public function parse_request() {
		global $wp;

		// Map query vars to their keys, or get them if endpoints are not supported.
		foreach ( $this->query_vars as $key => $var ) {
			if ( isset( $_GET[ $var ] ) ) {
				$wp->query_vars[ $key ] = sanitize_text_field( wp_unslash( $_GET[ $var ] ) );
			} elseif ( isset( $wp->query_vars[ $var ] ) ) {
				$wp->query_vars[ $key ] = $wp->query_vars[ $var ];
			}
		}
	}
}
