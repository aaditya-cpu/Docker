<?php
namespace AweBooking\Payment\Gateways;

use Awethemes\Http\Request;
use AweBooking\Model\Booking;

class Stripe_Gateway extends Omnipay_Gateway {
	/* Constants */
	const STRIPE_JS = 'https://js.stripe.com/v3/';

	/**
	 * The gateway unique ID.
	 *
	 * @var string
	 */
	protected $method = 'stripe';

	/**
	 * The extra metadata this gateway support.
	 *
	 * @var array
	 */
	public $supports = [ 'transaction_id' ];

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->method_title = esc_html__( 'Stripe', 'awebooking-payment' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function display_fields() {
		parent::display_fields();

		wp_enqueue_script( 'awebooking-payment-stripe' ); ?>

		<div id="stripe-card-element"></div>
		<div id="stripe-card-errors" role="alert"></div>

		<input type="hidden" name="stripe_token">
		<input type="hidden" id="stripe_publishable_key" value="<?php echo esc_attr( $this->get_option( 'publishable_key' ) ); ?>">

		<?php // @codingStandardsIgnoreStart ?>
		<script src="<?php echo esc_url( static::STRIPE_JS ); ?>"></script>
		<?php // @codingStandardsIgnoreEnd
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_purchase_parameters( Booking $booking, Request $request ) {
		return [ 'token' => $request->get( 'stripe_token' ) ];
	}

	/**
	 * {@inheritdoc}
	 */
	public function setup() {
		$this->setting_fields();

		$this->enabled     = $this->get_option( 'enabled' );
		$this->title       = esc_html( $this->get_option( 'title' ) );
		$this->description = esc_textarea( $this->get_option( 'description' ) );

		$this->gateway = $this->create_gateway( 'Stripe', [
			'apiKey' => $this->get_option( 'secret_key' ),
		]);
	}

	/**
	 * Set the gateway settings fields.
	 *
	 * @return void
	 */
	protected function setting_fields() {
		$this->setting_fields = [
			'enabled' => [
				'name'    => esc_html__( 'Enable / Disable', 'awebooking-payment' ),
				'type'    => 'toggle',
				'default' => 'off',
			],
			'title' => [
				'name'        => esc_html__( 'Title', 'awebooking-payment' ),
				'type'        => 'text',
				'description' => esc_html__( 'This controls the title which the user sees during checkout.', 'awebooking-payment' ),
				'default'     => _x( 'Stripe', 'Stripe payment method', 'awebooking-payment' ),
			],
			'description' => [
				'name'        => esc_html__( 'Description', 'awebooking-payment' ),
				'type'        => 'textarea',
				'description' => esc_html__( 'Payment method description that the customer will see on your checkout.', 'awebooking-payment' ),
				'default'     => esc_html__( 'Pay via Stripe.', 'awebooking-payment' ),
			],
			'publishable_key' => [
				'type' => 'text',
				'name' => esc_html__( 'Publishable key', 'awebooking-payment' ),
			],
			'secret_key' => [
				'type' => 'text',
				'name' => esc_html__( 'Secret key', 'awebooking-payment' ),
			],
		];
	}
}
