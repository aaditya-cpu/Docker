const groupTemplate = `
    <dl id="{{= it.group_id }}" class="rules-group-container">
      <dt class="rules-group-header">
        <div class="button-group pull-right group-actions">
          <button type="button" class="button" data-add="rule">
            <i class="{{= it.icons.add_rule }}"></i> {{= it.translate("add_rule") }}
          </button>

          {{? it.settings.allow_groups===-1 || it.settings.allow_groups>=it.level }}
            <button type="button" class="button" data-add="group">
              <i class="{{= it.icons.add_group }}"></i> {{= it.translate("add_group") }}
            </button>
          {{?}}

          {{? it.level>1 }}
            <button type="button" class="button" data-delete="group">
              <i class="{{= it.icons.remove_group }}"></i> <span class="screen-reader-text">{{= it.translate("delete_group") }}</span>
            </button>
          {{?}}
        </div>

        <div class="button-group group-conditions">
          {{~ it.conditions: condition }}
            <label class="button">
              <input type="radio" name="{{= it.group_id }}_cond" value="{{= condition }}"> {{= it.translate("conditions", condition) }}
            </label>
          {{~}}
        </div>

        {{? it.settings.display_errors }}
          <div class="error-container"><i class="{{= it.icons.error }}"></i></div>
        {{?}}
      </dt>

      <dd class=rules-group-body>
        <ul class=rules-list></ul>
      </dd>
    </dl>`;

const ruleTemplate = `
    <li id="{{= it.rule_id }}" class="rule-container">
      <div class="rule-header"></div>

      {{? it.settings.display_errors }}
        <div class="error-container"><i class="{{= it.icons.error }}"></i></div>
      {{?}}

      <div class="rule-filter-container"></div>
      <div class="rule-operator-container"></div>
      <div class="rule-value-container"></div>

      <div class="rule-actions">
        <button type="button" class="button-link awebooking-button-dashicons" data-delete="rule">
          <i class="{{= it.icons.remove_rule }}"></i> <span class="screen-reader-text">{{= it.translate("delete_rule") }}</span>
        </button>
      </div>
    </li>`;

export default {
  group: groupTemplate,
  rule: ruleTemplate
}
