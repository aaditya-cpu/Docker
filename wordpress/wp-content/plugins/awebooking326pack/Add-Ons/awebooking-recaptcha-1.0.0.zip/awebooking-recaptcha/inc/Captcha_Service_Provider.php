<?php
namespace AweBooking\Captcha;

use AweBooking\Support\Service_Provider;

class Captcha_Service_Provider extends Service_Provider {
	/**
	 * Registers services on the plugin.
	 *
	 * @return void
	 */
	public function register() {
		load_plugin_textdomain( 'awebooking-captcha', false, basename( dirname( __DIR__ ) ) . '/languages' );

		$this->plugin->singleton( 'recaptcha', function() {
			return new ReCaptcha(
				$this->plugin->get_option( 'recaptcha_secret_key' ), $this->plugin->get_option( 'recaptcha_site_key' )
			);
		});
	}

	/**
	 * Init service provider.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'abrs_register_admin_settings', function ( $settings ) {
			new Checkout_Captcha_Setting( $settings->get( 'checkout' ) );
		});

		add_action( 'abrs_before_submit_button', function() {
			$recaptcha = $this->plugin->make( 'recaptcha' );

			echo $recaptcha->display([ // WPCS: XSS OK.
				'data-theme' => $this->plugin->get_option( 'recaptcha_theme' ),
				'data-size'  => 'normal',
			]);

			echo $recaptcha->render_js(); // WPCS: XSS OK.
		}, 5 );

		add_action( 'abrs_validate_checkout', function ( $errors, $data, $request ) {
			if ( ! $this->plugin['recaptcha']->verify_request( $request ) ) {
				$errors->add( 'recaptcha', esc_html__( 'Sorry, you did not pass the security check. Please try again.', 'awebooking-captcha' ) );
			}
		}, 10, 3 );
	}
}
