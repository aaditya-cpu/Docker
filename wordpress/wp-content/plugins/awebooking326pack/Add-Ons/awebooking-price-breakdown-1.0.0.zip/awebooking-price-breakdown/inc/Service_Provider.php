<?php
namespace AweBooking\Price_Breakdown;

class Service_Provider extends \AweBooking\Support\Service_Provider {
	/**
	 * Registers services on the plugin.
	 *
	 * @access private
	 */
	public function register() {
	}

	/**
	 * Init service provider.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action( 'abrs_search_result_room_price', [ $this, 'print_pricing_breakdown' ], 20, 2 );
	}

	/**
	 * Enqueue scripts.
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		if ( ! abrs_is_search_page() ) {
			return;
		}

		wp_enqueue_style( 'awebooking-price-breakdown', AWEBOOKING_BREAKDOWN_PLUGIN_URL . 'assets/css/price-breakdown.css', [ 'awebooking' ], AWEBOOKING_BREAKDOWN_VERSION );
	}

	/**
	 * Print the breakdown popup.
	 *
	 * @param \AweBooking\Hotel\Room_Type        $room_type The room type instance.
	 * @param \AweBooking\Availability\Room_Rate $room_rate The room rate instance.
	 */
	public function print_pricing_breakdown( $room_type, $room_rate ) {
		$dialogid = $room_type->get_id() . '_' . $room_rate->get_rate_plan()->get_id();

		$breakdowns = array_merge(
			[ 'room_only' => $room_rate->get_breakdown() ],
			$room_rate->get_additional_breakdowns()
		);

		include __DIR__ . '/views/html-pricing-breakdown.php';
	}
}
