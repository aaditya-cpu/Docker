<?php

require_once __DIR__ . '/alert-functions.php';
require_once __DIR__ . '/page-functions.php';
require_once __DIR__ . '/user-functions.php';
require_once __DIR__ . '/template-functions.php';
require_once __DIR__ . '/template-hooks.php';

function abrs_user_locate_template( $template, $template_name ) {
	if ( ! file_exists( $template ) && 0 === strpos( $template_name, 'user/' ) ) {
		$template = AWEBOOKING_USER_PROFILE_DIR . '/templates/' . $template_name;
	}

	return $template;
}
add_action( 'abrs_locate_template', 'abrs_user_locate_template', 10, 2 );

/**
 * Get content of template file
 *
 * @return string
 * @since 1.0
 */
function awebooking_user_get_template( $template_name, $data = [] ) {
	ob_start();
	abrs_get_template( $template_name, $data );

	return ob_get_clean();
}

/**
 * is_awebooking_user - check if this page is AweBooking\User Hook
 *
 * @since 1.0
 * @return bool
 */
function is_awebooking_user() {
	return true;
}

/**
 * is_awebooking_user_endpoint_url - Check if an endpoint is showing.
 *
 * @since 1.0
 *
 * @param  string $endpoint
 *
 * @return bool
 */
function is_awebooking_user_endpoint_url( $endpoint = false ) {
	global $wp;

	$awebooking_user_endpoints = AWEBOOKING_USER()->query->get_query_vars();

	if ( false !== $endpoint ) {
		if ( ! isset( $awebooking_user_endpoints[ $endpoint ] ) ) {
			return false;
		}

		$endpoint_var = $awebooking_user_endpoints[ $endpoint ];

		return isset( $wp->query_vars[ $endpoint_var ] );
	}

	foreach ( $awebooking_user_endpoints as $key => $value ) {
		if ( isset( $wp->query_vars[ $key ] ) ) {
			return true;
		}
	}

	return false;
}

/**
 * is_awebooking_user_page - Returns true when viewing an account page.
 *
 * @since 1.0
 * @return bool
 */
function is_awebooking_user_page() {
	return is_page( abrs_get_option( 'user_page_id' ) ) || awebooking_user_post_content_has_shortcode( 'awebooking_user_profile' );
}

/**
 * Clean variables using sanitize_text_field. Arrays are cleaned recursively.
 * Non-scalar values are ignored.
 *
 * @since 1.0
 *
 * @param string|array $var
 *
 * @return string|array
 */
function awebooking_user_clean( $var ) {
	if ( is_array( $var ) ) {
		return array_map( 'awebooking_user_clean', $var );
	}

	return is_scalar( $var ) ? sanitize_text_field( $var ) : $var;
}

/**
 * Checks whether the content passed contains a specific short code.
 *
 * @since 1.0
 *
 * @param  string $tag Shortcode tag to check.
 *
 * @return bool
 */
function awebooking_user_post_content_has_shortcode( $tag = '' ) {
	global $post;

	return is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, $tag );
}

/**
 * Gets cancellable status
 *
 * @return array
 */
function abrs_get_cancellable_status() {
	return apply_filters( 'abrs_get_cancellable_status', [ 'pending', 'on-hold', 'inprocess' ] );
}
