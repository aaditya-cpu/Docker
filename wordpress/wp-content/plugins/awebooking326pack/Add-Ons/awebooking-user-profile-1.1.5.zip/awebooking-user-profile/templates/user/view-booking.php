<div class="awebooking_user-viewbooking">
	<?php if ( $the_booking ) : ?>

		<p>
			<?php
			/* translators: 1: order number 2: order date 3: order status */
			printf(
				__( 'Booking detail #%1$s was placed on %2$s and is currently %3$s.</br>', 'awebooking-user-profile' ),
				'<mark class="booking-number">' . $the_booking->get_id() . '</mark>',
				'<mark class="booking-date">' . abrs_format_date_time( $the_booking->get( 'date_created' ) ) . '</mark>',
				'<mark class="booking-status">' . $the_booking->get_status_label() . '</mark>'
			);

			if ( in_array( $the_booking->get_status(), abrs_get_cancellable_status() ) ) {

				$detail_url = awebooking_user_get_account_endpoint_url( 'view-booking', $the_booking->get_id() );
				$detail_url = wp_nonce_url( $detail_url, 'awebooking_user_booking_cancel', 'cancel' );

				printf( '<a onclick="return confirm(\'' . esc_attr__( 'Are you sure to cancel booking #%s? ',
						'awebooking-user-profile' ) . '\');return false;" href="%s">%s</a>', $the_booking->get_id(),
					esc_url( $detail_url ), esc_html__( 'Cancel booking?', 'awebooking-user-profile' ) );
			}
			?>
		</p>

		<h3 class="awebooking_user-heading"><?php esc_html_e( 'Booking information', 'awebooking-user-profile' ); ?></h3>

		<table class="awebooking_user-table">
			<tbody>

			<?php if ( ! $the_booking->is_multiple_rooms() ) : ?>

				<?php if ( $the_booking->get_check_in_date() ) : ?>
					<tr>
						<td><strong><?php esc_html_e( 'Check-in:', 'awebooking-user-profile' ); ?></strong></td>
						<td><?php echo esc_html( abrs_format_date( $the_booking->get_check_in_date() ) ); ?></td>
					</tr>
				<?php endif; ?>

				<?php if ( $the_booking->get_check_out_date() ) : ?>
					<tr>
						<td><strong><?php esc_html_e( 'Check-out:', 'awebooking-user-profile' ); ?></strong></td>
						<td><?php echo esc_html( abrs_format_date( $the_booking->get_check_out_date() ) ); ?></td>
					</tr>
				<?php endif; ?>

			<?php else : ?>
				<?php if ( $the_booking->get_check_in_date() ) : ?>
					<tr>
						<td><strong><?php esc_html_e( 'Arrival:', 'awebooking-user-profile' ); ?></strong></td>
						<td><?php echo esc_html( abrs_format_date( $the_booking->get_check_in_date() ) ); ?></td>
					</tr>
				<?php endif; ?>

				<?php if ( $the_booking->get_check_out_date() ) : ?>
					<tr>
						<td><strong><?php esc_html_e( 'Departure:', 'awebooking-user-profile' ); ?></strong></td>
						<td><?php echo esc_html( abrs_format_date( $the_booking->get_check_out_date() ) ); ?></td>
					</tr>
				<?php endif; ?>
			<?php endif ?>

			<tr>
				<td><strong><?php echo esc_html( 'Night(s)', 'awebooking-user-profile' ); ?></strong></td>
				<td>
					<?php echo esc_html( $the_booking->get( 'nights_stay' ) ); ?>
				</td>
			</tr>

			<?php do_action( 'awebooking\user\booking_detail_items_table', $the_booking ); ?>
			</tbody>
		</table>

		<h3 class="awebooking_user-heading"><?php esc_html_e( 'Room information', 'awebooking-user-profile' ); ?></h3>

		<div class="awebooking-booking-detail-table-wrapper">
			<table class="awebooking-table awebooking-booking-detail-table">
				<thead>
				<tr>
					<th><?php echo esc_html__( 'Room', 'awebooking-user-profile' ); ?></th>
					<th><?php echo esc_html__( 'Night(s)', 'awebooking-user-profile' ); ?></th>
					<th><?php echo esc_html__( 'Check In', 'awebooking-user-profile' ); ?></th>
					<th><?php echo esc_html__( 'Check Out', 'awebooking-user-profile' ); ?></th>
					<th><?php echo esc_html__( 'Adults', 'awebooking-user-profile' ); ?></th>
					<th><?php echo esc_html__( 'Children', 'awebooking-user-profile' ); ?></th>
					<th><?php echo esc_html__( 'Price', 'awebooking-user-profile' ); ?></th>
				</tr>
				</thead>

				<tbody>
				<?php foreach ( $the_booking->get_line_items() as $room_item ) : ?>
					<?php
					/* @var $item \AweBooking\Model\Booking\Room_Item */
					$timespan    = $room_item->get_timespan();
					$room        = abrs_get_room( $room_item->get( 'room_id' ) );
					$room_type   = abrs_get_room_type( $room_item->get( 'room_type_id' ) );
					$rate_plan   = abrs_get_rate( $room_item->get( 'rate_plan_id' ) );
					$action_link = abrs_admin_route( "/booking-room/{$room_item->get_id()}" );
					?>

					<tr>
						<td>
							<div>
								<strong class="row-title"><?php echo esc_html( $room ? $room->get( 'name' ) : $room_item->get_name() ); ?></strong>
								<p class="dp-block"><?php echo esc_html( $room_type ? $room_type->get( 'title' ) : '' ); ?></p>
							</div>
						</td>
						<td>
							<span class="abrs-badge"><?php echo esc_html( abrs_optional( $timespan )->get_nights() ); ?></span>
						</td>
						<td>
							<?php if ( ! is_null( $timespan ) ) : ?>
								<?php echo esc_html( abrs_format_date( $timespan->get_start_date() ) ); ?>
							<?php endif ?>
						</td>
						<td>
							<?php if ( ! is_null( $timespan ) ) : ?>
								<?php echo esc_html( abrs_format_date( $timespan->get_end_date() ) ); ?>
							<?php endif ?>
						</td>
						<td>
							<?php echo esc_html( number_format_i18n( $room_item->get( 'adults' ) ) ); ?>
						</td>
						<td>
							<?php if ( abrs_children_bookable() ) : ?>
								<?php echo esc_html( $room_item['children'] ? number_format_i18n( $room_item->get( 'children' ) ) : '-' ); ?>
							<?php endif ?>
						</td>
						<td>
							<?php abrs_price( $room_item->get( 'subtotal' ), $the_booking->get( 'currency' ) ); ?>
							<br>
							<?php esc_html_e( 'TAX:', 'awebooking-user-profile' ); ?> <?php abrs_price( $room_item->get( 'total_tax' ) ); ?>
						</td>
					</tr>
				<?php endforeach ?>
				</tbody>

				<?php

				$service_items = $the_booking->get_services();
				?>
				<thead>
				<th colspan="6"><strong class="row-title"><?php esc_html_e( 'Services', 'awebooking-user-profile' ); ?></strong></th>
				<th><?php esc_html_e( 'Price', 'awebooking-user-profile' ); ?></th>
				</thead>
				<tbody>

				<?php if ( abrs_blank( $service_items ) ) : ?>
					<tr>
						<td colspan="7">
							<p class="awebooking-no-items"><?php esc_html_e( 'No services', 'awebooking-user-profile' ); ?></p>
						</td>
					</tr>
				<?php else : ?>
					<?php foreach ( $service_items as $service_item ) : ?>
						<?php
						/* @var $service_item \AweBooking\Model\Booking\Service_Item */
						$service = abrs_get_service( $service_item->get( 'service_id' ) );

						$action_link = abrs_admin_route( "/booking-service/{$service_item->get_id()}" );
						?>
						<tr>
							<td colspan="6"><?php echo esc_html( $service->get_name() ); ?></td>
							<td>
								<p>
									<?php
									printf( /* translators: %1$s quantity, %2$s unit price */
										esc_html_x( '%1$s x %2$s', 'admin booking service price', 'awebooking-user-profile' ),
										absint( $service_item->get( 'quantity' ) ),
										abrs_format_price( $service_item->get( 'price' ) )
									); // WPCS: xss ok.
									?>
								</p>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>

				</tbody>
				<tbody>
				<tr>
					<td colspan="4"></td>
					<th colspan="2"><?php echo esc_html__( 'Total:', 'awebooking-user-profile' ); ?></th>
					<td><?php abrs_price( $the_booking->get( 'total' ), $the_booking->get( 'currency' ) ); ?></td>
				</tr>

				<tr>
					<td colspan="4"></td>
					<th colspan="2"><?php echo esc_html__( 'Paid:', 'awebooking-user-profile' ); ?></th>
					<td><?php abrs_price( $the_booking->get( 'paid' ), $the_booking->get( 'currency' ) ); ?></td>
				</tr>

				<tr>
					<td colspan="4"></td>
					<th colspan="2"><?php echo esc_html__( 'Balance Due:', 'awebooking-user-profile' ); ?></th>
					<td><?php abrs_price( $the_booking->get( 'balance_due' ), $the_booking->get( 'currency' ) ); ?></td>
				</tr>
				</tbody>

			</table>
		</div>

		<h3 class="awebooking_user-heading"><?php esc_html_e( 'Customer Information', 'awebooking-user-profile' ); ?></h3>

		<table class="awebooking_user-table">
			<tr>
				<td><strong><?php echo esc_html__( 'First name', 'awebooking-user-profile' ); ?></strong></td>
				<td><?php echo esc_html( $the_booking['customer_first_name'] ); ?></td>
			</tr>
			<tr>
				<td><strong><?php echo esc_html__( 'Last name', 'awebooking-user-profile' ); ?></strong></td>
				<td><?php echo esc_html( $the_booking['customer_last_name'] ); ?></td>
			</tr>
			<tr>
				<td><strong><?php echo esc_html__( 'Phone number', 'awebooking-user-profile' ); ?></strong></td>
				<td><?php echo esc_html( $the_booking['customer_phone'] ); ?></td>
			</tr>
			<tr>
				<td><strong><?php echo esc_html__( 'Email Address', 'awebooking-user-profile' ); ?></strong></td>
				<td><?php echo esc_html( $the_booking['customer_email'] ); ?></td>
				</td>
			</tr>
			<tr>
				<td><strong><?php echo esc_html__( 'Address', 'awebooking-user-profile' ); ?></strong></td>
				<td><?php echo esc_html( $the_booking['customer_address'] ); ?></td>
			</tr>
			<tr>
				<td><strong><?php echo esc_html__( 'Company', 'awebooking-user-profile' ); ?></strong></td>
				<td><?php echo esc_html( $the_booking['customer_company'] ); ?></td>
			</tr>
			<tr>
				<td><strong><?php echo esc_html__( 'Notes', 'awebooking-user-profile' ); ?></strong></td>
				<td>
					<?php if ( 'pending' == $the_booking->get_status() ) : ?>
						<div class="awebooking_can_edit">
							<div class="item-group_view">
								<span><?php echo wp_kses_post( wpautop( $the_booking['customer_note'] ) ); ?></span>
								<a href="#" class="item-button-edit"><?php echo esc_html__( 'Edit', 'awebooking-user-profile' ); ?></a>
							</div>

							<div class="item-group_edit">
							<textarea
								class="item-textedit"><?php echo esc_textarea( $the_booking['customer_note'] ); ?></textarea>
								<a href="#"
								   class="item-button-update js-customer_update_note"><?php echo esc_html__( 'Update', 'awebooking-user-profile' ); ?></a>
								<a href="#" class="item-button-cancel"><?php echo esc_html__( 'Cancel', 'awebooking-user-profile' ); ?></a>
								<input type="hidden" id="booking_id"
								       value="<?php echo esc_attr( $the_booking->get_id() ); ?>"/>
								<?php wp_nonce_field( 'awebooking_user_edit_customer_note', 'customer_note' ); ?>
							</div>

						</div>
					<?php else : ?>
						<?php echo wp_kses_post( wpautop( $the_booking['customer_note'] ) ); ?>
					<?php endif; ?>
				</td>
			</tr>
		</table>
	<?php else : ?>
		<?php awebooking_user_print_alert( esc_html__( 'There is no booking detail to display', 'awebooking-user-profile' ) ); ?>
	<?php endif; ?>
</div>
