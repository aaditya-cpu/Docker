<?php
/**
 * User reset password email template.
 *
 * @see      http://docs.awethemes.com/awebooking/developers/theme-developers/
 * @author   awethemes
 * @package  AweBooking
 * @version  3.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abrs_mailer()->header( $email );

?>


<p><?php printf( __( 'Thanks for creating an account on %s.', 'awebooking-user-profile' ), esc_html( $email->get_blogname() ) ); ?></p>
<p><?php printf( __( 'Your username is: %s', 'awebooking-user-profile' ), '<strong>' . esc_html( $user_login ) . '</strong>' ) ?></p>
<p><?php printf( __( 'To verify your account, visit the following address:', 'awebooking-user-profile' ) ) ?></p>
<p>
	<a class="link" href="<?php echo esc_url( add_query_arg( array( 'key' => $user_hash, 'login' => rawurlencode( $user_login ), 'action' => 'register' ), awebooking_user_get_page_permalink( 'user-profile' ) ) ); ?>"><?php _e( 'Click here to verify your account.', 'awebooking-user-profile' ); ?></a>
</p>

<?php abrs_mailer()->footer( $email );

