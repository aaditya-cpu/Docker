<div class="scheduler__marker" style="display: none;">
	<span class="scheduler__markerspan">0</span>
</div>
