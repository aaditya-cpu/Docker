(function () {
  'use strict';

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }

    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }

  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }

  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };

    return _setPrototypeOf(o, p);
  }

  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }

    return self;
  }

  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    }

    return _assertThisInitialized(self);
  }

  (function ($, checkout) {

    if ('undefined' === typeof checkout.Gateway) {
      throw new Error('AweBooking checkout gateway is missing');
    }

    var StripeGateway =
    /*#__PURE__*/
    function (_checkout$Gateway) {
      _inherits(StripeGateway, _checkout$Gateway);

      function StripeGateway() {
        var _this;

        _classCallCheck(this, StripeGateway);

        _this = _possibleConstructorReturn(this, _getPrototypeOf(StripeGateway).call(this));
        _this.stripe = void 0;
        _this.stripeCard = void 0;
        return _this;
      }

      _createClass(StripeGateway, [{
        key: "getName",
        value: function getName() {
          return 'stripe';
        }
      }, {
        key: "setup",
        value: function setup(config) {
          this.stripe = Stripe($('#stripe_publishable_key').val());
          this.stripeCard = this.stripe.elements().create('card');
          this.stripeCard.mount('#stripe-card-element');
          this.stripeCard.addEventListener('change', function (e) {
            var displayError = document.getElementById('stripe-card-errors');

            if (e.error) {
              displayError.textContent = e.error.message;
            } else {
              displayError.textContent = '';
            }
          });
        }
      }, {
        key: "on",
        value: function on(e) {
          var _this2 = this;

          this.getSubmitButton().disabled = true;
          this.stripe.createToken(this.stripeCard).then(function (result) {
            _this2.getSubmitButton().disabled = false;

            if (result.error) {
              var errorElement = document.getElementById('stripe-card-errors');
              errorElement.textContent = result.error.message;
            } else {
              $('input[name="stripe_token"]').val(result.token.id);

              _this2.forceSubmit();
            }
          });
        }
      }, {
        key: "off",
        value: function off() {
          this.getSubmitButton().disabled = false;
        }
      }]);

      return StripeGateway;
    }(checkout.Gateway);

    $(document).on('abrs_checkout_init', function () {
      new StripeGateway();
    });
  })(window.jQuery, awebooking.checkout || {});

}());

//# sourceMappingURL=stripe-gateway.js.map
