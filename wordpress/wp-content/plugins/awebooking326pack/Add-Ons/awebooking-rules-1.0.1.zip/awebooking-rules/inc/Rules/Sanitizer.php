<?php
namespace AweBooking\Rules\Rules;

class Sanitizer {
	/**
	 * The filters instance.
	 *
	 * @var Filters|null
	 */
	protected $filters;

	/**
	 * Constructor sanitizer.
	 *
	 * @param Filters $filters Optional, restrict only in the filters.
	 */
	public function __construct( Filters $filters = null ) {
		$this->filters = $filters;
	}

	/**
	 * Sanitize the rules
	 *
	 * @param  array $rules The rules to sanitize.
	 * @return array|null
	 */
	public function sanitize( array $rules ) {
		return $this->sanitize_group( $rules );
	}

	/**
	 * Doing sanitize rule.
	 *
	 * @param  array $rule The raw rule.
	 * @return array|null
	 */
	public function sanitize_rule( array $rule ) {
		return abrs_rescue( function() use ( $rule ) {
			return Rule::from_array( $rule )->to_array();
		});
	}

	/**
	 * Sanitize group.
	 *
	 * @param  array $group The raw group rules.
	 * @return array|null
	 */
	public function sanitize_group( array $group ) {
		if ( ! isset( $group['condition'] ) || ! in_array( $group['condition'], [ Rule::COR, Rule::CAND ] ) ) {
			return null;
		}

		if ( ! isset( $group['rules'] ) || abrs_blank( $group['rules'] ) ) {
			return null;
		}

		$group['rules'] = array_values(
			array_filter( array_map( function( $rule ) {
				if ( isset( $rule['condition'], $rule['rules'] ) ) {
					return $this->sanitize_group( $rule );
				}

				return $this->sanitize_rule( $rule );
			}, $group['rules'] ) )
		);

		return ! empty( $group['rules'] ) ? $group : null;
	}
}
