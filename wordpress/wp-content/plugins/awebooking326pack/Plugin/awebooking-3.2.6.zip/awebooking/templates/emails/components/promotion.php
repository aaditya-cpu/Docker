<table class="promotion" align="center" width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td align="center">
			<?php echo wp_kses_post( wptexturize( $slot ) ); ?>
		</td>
	</tr>
</table>
