(function ($, checkout) {
  'use strict'

  if ('undefined' === typeof checkout.Gateway) {
    throw new Error('AweBooking checkout gateway is missing')
  }

  class StripeGateway extends checkout.Gateway {
    constructor() {
      super()

      this.stripe = void 0
      this.stripeCard = void 0
    }

    getName() {
      return 'stripe'
    }

    setup(config) {
      this.stripe = Stripe($('#stripe_publishable_key').val())
      this.stripeCard = this.stripe.elements().create('card')

      this.stripeCard.mount('#stripe-card-element')

      this.stripeCard.addEventListener('change', (e) => {
        const displayError = document.getElementById('stripe-card-errors')

        if (e.error) {
          displayError.textContent = e.error.message
        } else {
          displayError.textContent = ''
        }
      })
    }

    on(e) {
      this.getSubmitButton().disabled = true

       this.stripe.createToken(this.stripeCard).then((result) => {
         this.getSubmitButton().disabled = false

         if (result.error) {
          const errorElement = document.getElementById('stripe-card-errors');
          errorElement.textContent = result.error.message;
         } else {
           $('input[name="stripe_token"]').val(result.token.id);
           this.forceSubmit()
         }
       })
    }

    off() {
      this.getSubmitButton().disabled = false
    }
  }

  $(document).on('abrs_checkout_init', () => {
    new StripeGateway
  })

})(window.jQuery, awebooking.checkout || {})
