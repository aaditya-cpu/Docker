<?php
namespace AweBooking\User_Profile\Email;

use AweBooking\Email\Mailable;

class Reset_Password extends Mailable {
	public $user_login;
	public $reset_key;

	/**
	 * {@inheritdoc}
	 */
	public function setup() {
		$this->id             = 'reset_password';
		$this->title          = esc_html__( 'Reset password', 'awebooking-user-profile' );
		$this->description    = esc_html__( 'Customer "reset password" emails are sent when customers reset their passwords.', 'awebooking-user-profile' );
		$this->customer_email = true;
	}

	/**
	 * Prepare data for sending.
	 *
	 * @param  \AweBooking\Model\Booking $booking       The booking instance.
	 * @return void
	 */
	protected function prepare_data( $user_login, $reset_key ) {
		if ( $user = get_user_by( 'login', $user_login ) ) {
			$this->reset_key  = $reset_key;
			$this->user_login = $user->user_login;
			$this->recipient  = $user->user_email;
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_subject() {
		return esc_html__( '[{site_title}] Your reset password!', 'awebooking-user-profile' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_content() {
		return '';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_content_html() {
		return awebooking_user_get_template( 'user/emails/user-reset-password.php', [
			'email'      => $this,
			'content'    => $this->format_string( $this->get_option( 'content' ) ),
			'user_login' => $this->user_login,
			'reset_key'  => $this->reset_key,
		] );
	}
}
