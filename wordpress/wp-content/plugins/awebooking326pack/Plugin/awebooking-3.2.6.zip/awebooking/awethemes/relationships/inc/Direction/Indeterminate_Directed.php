<?php
namespace Awethemes\Relationships\Direction;

class Indeterminate_Directed extends Directed {

}
