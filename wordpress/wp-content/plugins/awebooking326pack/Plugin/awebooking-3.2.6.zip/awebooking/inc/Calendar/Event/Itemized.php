<?php

namespace AweBooking\Calendar\Event;

use AweBooking\Support\Collection;

class Itemized extends Collection {
	// ...
}
