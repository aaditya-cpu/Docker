jQuery(function ($) {
    'use strict';


    /**
     * Password Strength Meter class.
     */
    var awebooking_user_password_meter = {
        /**
         * Initialize strength meter actions.
         */
        init: function () {
            $(document.body)
                    .on('keyup change', '.js-password_meter', this.strengthMeter);
        },
        /**
         * Strength Meter.
         */
        strengthMeter: function () {
            var wrapper = $('form.register, form.checkout, form.edit-account, form.lost_reset_password'),
                    submit = $('.button', wrapper),
                    field = $('.js-password_meter', wrapper),
                    strength = 1;

            awebooking_user_password_meter.includeMeter(wrapper, field);

            strength = awebooking_user_password_meter.checkPasswordStrength(wrapper, field);

            if (strength < awebooking_user.password_meter.min_password_strength) {
                submit.attr('disabled', 'disabled').addClass('disabled');
            } else {
                submit.removeAttr('disabled', 'disabled').removeClass('disabled');
            }
        },
        /**
         * Include meter HTML.
         *
         * @param {Object} wrapper
         * @param {Object} field
         */
        includeMeter: function (wrapper, field) {
            var meter = wrapper.find('.meter');

            if ('' === field.val()) {
                meter.remove();
                $(document.body).trigger('awebooking_user-input-warning-removed');
            } else if (0 === meter.length) {
                field.after('<div class="meter" aria-live="polite">\n\
                                <div class="awebooking_user-input-info"></div>\n\
                                <div class="meter-pwd-bar"><span class="strength-bar"></span></div>\n\
                            </div>');
                $(document.body).trigger('awebooking_user-input-warning-added');
            }
        },
        /**
         * Check password strength.
         *
         * @param {Object} field
         *
         * @return {Int}
         */
        checkPasswordStrength: function (wrapper, field) {
            var meter = wrapper.find('.meter');
            var notice = meter.find('.awebooking_user-input-info');
            var hint = wrapper.find('.awebooking_user-password-hint');
            var hint_html = '<small class="awebooking_user-password-hint awebooking_user-input-warning">' + awebooking_user.password_meter.i18n_password_hint + '</small>';
            var strength = wp.passwordStrength.meter(field.val(), wp.passwordStrength.userInputBlacklist());
            var label = '<strong>' + awebooking_user.password_meter.i18n_password_label + '</strong>';

            // Reset
            meter.removeClass('short bad good strong');
            
            hint.remove();

            switch (strength) {
                case 0 :
                    notice.html(label + pwsL10n['short']);
                    meter.addClass('short').append(hint_html);
                    break;
                case 1 :
                    notice.html(label + pwsL10n.bad);
                    meter.addClass('bad').append(hint_html);
                    break;
                case 2 :
                    notice.html(label + pwsL10n.bad);
                    meter.addClass('bad').append(hint_html);
                    break;
                case 3 :
                    notice.html(label + pwsL10n.good);
                    meter.addClass('good');
                    break;
                case 4 :
                    notice.html(label + pwsL10n.strong);
                    meter.addClass('strong');
                    break;
                case 5 :
                    notice.html(label + pwsL10n.mismatch);
                    meter.addClass('short');
                    break;
            }

            return strength;
        }
    };

    var awebooking_user_validate_email = {
        init: function () {
            $(document.body)
                    .on('keyup change', '.js-validate_email', this.checkEmail);

        },
        isEmail: function (email) {
            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            return regex.test(email);
        },
        checkEmail: function () {

            var $this = $(this);

            var $wrapper = $this.closest('form');

            var $submit = $wrapper.find('input[type="submit"]');

            if (!awebooking_user_validate_email.isEmail($this.val())) {
                if ($this.parent().find('.invalid-email').length == 0) {
                    $this.after('<div class="awebooking_user-input-warning invalid-email" aria-live="polite">' + awebooking_user.form.INVALID_EMAIL + '</div>');
                    $($this.attr('data-create_user')).val('');
                }
            } else {
                $this.parent().find('.invalid-email').remove();
                $($this.attr('data-create_user')).val(awebooking_user_validate_email.createUserName($this.val()));
            }

            if ($wrapper.find('.awebooking_user-input-warning').length = 0) {
                $submit.removeAttr('disabled', 'disabled').removeClass('disabled');
            } else {
                $submit.attr('disabled', 'disabled').addClass('disabled');
            }
        },
        createUserName: function (email) {
            var username = email.split('@');
            if ($.trim(username[0]) != '') {
                return username[0];
            }

            return '';
        }
    };

    var awebooking_user_validate_username = {
        init: function () {
            $(document.body)
                    .on('keyup change', '.js-validate_username', this.checkUser);

        },
        checkUser: function () {
            var $this = $(this);

            var $wrapper = $this.closest('form');

            var $submit = $wrapper.find('input[type="submit"]');

            if ($this.val().length < 6 || $this.val().length > 32) {
                if ($this.parent().find('.invalid-user').length == 0) {
                    $this.after('<div class="awebooking_user-input-warning invalid-user" aria-live="polite">' + awebooking_user.form.INVALID_USER + '</div>');
                }
            } else {
                $this.parent().find('.invalid-user').remove();
            }

            if ($wrapper.find('.awebooking_user-input-warning').length = 0) {
                $submit.removeAttr('disabled', 'disabled').removeClass('disabled');
            } else {
                $submit.attr('disabled', 'disabled').addClass('disabled');
            }
        }
    }

    awebooking_user_password_meter.init();
    awebooking_user_validate_email.init();
    awebooking_user_validate_username.init();


    $(document.body).on('keyup change', '.js-confirm_pwd', function () {
        var $this = $(this);

        var $wrapper = $this.closest('form');

        var $submit = $wrapper.find('input[type="submit"]');

        if ($this.val() != $wrapper.find($this.attr('data-confirm')).val()) {
            if ($this.parent().find('.invalid-confirm-psw').length == 0) {
                $this.after('<div class="awebooking_user-input-warning invalid-confirm-psw" aria-live="polite">' + awebooking_user.form.INVALID_CONFIRM_PWD + '</div>');
            }
        } else {

            $this.parent().find('.invalid-confirm-psw').remove();
        }

        if ($wrapper.find('.awebooking_user-input-warning').length == 0) {
            $submit.removeAttr('disabled', 'disabled').removeClass('disabled');
        } else {
            $submit.attr('disabled', 'disabled').addClass('disabled');
        }
    });
});