<?php
namespace AweBooking\Rules;

use AweBooking\Component\Form\Custom_Fields;
use AweBooking\Support\Service_Provider as Base_Service_Provider;

class Service_Provider extends Base_Service_Provider {
	/**
	 * Registers services on the plugin.
	 *
	 * @access private
	 */
	public function register() {
		$this->plugin->singleton( 'query_builder.filters', function () {
			return ( new Filters )->with_defaults();
		});

		add_action( 'cmb2_init', function () {
			$cf = new Custom_Fields( __DIR__ . '/Fields' );
			$cf->register( 'abrs_query_builder', 'abrs_sanitize_rules' );
		});
	}

	/**
	 * Init service provider.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
	}

	/**
	 * Register and enqueue admin scripts.
	 *
	 * @return void
	 */
	public function enqueue_admin_scripts() {
		$min       = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$asset_url = trailingslashit( AWEBOOKING_RULES_PLUGIN_URL ) . 'assets/';
		$version   = AWEBOOKING_RULES_VERSION;

		wp_register_style( 'jquery-tagit', $asset_url . 'css/jquery.tagit.css', [], '2.0' );
		wp_register_script( 'jquery-tagit', $asset_url . 'js/tag-it.js', [ 'jquery' ], '2.0', true );
		wp_register_script( 'jquery-query-builder', $asset_url . 'vendor/query-builder/query-builder.standalone' . $min . '.js', [ 'jquery', 'moment' ], '2.5.2', true );

		wp_register_style( 'awebooking-rules', $asset_url . 'css/awebooking-rules' . $min . '.css', [], $version );
		wp_register_script( 'awebooking-rules', $asset_url . 'js/awebooking-rules' . $min . '.js', [ 'awebooking-admin', 'jquery-query-builder' ], $version, true );

		$filters = $this->plugin->make( 'query_builder.filters' );

		wp_localize_script( 'awebooking-rules', '_awebookingRules', [
			'groups'  => $filters->get_groups(),
			'filters' => $filters->get_filters(),
			'strings' => abrs_get_query_builder_i18n(),
		]);
	}
}
