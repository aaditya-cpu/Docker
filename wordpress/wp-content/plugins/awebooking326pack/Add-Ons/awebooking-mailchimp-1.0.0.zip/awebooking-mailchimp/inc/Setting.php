<?php
namespace AweBooking\MailChimp;

use AweBooking\Admin\Settings\Checkout_Setting;

class Setting {
	/**
	 * The checkout setting instance.
	 *
	 * @var \AweBooking\Admin\Settings\Checkout_Setting
	 */
	protected $settings;

	/**
	 * Constructor.
	 *
	 * @param \AweBooking\Admin\Settings\Checkout_Setting $settings //.
	 */
	public function __construct( Checkout_Setting $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Setup the fields.
	 *
	 * @return void
	 */
	public function register() {
		$options = $this->settings->add_section( 'mail_chimp-options', [
			'title'    => esc_html__( 'MailChimp', 'awebooking-mailchimp' ),
			'priority' => 10,
		] );

		$show_on_cb = function () {
			return (bool) abrs_get_option( 'mailchimp_api_key' ) && 'on' === abrs_get_option( 'mailchimp_enable', 'on' );
		};

		$options->add_field( [
			'id'   => '__mailchimp_control',
			'type' => 'title',
			'name' => esc_html__( 'Mailchimp', 'awebooking-mailchimp' ),
			'desc' => esc_html__( 'Enter your MailChimp settings below to control how AweBooking integrates with your MailChimp account.', 'awebooking-mailchimp' ),
		] );

		$options->add_field( [
			'id'              => 'mailchimp_api_key',
			'type'            => 'text',
			'name'            => esc_html__( 'API Key', 'awebooking-mailchimp' ),
			'desc'            => abrs_esc_text( __( 'Login to <a href="https://admin.mailchimp.com/account/api/" target="_blank">MailChimp</a> to look up your api key.', 'awebooking-mailchimp' ) ),
			'sanitization_cb' => [ $this, 'sanitize_api_key' ],
		] );

		$options->add_field( [
			'id'         => 'mailchimp_enable',
			'type'       => 'abrs_toggle',
			'name'       => esc_html__( 'Enable?', 'awebooking-mailchimp' ),
			'desc'       => esc_html__( 'Enable/disable the plugin functionality.', 'awebooking-mailchimp' ),
			'default'    => 'on',
		] );

		$options->add_field( [
			'id'         => 'mailchimp_list_mail',
			'type'       => 'select',
			'name'       => esc_html__( 'Main List', 'awebooking-mailchimp' ),
			'desc'       => esc_html__( 'All customers will be added to this list.', 'awebooking-mailchimp' ),
			'options_cb' => [ $this, 'fetch_mailchimp_list' ],
			'show_on_cb' => $show_on_cb,
		] );

		$options->add_field( [
			'id'         => 'mailchimp_checkbox_label_text',
			'type'       => 'text',
			'name'       => esc_html__( 'Checkbox label text', 'awebooking-mailchimp' ),
			'default'    => esc_html__( 'Subscribe Us!', 'awebooking-mailchimp' ),
			'show_on_cb' => $show_on_cb,
		] );

		$options->add_field( [
			'id'         => 'mailchimp_checked_default',
			'type'       => 'abrs_checkbox',
			'name'       => esc_html__( 'Ticked by default', 'awebooking-mailchimp' ),
			'default'    => 'off',
			'show_on_cb' => $show_on_cb,
		] );
	}

	/**
	 * Perform sanitize the API key.
	 *
	 * @param  string $key The api key.
	 * @return string
	 */
	public function sanitize_api_key( $key ) {
		$verified = abrs_rescue( function () use ( $key ) {
			return ( new MailChimp( $key ) )->verify();
		});

		if ( is_wp_error( $verified ) ) {
			abrs_admin_notices( $verified->get_error_message(), 'error' );
			return '';
		}

		return ! $verified ? '' : $key;
	}

	/**
	 * Retrive the list.
	 *
	 * @return array
	 */
	public function fetch_mailchimp_list() {
		$transient_key = md5( 'awebooking_mailchimp_' . abrs_get_option( 'mailchimp_api_key' ) );
		$dropdown      = get_transient( $transient_key );

		if ( ! $dropdown ) {
			$dropdown = awebooking( 'mailchimp' )->get_list_dropdown();
			set_transient( $transient_key, $dropdown, HOUR_IN_SECONDS * 2 );
		}

		return $dropdown;
	}
}
