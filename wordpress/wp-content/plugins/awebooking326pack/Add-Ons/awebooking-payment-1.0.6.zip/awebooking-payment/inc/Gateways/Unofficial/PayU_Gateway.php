<?php
namespace AweBooking\Payment\Gateways\Unofficial;

use Awethemes\Http\Request;
use AweBooking\Model\Booking;
use AweBooking\Payment\Gateways\Omnipay_Gateway;

class PayU_Gateway extends Omnipay_Gateway {
	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->method             = 'payu';
		$this->supports           = [ 'transaction_id' ];
		$this->method_title       = esc_html__( 'PayU (EU)', 'awebooking-payment' );

		$message = abrs_esc_text( 'If you do not already have PayU merchant account, please register in <a href="https://secure.payu.com/boarding/#/form" target="_blank">Production</a> or <a href="https://secure.snd.payu.com/boarding/#/form" target="_blank">Sandbox</a>.', 'awebooking-payment' );
		$this->method_description = esc_html__( 'PayU (EU) payment gateway.', 'awebooking-payment' ) . ' ' . $message;
	}

	/**
	 * {@inheritdoc}
	 */
	public function setup() {
		$this->setting_fields();

		$this->enabled     = $this->get_option( 'enabled' );
		$this->title       = esc_html( $this->get_option( 'title' ) );
		$this->description = esc_textarea( $this->get_option( 'description' ) );

		$this->gateway = $this->create_gateway( 'PayU', [
			'posId'        => $this->get_option( 'pos_id' ),
			'secondKey'    => $this->get_option( 'second_key' ),
			'clientSecret' => $this->get_option( 'client_secret' ),
			'testMode'     => 'on' === $this->get_option( 'sandbox', 'off' ),
			'posAuthKey'   => null,
		]);
	}

	/**
	 * Set the gateway settings fields.
	 *
	 * @return void
	 */
	protected function setting_fields() {
		$this->setting_fields = [
			'enabled' => [
				'name'    => esc_html__( 'Enable / Disable', 'awebooking-payment' ),
				'type'    => 'toggle',
				'label'   => esc_html__( 'Enable check payments', 'awebooking-payment' ),
				'default' => 'off',
			],
			'title' => [
				'name'        => esc_html__( 'Title', 'awebooking-payment' ),
				'type'        => 'text',
				'description' => esc_html__( 'This controls the title which the user sees during checkout.', 'awebooking-payment' ),
				'default'     => _x( 'PayU', 'PayU payment method', 'awebooking-payment' ),
			],
			'description' => [
				'name'        => esc_html__( 'Description', 'awebooking-payment' ),
				'type'        => 'textarea',
				'description' => esc_html__( 'Payment method description that the customer will see on your checkout.', 'awebooking-payment' ),
				'default'     => esc_html__( 'PayU is a leading payment services provider with presence in 16 growth markets across the world', 'awebooking-payment' ),
			],
			'sandbox' => [
				'type'    => 'toggle',
				'name'    => esc_html__( 'PayU Sandbox', 'awebooking-payment' ),
				'default' => 'off',
			],
			'pos_id' => [
				'type' => 'text',
				'name' => esc_html__( 'POS ID', 'awebooking-payment' ),
			],
			'second_key' => [
				'type' => 'text',
				'name' => esc_html__( 'Second key (MD5)', 'awebooking-payment' ),
			],
			'client_secret' => [
				'type' => 'text',
				'name' => esc_html__( 'OAuth Client Secret', 'awebooking-payment' ),
			],
		];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_purchase_parameters( Booking $booking, Request $request ) {
		return [
			'notifyUrl'   => $this->get_notify_purchase_url( $booking ),
			'orderNumber' => uniqid( $booking->get_booking_number() . '_', true ),
			'settings'    => [
				'invoiceDisabled' => true,
			],
			'items'       => [
				[
					'name'     => esc_html__( 'Make reservation', 'awebooking-payment' ),
					'price'    => $booking->get( 'total' ),
					'quantity' => 1,
				],
			],
		];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_complete_purchase_parameters( Booking $booking ) {
		return [
			'transactionReference' => $booking->get_meta( '_payment_payu_transaction_refer' ),
		];
	}
}
