import $ from 'jquery'
import templates from './templates'

const Builder = $.fn.queryBuilder
const Selectors = Builder.constructor.selectors

const data = window._awebookingRules || {}

const Defaults = {
  rules: null,
  groups: data.groups || [],
  filters: data.filters || [],
  strings: data.strings || {},
  defaultFilter: '',
  inputSelector: 'input[type="hidden"]',
  autoUpdate: true,
}

class QueryBuilder {
  constructor(el, options = {}) {
    this.options = $.extend({}, Defaults, options)

    this.el = el
    this.input = el.querySelector(this.options.inputSelector)

    this._addEventListener()
    this.builder = this._createQueryBuilder()

    if (!this.builder instanceof QueryBuilder) {
      throw new Error('Cannot create the builder')
    }

    QueryBuilder.instances.push(this)
  }

  validate() {
    return this.builder.validate({
      allow_empty_value: true
    })
  }

  getRules() {
    let jsonRules = this.builder.getRules({
      allow_invalid: true,
    })

    if (jsonRules && typeof jsonRules === 'object') {
      return jsonRules
    }

    return {}
  }

  getInputRules() {
    if (! this.input) {
      return null;
    }

    try {
      return JSON.parse(this.input.value);
    } catch(e) {
      return null;
    }
  }

  updateInputRules() {
    if (this.input) {
      this.input.value = JSON.stringify(this.getRules())
      $(this.input).trigger('change');
    }
  }

  getDateFilters() {
    const filters = (new Object(this.options.filters || {}))
      .filter(f => f.type === 'date')
      .map(f => f.id)

    return filters ? filters : []
  }

  _addEventListener() {
    $(this.el).on('afterCreateRuleInput.queryBuilder', (e, rule) => {
      this._initPlugins(rule)
    }).on('afterUpdateRuleValue.queryBuilder', (e, rule) => {
      this._updatePlugins(rule)
    }).on('beforeDeleteRule.queryBuilder', (e, rule) => {
      this._destroyPlugins(rule)
    })
  }

  _initPlugins(rule) {
    if (!rule.filter) {
      return;
    }

    const $input = rule.$el.find(Selectors.rule_value);

    if (window.flatpickr && this.getDateFilters().includes(rule.filter.id)) {
      $input.each((i, el) => {
        flatpickr(el, {
          allowInput: true,
          dateFormat: 'Y-m-d'
        })
      })
    }
  }

  _updatePlugins (rule) {
    if (!rule.filter) {
      return;
    }

    const $input = rule.$el.find(Selectors.rule_value);

    if (window.flatpickr && this.getDateFilters().includes(rule.filter.id)) {
      $input.each((i, el) => el._flatpickr && el._flatpickr.redraw())
    }
  }

  _destroyPlugins (rule) {
    if (!rule.filter) {
      return;
    }

    const $input = rule.$el.find(Selectors.rule_value);

    if (window.flatpickr && this.getDateFilters().includes(rule.filter.id)) {
      $input.each((i, el) => el._flatpickr && el._flatpickr.destroy())
    }
  }

  _createQueryBuilder() {
    $(this.el).queryBuilder({
      templates: templates,
      rules: this.options.rules || this.getInputRules(),
      filters: this.options.filters,
      optgroups: this.options.groups,
      lang: this.options.strings,
      default_filter: this.options.defaultFilter,
      inputs_separator: '<span class="query-builder-separator"></span>',
      allow_groups: 5,
      allow_empty: true,
      icons: {
        add_rule: 'dashicons dashicons-plus',
        add_group: 'dashicons dashicons-plus-alt',
        remove_rule: 'dashicons dashicons-no-alt',
        remove_group: 'dashicons dashicons-trash',
        error: 'dashicons dashicons-warning',
      },
    })

    return $(this.el).data('query-builder');
  }
}

/**
 * Store all instances of the builder.
 *
 * @type {Array}
 */
QueryBuilder.instances = []

export default QueryBuilder
