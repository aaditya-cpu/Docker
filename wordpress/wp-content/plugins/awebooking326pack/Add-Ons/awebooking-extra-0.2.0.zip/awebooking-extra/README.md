## Features

- Availability Calendar for Room Type (Shortcode, Widget, Tab in Room Type)
- Extra Price
