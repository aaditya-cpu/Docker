jQuery(function ($) {
  'use strict';

  var plugin = window.awebooking;

  var ajaxCustomerData = function( customer ) {
    $.ajax({
      type: 'GET',
      url: plugin.route( '/ajax/customer-data/' + customer ),
      data: {},
      error: function() {},
      success: function(res) {
        $.each(res, function(index, value) {
          var $input = $('#' + index);

          if ( ! $input.val() ) {
            $input.val(value).trigger('change');

            if ($input.hasClass('selectized') && $input[0].selectize) {
              $input[0].selectize.setValue(value);
            }
          }
        });
      }
    });
  };

  $('#_customer_id').on('change', function() {
    var customer = this.value;

    if ( customer ) {
      ajaxCustomerData(customer);
    }
  });
});
