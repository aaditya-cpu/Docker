<?php
namespace AweBooking\Fees;

use AweBooking\Fees\Metabox\Global_Fee_Metabox;
use AweBooking\Fees\Metabox\Fee_Conditions_Metabox;
use AweBooking\Fees\Model\Global_Fee;
use AweBooking\Support\Service_Provider as Base_Service_Provider;

class Service_Provider extends Base_Service_Provider {
	/**
	 * Registers services on the plugin.
	 *
	 * @access private
	 */
	public function register() {
		include __DIR__ . '/functions.php';

		load_plugin_textdomain( 'awebooking', false, basename( dirname( __DIR__ ) ) . '/languages' );

		// $this->plugin->tag( Fees_Setting::class, 'settings' );
		$this->plugin->tag( [ Global_Fee_Metabox::class, Fee_Conditions_Metabox::class ], 'metaboxes' );

		$this->plugin
			->relationships()
			->register( 'abrs_fees_to_rooms', 'hotel_fee', 'room_type' );
	}

	/**
	 * Init service provider.
	 *
	 * @return void
	 */
	public function init() {
		$this->register_post_types();

		add_filter( 'abrs_admin_screens', function ( $screens ) {
			$screens[] = 'hotel_fee';

			return $screens;
		});

		add_action( 'abrs_reservation_fees', [ $this, 'add_fees' ] );
	}

	/**
	 *
	 * @param \AweBooking\Reservation\Reservation $reservation
	 */
	public function add_fees( $reservation ) {
		$room_ids = $reservation->get_room_stays()
			->map( function( $rs ) {
				return $rs->data->room_type->get_id();
			})->values()->unique()->all();

		if ( ! $room_ids ) {
			return;
		}

		$fees_ids = awebooking()
			->relationships()
			->get( 'abrs_fees_to_rooms' )
			->find( [
				'from'      => $room_ids,
				'direction' => 'to',
			] );

		$fees_ids = wp_list_pluck( (array) $fees_ids, 'rel_from' );
		if ( ! $fees_ids ) {
			return;
		}

		$fees = new \WP_Query( [
			'post__in'       => $fees_ids,
			'post_type'      => 'hotel_fee',
			'posts_per_page' => -1,
		] );

		foreach ( $fees->posts as $fee ) {
			$fee = new Global_Fee( $fee );

			if ( ! $fee->passed( $reservation ) ) {
				continue;
			}

			$reservation->add_fee([
				'id'     => $fee->get_id(),
				'name'   => $fee->get( 'name' ),
				'amount' => $fee->get( 'amount' ),
			]);
		}
	}

	/**
	 * Register the fee CPT.
	 *
	 * @access private
	 */
	protected function register_post_types() {
		register_post_type( 'hotel_fee', apply_filters( 'abrs_register_fee_args', [
			'labels'              => [
				'name'                  => esc_html_x( 'Fees', 'Rate plural name', 'awebooking-fees' ),
				'singular_name'         => esc_html_x( 'Rate', 'Rate singular name', 'awebooking-fees' ),
				'menu_name'             => esc_html_x( 'Fees', 'Admin menu name', 'awebooking-fees' ),
				'add_new'               => esc_html__( 'Add fee', 'awebooking-fees' ),
				'add_new_item'          => esc_html__( 'Add new fee', 'awebooking-fees' ),
				'edit'                  => esc_html__( 'Edit', 'awebooking-fees' ),
				'edit_item'             => esc_html__( 'Edit fee', 'awebooking-fees' ),
				'new_item'              => esc_html__( 'New fee', 'awebooking-fees' ),
				'view_item'             => esc_html__( 'View fee', 'awebooking-fees' ),
				'search_items'          => esc_html__( 'Query fees', 'awebooking-fees' ),
				'not_found'             => esc_html__( 'No fees found', 'awebooking-fees' ),
				'not_found_in_trash'    => esc_html__( 'No fees found in trash', 'awebooking-fees' ),
				'parent'                => esc_html__( 'Parent fees', 'awebooking-fees' ),
				'filter_items_list'     => esc_html__( 'Filter fees', 'awebooking-fees' ),
				'items_list_navigation' => esc_html__( 'Fees navigation', 'awebooking-fees' ),
				'items_list'            => esc_html__( 'Fees List', 'awebooking-fees' ),
			],
			'description'         => esc_html__( 'This is where store fees are stored.', 'awebooking-fees' ),
			'public'              => false,
			'hierarchical'        => false,
			'exclude_from_search' => true,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_menu'        => 'edit.php?post_type=room_type',
			'show_in_nav_menus'   => false,
			'show_in_admin_bar'   => false,
			'show_in_rest'        => true,
			'map_meta_cap'        => true,
			// 'capability_type'     => Constants::HOTEL_RATE,
			'supports'            => [ 'title' ],
			'rewrite'             => false,
			'has_archive'         => false,
		]));
	}
}
