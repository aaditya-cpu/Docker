<?php

namespace AweBooking\Calendar\Exceptions;

class StoreNotSupportedException extends \RuntimeException {}
