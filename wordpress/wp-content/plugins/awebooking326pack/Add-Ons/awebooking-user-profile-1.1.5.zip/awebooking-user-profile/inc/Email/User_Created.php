<?php
namespace AweBooking\User_Profile\Email;

use AweBooking\Email\Mailable;

class User_Created extends Mailable {
	/**
	 * The user data.
	 *
	 * @var \WP_User
	 */
	protected $user;

	/**
	 * {@inheritdoc}
	 */
	public function setup() {
		$this->id             = 'user_created';
		$this->title          = esc_html__( 'User created', 'awebooking-user-profile' );
		$this->description    = esc_html__( 'User created emails are sent to user when their created.', 'awebooking-user-profile' );
		$this->customer_email = true;
		$this->placeholders   = [];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function prepare_data( $user ) {
		if ( $user = get_user_by( 'ID', $user ) ) {
			$this->user      = $user;
			$this->recipient = $user->user_email;
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_subject() {
		return esc_html__( 'Your account on {site_title}', 'awebooking-user-profile' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_heading() {
		return esc_html__( 'Welcome to {site_title}', 'awebooking-user-profile' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_content_html() {
		return awebooking_user_get_template( 'user/emails/user-new-account.php', [
			'email'      => $this,
			'content'    => $this->format_string( $this->get_option( 'content' ) ),
			'user_login' => $this->user->user_login,
		] );
	}
}
