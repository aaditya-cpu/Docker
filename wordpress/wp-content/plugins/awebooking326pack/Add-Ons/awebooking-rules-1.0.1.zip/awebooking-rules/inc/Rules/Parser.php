<?php
namespace AweBooking\Rules\Rules;

use Ruler\Operator\LogicalOr;
use Ruler\Operator\LogicalAnd;
use AweBooking\Component\Ruler\Variable;
use AweBooking\Component\Ruler\Rule as Ruler;

class Parser {
	/**
	 * The filters instance.
	 *
	 * @var Filters|null
	 */
	protected $filters;

	/**
	 * An array of mapping rules operators.
	 *
	 * @var array
	 */
	protected $dictionary = [
		'equal'            => \AweBooking\Component\Ruler\Operator\Equal::class,
		'not_equal'        => \AweBooking\Component\Ruler\Operator\Not_Equal::class,
		'in'               => \AweBooking\Component\Ruler\Operator\In::class,
		'not_in'           => \AweBooking\Component\Ruler\Operator\Not_In::class,
		'less'             => \AweBooking\Component\Ruler\Operator\Less_Than::class,
		'less_or_equal'    => \AweBooking\Component\Ruler\Operator\Less_Than_Or_Equal::class,
		'greater'          => \AweBooking\Component\Ruler\Operator\Greater_Than::class,
		'greater_or_equal' => \AweBooking\Component\Ruler\Operator\Greater_Than_Or_Equal::class,
		'between'          => \AweBooking\Component\Ruler\Operator\Between::class,
		'not_between'      => \AweBooking\Component\Ruler\Operator\Not_Between::class,
		'begins_with'      => \AweBooking\Component\Ruler\Operator\Starts_With::class,
		'not_begins_with'  => \AweBooking\Component\Ruler\Operator\Not_Starts_With::class,
		'contains'         => \AweBooking\Component\Ruler\Operator\String_Contains::class,
		'not_contains'     => \AweBooking\Component\Ruler\Operator\String_Does_Not_Contain::class,
		'ends_with'        => \AweBooking\Component\Ruler\Operator\Ends_With::class,
		'not_ends_with'    => \AweBooking\Component\Ruler\Operator\Not_Ends_With::class,
		'is_empty'         => \AweBooking\Component\Ruler\Operator\Is_Empty::class,
		'is_not_empty'     => \AweBooking\Component\Ruler\Operator\Is_Not_Empty::class,
		'is_null'          => \AweBooking\Component\Ruler\Operator\Is_Null::class,
		'is_not_null'      => \AweBooking\Component\Ruler\Operator\Is_Not_Null::class,
	];

	/**
	 * Constructor sanitizer.
	 *
	 * @param Filters $filters Optional, restrict only in the filters.
	 */
	public function __construct( Filters $filters = null ) {
		$this->filters = $filters;
	}

	/**
	 * Returns mapping rules operators.
	 *
	 * @return array
	 */
	public function get_dictionary() {
		return $this->dictionary;
	}

	/**
	 * Parse the query.
	 *
	 * @param  array $query The builder query.
	 * @return \AweBooking\Component\Ruler\Rule
	 *
	 * @throws \InvalidArgumentException
	 */
	public function parse( array $query ) {
		$query = ( new Sanitizer( $this->filters ) )
			->sanitize( $query );

		if ( is_null( $query ) ) {
			throw new \InvalidArgumentException( 'Invalid query to parse.' );
		}

		return new Ruler( $this->create_operator(
			$query['rules'], $query['condition']
		) );
	}

	/**
	 * Create the logical operator.
	 *
	 * @param  array  $rules     Rule array.
	 * @param  string $condition Rule condition.
	 * @return LogicalOr|LogicalAnd
	 */
	protected function create_operator( array $rules, $condition ) {
		$props = [];

		foreach ( $rules as $rule ) {
			if ( isset( $rule['condition'], $rule['rules'] ) ) {
				$props[]  = $this->create_operator( $rule['rules'], $rule['condition'] );
			} else {
				$operator = $this->dictionary[ $rule['operator'] ];
				$props[]  = new $operator( new Variable( $rule['id'] ), new Variable( null, $rule['value'] ) );
			}
		}

		if ( Rule::COR === $condition && count( $props ) > 1 ) {
			return new LogicalOr( $props );
		}

		return new LogicalAnd( $props );
	}
}
