<?php
/**
 * Account template
 * 
 * @author 		Awethemes <awethemes.com>
 * @package 	AweBooking\User
 * @since 1.0
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>

<?php do_action( 'awebooking\user\before_account_content' ); ?>
<div class="awebooking_user">
	<div class="awebooking_user__nav">
		<?php do_action( 'awebooking\user\navigation' ); ?>
	</div>

	<div class="awebooking_user__content">
		<?php
		/**
		 * Hook Account content here.
		 * @hooked awebooking_user_print_alerts();
		 * @since 1.0
		 */
		do_action( 'awebooking\user\content' );
		?>
	</div>
</div>
<?php
do_action( 'awebooking\user\after_account_content' );
