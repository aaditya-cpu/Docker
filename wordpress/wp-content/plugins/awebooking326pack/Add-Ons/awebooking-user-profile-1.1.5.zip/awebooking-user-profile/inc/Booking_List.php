<?php

namespace AweBooking\User_Profile;

class Booking_List {
	public function columns() {
		return apply_filters( 'awebooking\user\booking_columns', [
			'booking_status'  => esc_html__( 'Status', 'awebooking-user-profile' ),
			'booking_title'   => esc_html__( 'Booking', 'awebooking-user-profile' ),
			'booking_total'   => esc_html__( 'Total', 'awebooking-user-profile' ),
			'booking_date'    => esc_html__( 'Date', 'awebooking-user-profile' ),
			'booking_actions' => '&nbsp;',
		] );
	}

	public function get_list() {

		$customer_orders = get_posts( apply_filters( 'awebooking\user\orders_query', [
			'numberposts' => 10,
			'meta_key'    => '_customer_id',
			'meta_value'  => get_current_user_id(),
			'post_type'   => 'awebooking',
			'post_status' => array_keys( awebooking( 'setting' )->get_booking_statuses() ),
		] ) );

		return $customer_orders;
	}

	public function columns_display( $column, $the_booking ) {
		$detail_url = awebooking_user_get_account_endpoint_url( 'view-booking', $the_booking->get_id() );

		switch ( $column ) {
			case 'booking_title':
				if ( $the_booking['customer_id'] ) {
					$userdata = get_userdata( $the_booking['customer_id'] );
					$username = $userdata ? sprintf( '<a href="%s">%s</a></br>', esc_url( awebooking_user_get_account_endpoint_url( 'profile' ) ), esc_html( $userdata->display_name ) ) : '';
				} elseif ( $the_booking['customer_company'] ) {
					$username = trim( $the_booking->get( 'customer_company' ) );
				} else {
					$username = esc_html__( 'Guest', 'aweboking-user-profile' );
				}

				$html = sprintf( esc_html__( '%1$s by %2$s', 'aweboking-user-profile' ),
					'<a href="' . $detail_url . '" class="row-title"><strong>#' . esc_attr( $the_booking->get_id() ) . '</strong></a>',
					$username
				);

				if ( $the_booking['customer_email'] ) {
					$html .= '<small class="meta email"><a href="' . esc_url( 'mailto:' . $the_booking->get_customer_email() ) . '">' . esc_html( $the_booking->get_customer_email() ) . '</a></small>';
				}

				echo apply_filters( 'abrs_user_booking_title', $html, $the_booking );
				break;

			case 'booking_status':
				$the_booking->booking_detail_status();
				break;

			case 'booking_total':
				$the_booking->booking_detail_total();
				break;

			case 'booking_date':
				printf( '<abbr title="%s">%s</abbr>', esc_attr( $the_booking->get( 'date_created' ) ),
					esc_html( $the_booking->get( 'date_created' ) )
				);
				break;

			case 'booking_actions':
				echo '<a href="' . esc_url( $detail_url ) . '" class="button button-view">' . esc_html( 'View', 'awebooking-user-profile' ) . '</a>';
				break;
		}
	}
}
