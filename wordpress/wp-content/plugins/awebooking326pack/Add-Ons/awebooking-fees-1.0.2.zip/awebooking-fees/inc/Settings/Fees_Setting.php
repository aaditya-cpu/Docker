<?php
namespace AweBooking\Fees\Settings;

use AweBooking\Admin\Settings\Abstract_Setting;

class Fees_Setting extends Abstract_Setting {
	/**
	 * {@inheritdoc}
	 */
	public function setup() {
		$this->form_id  = 'fees';
		$this->label    = esc_html__( 'Fees', 'awebooking-fees' );
		$this->priority = 35;
	}
}
