<?php
namespace AweBooking\Payment\Gateways;

use WP_Error;
use Omnipay\Omnipay;
use Awethemes\Http\Request;
use AweBooking\Model\Booking;
use AweBooking\Gateway\Gateway;

abstract class Omnipay_Gateway extends Gateway {
	use Traits\CreditCard,
		Traits\Process_Actions;

	/**
	 * The omnipay gateway instance.
	 *
	 * @var \Closure of \Omnipay\Common\AbstractGateway
	 */
	protected $gateway;

	/**
	 * Store the gateway instance.
	 *
	 * @var \Omnipay\Common\AbstractGateway
	 */
	protected $gateway_instance;

	/**
	 * Gets the omnipay gateway instance.
	 *
	 * @return \Omnipay\Common\AbstractGateway
	 *
	 * @throws \RuntimeException
	 */
	public function get_gateway() {
		if ( null === $this->gateway ) {
			throw new \RuntimeException( 'Please setup the gateway before call this method.' );
		}

		if ( $this->gateway_instance ) {
			return $this->gateway_instance;
		}

		return $this->gateway_instance = call_user_func( $this->gateway );
	}

	/**
	 * Create the gateway.
	 *
	 * @param string $gateway    The omnipay gateway.
	 * @param array  $parameters the omnipay gateway parameters.
	 *
	 * @return \Closure of \Omnipay\Common\GatewayInterface
	 */
	protected function create_gateway( $gateway, array $parameters ) {
		return function () use ( $gateway, $parameters ) {
			$gateway = Omnipay::create( $gateway );

			$gateway->initialize( $parameters );

			return $gateway;
		};
	}

	/**
	 * Is the sandbox enabled?
	 *
	 * @return bool
	 */
	public function sandbox() {
		return 'on' === $this->get_option( 'sandbox', 'off' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function display_fields() {
		parent::display_fields();

		if ( $this->is_support( 'card' ) ) {
			echo '<div class="payment-method__controls">';
			$this->show_card_form();
			echo '</div>';
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function validate_fields( $data, Request $request ) {
		if ( $this->is_support( 'card' ) ) {
			try {
				$this->get_card( $request )->validate();
			} catch ( \Exception $e ) {
				return new WP_Error( 'card', $e->getMessage() ?: esc_html__( 'The credit card number is required', 'awebooking-payment' ) );
			}
		}

		return true;
	}

	/**
	 * Gets the omnipay items.
	 *
	 * @param \AweBooking\Model\Booking $booking The booking.
	 * @return array
	 */
	protected function get_items( Booking $booking ) {
		return [];
	}
}
