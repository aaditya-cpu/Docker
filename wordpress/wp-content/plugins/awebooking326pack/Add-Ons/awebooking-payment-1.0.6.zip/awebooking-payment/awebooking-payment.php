<?php
/**
 * Plugin Name:     AweBooking Payment
 * Plugin URI:      http://awethemes.com/plugins/awebooking
 * Description:     Allows you to enable payments online via gateways in guest checkout.
 * Author:          awethemes
 * Author URI:      http://awethemes.com
 * Text Domain:     awebooking-payment
 * Domain Path:     /languages
 * Version:         1.0.6
 *
 * @package         AweBooking/Payment
 */

if ( ! defined( 'ABRS_PAYMENT_VERSION' ) ) {
	require trailingslashit( __DIR__ ) . 'vendor/autoload.php';

	/* Constants */
	define( 'ABRS_PAYMENT_VERSION', '1.0.6' );
	define( 'ABRS_PAYMENT_PLUGIN_FILE', __FILE__ );
	define( 'ABRS_PAYMENT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
	define( 'ABRS_PAYMENT_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

	/* Define the premium constant */
	if ( ! defined( 'ABRS_PREMIUM' ) ) {
		define( 'ABRS_PREMIUM', true );
	}

	/* Init the addon */
	add_action( 'awebooking_init', function( $plugin ) {
		require trailingslashit( __DIR__ ) . '/inc/functions.php';

		/* @var \AweBooking\Plugin $plugin */
		$plugin->provider( \AweBooking\Payment\Service_Provider::class );
	});
}
