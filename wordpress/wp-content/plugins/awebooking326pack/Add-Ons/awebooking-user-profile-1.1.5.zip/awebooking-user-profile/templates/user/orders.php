<?php
/**
 * Bookings
 *
 * @author        Awethemes <awethemes.com>
 * @package       AweBooking\User
 * @since         1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<h2><?php echo apply_filters( 'abrs_user_orders_title', __( 'Recent bookings', 'awebooking-user-profile' ) ); ?></h2>

<?php if ( $customer_bookings ) : ?>
	<div class="awebooking-bookings-table-wrapper">
		<table class="awebooking_user_orders">
			<thead>
			<tr>
				<?php foreach ( $booking_columns as $column_id => $column_name ) : ?>
					<th class="<?php echo esc_attr( $column_id ); ?>"><span class="nobr"><?php echo esc_html( $column_name ); ?></span></th>
				<?php endforeach; ?>
			</tr>
			</thead>

			<tbody>
			<?php
			foreach ( $customer_bookings as $customer_booking ) :
				$booking = new AweBooking\User_Profile\Booking_Detail( $customer_booking->ID );
				?>
				<tr class="booking-item">
					<?php foreach ( $booking_columns as $column_id => $column_name ) : ?>
						<td class="<?php echo esc_attr( $column_id ); ?>" data-title="<?php echo esc_attr( $column_name ); ?>">
							<?php $booking_list->columns_display( $column_id, $booking ); ?>
						</td>
					<?php endforeach; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php
else:
	printf( '<p class="empty-booking-list">%s</p>', esc_html__( 'There is no recent booking to display,', 'awebooking-user-profile' ) );

endif;
