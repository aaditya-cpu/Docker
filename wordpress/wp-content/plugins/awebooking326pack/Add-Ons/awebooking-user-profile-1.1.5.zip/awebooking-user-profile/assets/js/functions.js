jQuery(function ($) {
    'use strict';
    /*
     * Process upload profile image
     */
    var profile_image_dropped = false;
    var $profile_drag = $('.js-user-avatar .awebooking_user-file-drag');
    $profile_drag.on('drag dragstart dragend dragover dragenter dragleave drop', function (e) {
        e.preventDefault();
        e.stopPropagation();
    }).on('dragover dragenter', function () {
        $profile_drag.addClass('dragover');
    })
            .on('dragleave dragend drop', function () {
                $profile_drag.removeClass('dragover');
            })
            .on('drop', function (e) {
                profile_image_dropped = e.originalEvent.dataTransfer.files;
                $profile_drag.find('input[type="file"]').prop('files', profile_image_dropped);
            });


    $('.js-user-avatar .awebooking_user-file-drag input[type="file"]').change(function () {
        $('.dragover').removeClass('dragover');
        if (this.files && this.files[0]) {
            previewResizeImage({
                file: this.files[0],
                width: 300,
                height: 300,
                callback: function (thumbURL) {
                    $('.js-user-avatar #user_remove_avatar').val(0);
                    $('.js-user-avatar .awebooking_user-file-drag').addClass('has-image').css('background-image', 'url(' + thumbURL + ')');
                }
            });
        }
    });

    $('.js-user-avatar .awebooking_user-file-drag .remove').click(function (e) {
        e.preventDefault();
        $('.js-user-avatar #user_remove_avatar').val(1);
        $('.js-user-avatar .awebooking_user-file-drag').removeClass('has-image').removeAttr('style');

    });


    $('.hide-if-no-js').show();
    $('.hide-if-js').hide();

    $('.awebooking_can_edit .item-button-edit').on('click', function (e) {

        var $this = $(this);
        $this.closest('.awebooking_can_edit').find('.item-group_edit').show();
        $this.parent().hide();
        e.preventDefault();
    });

    $('.awebooking_can_edit .item-button-cancel').on('click', function (e) {

        var $this = $(this);
        $this.closest('.awebooking_can_edit').find('.item-group_view').show();
        $this.parent().hide();

        e.preventDefault();
    });

    $('.js-customer_update_note').on('click', function (e) {

        var $this = $(this);

        $.ajax({
            type: 'POST',
            url: awebooking_user.url.ajax,
            data: {
                action: 'awebooking_user_edit_customer_note',
                nonce: $('#customer_note').val(),
                customer_note: $this.parent().find('textarea').val(),
                id_booking: $('#booking_id').val()
            },
            success: function (res) {
                if (res.success) {
                    $this.closest('.awebooking_can_edit').find('.item-group_view span').text(res.data);
                    $('.awebooking_can_edit .item-button-cancel').trigger('click');
                }
            }
        });

        e.preventDefault();
    });
});

function previewResizeImage(args) {
    var reader = new FileReader();
    reader.onloadend = function () {

        var tempImg = new Image();
        tempImg.src = reader.result;
        tempImg.onload = function () {

            var MAX_WIDTH = args.width;
            var MAX_HEIGHT = args.height;
            var tempW = tempImg.width;
            var tempH = tempImg.height;
            if (tempW > tempH) {
                if (tempW > MAX_WIDTH) {
                    tempH *= MAX_WIDTH / tempW;
                    tempW = MAX_WIDTH;
                }
            } else {
                if (tempH > MAX_HEIGHT) {
                    tempW *= MAX_HEIGHT / tempH;
                    tempH = MAX_HEIGHT;
                }
            }

            var canvas = document.createElement('canvas');
            canvas.width = tempW;
            canvas.height = tempH;
            var ctx = canvas.getContext("2d");
            ctx.drawImage(this, 0, 0, tempW, tempH);
            var thumbURL = canvas.toDataURL("image/jpeg");
            if (typeof args.callback == 'function') {
                args.callback(thumbURL);
            }
        }

    }
    reader.readAsDataURL(args.file);
}
