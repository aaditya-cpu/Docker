<?php

/**
 * Page Functions
 *
 * Functions related to pages and menus.
 *
 */


/**
 * Retrieve page permalink.
 *
 * @since 1.0
 *
 * @param string $page
 *
 * @return string
 */
function awebooking_user_get_page_permalink( $page ) {
	$page_id = abrs_get_option( 'user_page_id', 0 );

	$permalink = $page_id > 0 ? get_permalink( $page_id ) : get_home_url();

	return apply_filters( 'awebooking\user\get_' . $page . '_page_permalink', $permalink );
}

/**
 * Get endpoint URL.
 *
 * Gets the URL for an endpoint, which varies depending on permalink settings.
 *
 * @since 1.0
 *
 * @param  string $endpoint
 * @param  string $value
 * @param  string $permalink
 *
 * @return string
 */
function awebooking_user_get_endpoint_url( $endpoint, $value = '', $permalink = '' ) {

	if ( ! $permalink ) {
		$permalink = get_permalink();
	}

	// Map endpoint to options
	$endpoint = ! empty( awebooking_user()->query->query_vars[ $endpoint ] ) ? awebooking_user()->query->query_vars[ $endpoint ] : $endpoint;

	if ( get_option( 'permalink_structure' ) ) {
		if ( strstr( $permalink, '?' ) ) {

			$query_string = '?' . parse_url( $permalink, PHP_URL_QUERY );
			$permalink    = current( explode( '?', $permalink ) );
		} else {
			$query_string = '';
		}

		$url = trailingslashit( $permalink ) . $endpoint . '/' . $value . $query_string;
	} else {

		$url = add_query_arg( $endpoint, $value, $permalink );
	}

	return apply_filters( 'awebooking\user\get_endpoint_url', $url, $endpoint, $value, $permalink );
}

/**
 * Hide menu items conditionally.
 *
 * @since 1.0
 *
 * @param array $items
 *
 * @return array
 */
function awebooking_user_nav_menu_items( $items ) {
	if ( ! is_user_logged_in() ) {
		$user_logout = 'user-logout';

		if ( ! empty( $user_logout ) ) {
			foreach ( $items as $key => $item ) {
				$path  = parse_url( $item->url, PHP_URL_PATH );
				$query = parse_url( $item->url, PHP_URL_QUERY );
				if ( strstr( $path, $user_logout ) || strstr( $query, $user_logout ) ) {
					unset( $items[ $key ] );
				}
			}
		}
	}

	return $items;
}

add_filter( 'wp_nav_menu_objects', 'awebooking_user_nav_menu_items', 10 );

/**
 * Fix active class in nav for shop page.
 *
 * @since 1.0
 *
 * @param array $menu_items
 *
 * @return array
 */
function awebooking_user_nav_menu_item_classes( $menu_items ) {

	if ( ! is_awebooking_user() ) {
		return $menu_items;
	}

	foreach ( (array) $menu_items as $key => $menu_item ) {

		$classes = (array) $menu_item->classes;

		$menu_items[ $key ]->classes = array_unique( $classes );
	}

	return $menu_items;
}

add_filter( 'wp_nav_menu_objects', 'awebooking_user_nav_menu_item_classes', 2 );
