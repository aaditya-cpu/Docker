<?php
/**
 * Show info messages
 * @author 		Awethemes <awethemes.com>
 * @package 	AweBooking\User
 * @since 1.0
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !$messages ) {
	return;
}
?>

<?php foreach ( $messages as $message ) : ?>
	<div class="alert alert-info alert-dismissible" role="alert">
        <div class="message">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <?php echo wp_kses_post( $message ); ?>
        </div>
	</div>
	<?php
endforeach;
