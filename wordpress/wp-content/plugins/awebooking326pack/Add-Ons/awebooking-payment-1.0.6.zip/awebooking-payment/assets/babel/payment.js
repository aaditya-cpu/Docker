import Gateway from './src/gateway'

(function ($, awebooking) {
  'use strict'

  awebooking.checkout = {}
  awebooking.checkout.Gateway = Gateway

  awebooking.checkout.selected = void 0
  awebooking.checkout.selectedGateway = void 0

  $(function() {
    $(document).trigger('abrs_checkout_init', awebooking.checkout)

    // Setup the gateways.
    $.each(Gateway.instances, function (name, gateway) {
      if (gateway.isAvailable()) {
        gateway.setup({})
        gateway.getCardElement() && gateway.createCard()
      }
    })

    // Handle selected payment.
    $('#payment-methods').on('selected.awebooking.gateway', (e, gateway) => {
      awebooking.checkout.selected = gateway

      if (awebooking.checkout.selectedGateway) {
        awebooking.checkout.selectedGateway.off()
      }

      awebooking.checkout.selectedGateway = Gateway.get(gateway)
    })

    // Handle checkout form.
    $('#checkout-form').on('submit', (e) => {
      if (awebooking.checkout.selected && awebooking.checkout.selectedGateway) {
        e.preventDefault()
        awebooking.checkout.selectedGateway.on(e)
      }
    })
  })

})(window.jQuery, window.awebooking || {})
