<?php
/**
 * Lost Password form
 *
 * @author 		Awethemes <awethemes.com>
 * @package 	AweBooking\User
 * @since 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}?>
<?php awebooking_user_print_alerts();  ?>

<form method="post" class="awebooking_user-reset-password lost_reset_password">

	<p><?php echo apply_filters( 'awebooking\user\lost_password_message', __( 'Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.', 'awebooking-user-profile' ) ); ?></p>

	<p class="form-row form-row-first">
		<label for="user_login"><?php _e( 'Username or email', 'awebooking-user-profile' ); ?></label>
		<input class="input-text" type="text" name="user_login" id="user_login" />
	</p>

	<div class="clear"></div>

	<?php do_action( 'awebooking\user\lostpassword_form' ); ?>

	<p class="form-row">
		<input type="hidden" name="awebooking_user_reset_password" value="true" />
		<input type="submit" class="awebooking_user-button button" value="<?php esc_attr_e( 'Reset Password', 'awebooking-user-profile' ); ?>" />
	</p>

	<?php wp_nonce_field( 'lost_password' ); ?>

</form>
