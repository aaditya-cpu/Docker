<?php
namespace AweBooking\User_Profile\Controllers;

use Awethemes\Http\Json_Response;
use Awethemes\Http\Request;

class Ajax_Controller {

	/**
	 * Query for customer data.
	 *
	 * @param  \Awethemes\Http\Request $request The current request.
	 *
	 * @return mixed
	 */
	public function customer_data( Request $request, $customer ) {
		$customer = get_user_by( 'ID', $customer );

		if ( ! $customer ) {
			return new Json_Response( [ 'error' => 'User not found.' ], 404 );
		}

		$user_data = [
			'customer_title'       => $this->get_user_meta( $customer->ID, 'customer_title' ),
			'customer_first_name'  => $this->get_user_meta( $customer->ID, 'customer_first_name' ),
			'customer_last_name'   => $this->get_user_meta( $customer->ID, 'customer_last_name' ),
			'customer_company'     => $this->get_user_meta( $customer->ID, 'customer_company' ),
			'customer_address'     => $this->get_user_meta( $customer->ID, 'customer_address' ),
			'customer_address_2'   => $this->get_user_meta( $customer->ID, 'customer_address_2' ),
			'customer_city'        => $this->get_user_meta( $customer->ID, 'customer_city' ),
			'customer_state'       => $this->get_user_meta( $customer->ID, 'customer_state' ),
			'customer_country'     => $this->get_user_meta( $customer->ID, 'customer_country' ),
			'customer_postal_code' => $this->get_user_meta( $customer->ID, 'customer_postal_code' ),
			'customer_phone'       => $this->get_user_meta( $customer->ID, 'customer_phone' ),
			'customer_email'       => $this->get_user_meta( $customer->ID, 'customer_email' ),
		];

		return $user_data;
	}

	/**
	 * Get user meta for a given key, with fallbacks to core user info for pre-existing fields.
	 *
	 * @param int    $user_id User ID of the user being edited.
	 * @param string $key     Key for user meta field.
	 *
	 * @return string
	 */
	protected function get_user_meta( $user_id, $key ) {
		$value           = get_user_meta( $user_id, $key, true );
		$existing_fields = [ 'customer_first_name', 'customer_last_name' ];
		if ( ! $value && in_array( $key, $existing_fields ) ) {
			$value = get_user_meta( $user_id, str_replace( 'customer_', '', $key ), true );
		} elseif ( ! $value && ( 'customer_email' === $key ) ) {
			$user  = get_userdata( $user_id );
			$value = $user->user_email;
		}

		return $value;
	}
}
