<?php
namespace AweBooking\Component\ICalendar\Exceptions;

class ReadingException extends \RuntimeException {}
