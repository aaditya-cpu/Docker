<?php
/**
 * User reset password email template.
 *
 * @see      http://docs.awethemes.com/awebooking/developers/theme-developers/
 * @author   awethemes
 * @package  AweBooking
 * @version  3.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abrs_mailer()->header( $email );

?>

<p><?php echo esc_html__( 'Someone requested that the password be reset for the following account:', 'awebooking-user-profile' ); ?></p>
<p><?php echo esc_html__( 'Username:', 'awebooking-user-profile' ); ?><strong><?php echo esc_attr( $user_login ) ?> </strong></p>
<p><?php echo esc_html__( 'If this was a mistake, just ignore this email and nothing will happen.', 'awebooking-user-profile' ); ?></p>
<p><?php echo esc_html__( 'To reset your password, visit the following address:', 'awebooking-user-profile' ); ?></p>
<p><a class="link" href="<?php echo esc_url( add_query_arg( array( 'key' => $reset_key, 'login' => rawurlencode( $user_login ), 'action' => 'resetpwd' ), wp_lostpassword_url() ) ); ?>"><?php _e( 'Click here to reset your password', 'awebooking-user-profile' ); ?></a></p>

<?php abrs_mailer()->footer( $email );
