<?php wp_enqueue_style( 'awebooking-rules' ); ?>
<?php wp_enqueue_script( 'awebooking-rules' ); ?>

<div class="awebooking-rules" data-init="awebooking-rules">
	<?php echo $types->input( [ 'type' => 'hidden' ] ); // @codingStandardsIgnoreLine ?>
</div>
