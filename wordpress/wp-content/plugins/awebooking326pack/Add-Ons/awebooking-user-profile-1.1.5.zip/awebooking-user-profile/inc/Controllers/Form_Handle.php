<?php
namespace AweBooking\User_Profile\Controllers;

use AweBooking\Checkout\Form_Controls;
use AweBooking\Model\Booking;
use AweBooking\Support\Fluent;
use AweBooking\User_Profile\Shortcodes;

class Form_Handle {
	/**
	 * Hook in methods.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'template_redirect', [ $this, 'redirect_reset_password_link' ] );
		add_action( 'template_redirect', [ $this, 'redirect_verify_account' ] );
		add_action( 'template_redirect', [ $this, 'save_user_profile' ] );
		add_action( 'template_redirect', [ $this, 'save_booking_info' ] );
		add_action( 'template_redirect', [ $this, 'cancel_booking' ] );

		add_action( 'wp_loaded', [ $this, 'process_login' ], 20 );
		add_action( 'wp_loaded', [ $this, 'process_registration' ], 20 );
		add_action( 'wp_loaded', [ $this, 'process_lost_password' ], 20 );
		add_action( 'wp_loaded', [ $this, 'process_reset_password' ], 20 );
		add_action( 'awebooking_created_customer', [ $this, 'send_created_account_mails' ], 10, 2 );
		add_filter( 'abrs_checkout_controls', [ $this, 'fill_checkout_form_data' ] );
	}

	/**
	 * Remove key and login from querystring, set cookie, and redirect to account page to show the form.
	 *
	 * @return void
	 */
	public function redirect_reset_password_link() {
		if ( isset( $_GET['action'] ) && 'resetpwd' === $_GET['action'] ) {
			if ( is_awebooking_user_page() && ! empty( $_GET['key'] ) && ! empty( $_GET['login'] ) ) {
				$value = sprintf( '%s:%s', wp_unslash( $_GET['login'] ), wp_unslash( $_GET['key'] ) );
				Shortcodes::set_reset_password_cookie( $value );

				wp_safe_redirect( add_query_arg( 'show-reset-form', 'true', awebooking_user_get_endpoint_url( 'lost-password' ) ) );
				exit;
			}
		}
	}

	/**
	 * Save the user profile
	 *
	 * @return void
	 */
	public function save_user_profile() {
		if ( 'POST' !== strtoupper( $_SERVER['REQUEST_METHOD'] ) ) {
			return;
		}

		if ( empty( $_POST['action'] ) || 'user-profile' !== $_POST['action'] || empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'],
				'awebooking_user-user-profile' ) ) {
			return;
		}


		$errors = new \WP_Error();
		$user   = new \stdClass();

		$user->ID     = (int) get_current_user_id();
		$current_user = get_user_by( 'id', $user->ID );

		if ( $user->ID <= 0 ) {
			return;
		}

		//Basic field
		$first_name  = ! empty( $_POST['first_name'] ) ? sanitize_text_field( $_POST['first_name'] ) : '';
		$last_name   = ! empty( $_POST['last_name'] ) ? sanitize_text_field( $_POST['last_name'] ) : '';
		$email       = ! empty( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
		$url         = ! empty( $_POST['url'] ) ? sanitize_text_field( $_POST['url'] ) : '';
		$description = ! empty( $_POST['description'] ) ? sanitize_text_field( $_POST['description'] ) : '';

		//Password
		$pass_cur  = ! empty( $_POST['password_current'] ) ? $_POST['password_current'] : '';
		$pass1     = ! empty( $_POST['password_1'] ) ? $_POST['password_1'] : '';
		$pass2     = ! empty( $_POST['password_2'] ) ? $_POST['password_2'] : '';
		$save_pass = true;

		$user->first_name  = $first_name;
		$user->last_name   = $last_name;
		$user->user_url    = $url;
		$user->description = $description;

		if ( ! empty( $first_name ) && ! empty( $last_name ) ) {
			$user->display_name = $first_name . ' ' . $last_name;
		}


		/**
		 * Update User Contact Methods
		 */
		$usercontacts = wp_get_user_contact_methods( $user );

		foreach ( $usercontacts as $method => $name ) {
			if ( isset( $_POST[ $method ] ) ) {
				$user->$method = sanitize_text_field( $_POST[ $method ] );
			}
		}

		/**
		 * Update Avatar Image
		 */
		$is_remove_current_avatar = false;
		if ( ! empty( $_FILES['user_avatar']['name'] ) ) {

			if ( strpos( $_FILES['user_avatar']['type'], 'image' ) === 0 ) {
				require_once( ABSPATH . 'wp-admin/includes/image.php' );
				require_once( ABSPATH . 'wp-admin/includes/file.php' );
				require_once( ABSPATH . 'wp-admin/includes/media.php' );

				// Let WordPress handle the upload.
				$attachment_id = media_handle_upload( 'user_avatar', 0 );

				if ( is_wp_error( $attachment_id ) ) {
					awebooking_user_add_wp_error_alerts( $attachment_id );
				} else {
					//Update New Image
					update_user_meta( $user->ID, 'image_avatar', $attachment_id );
					//Flag remove current avatar
					$is_remove_current_avatar = true;
				}
			} else {
				awebooking_user_add_alert( __( 'User avatar must be an image.', 'awebooking-user-profile' ), 'error' );
			}
		}

		/**
		 * Remove Avatar
		 */
		if ( isset( $_POST['user_remove_avatar'] ) && absint( $_POST['user_remove_avatar'] ) == 1 ) {
			//Flag remove current avatar.
			$is_remove_current_avatar = true;
		}

		if ( $is_remove_current_avatar ) {
			$current_image = ! empty( $_POST['user_curent_avatar'] ) ? absint( $_POST['user_curent_avatar'] ) : 0;
			if ( $current_image ) {
				wp_delete_attachment( $current_image, true );
			}
		}

		// Handle required fields.
		$required_fields = apply_filters( 'awebooking/user/profile_required_fields', [
			'first_name' => __( 'First Name', 'awebooking-user-profile' ),
			'last_name'  => __( 'Last Name', 'awebooking-user-profile' ),
			'email'      => __( 'Email address', 'awebooking-user-profile' ),
		] );

		foreach ( $required_fields as $field_key => $field_name ) {
			$value = sanitize_text_field( $_POST[ $field_key ] );
			if ( empty( $value ) ) {
				awebooking_user_add_alert( '<strong>' . esc_html( $field_name ) . '</strong> ' . __( 'is a required field.',
						'awebooking-user-profile' ), 'error' );
			}
		}

		if ( $email ) {
			if ( ! is_email( $email ) ) {
				awebooking_user_add_alert( __( 'Please provide a valid email address.', 'awebooking-user-profile' ),
					'error' );
			} elseif ( email_exists( $email ) && $email !== $current_user->user_email ) {
				awebooking_user_add_alert( __( 'This email address is already registered.', 'awebooking-user-profile' ),
					'error' );
			}
			$user->user_email = $email;
		}

		if ( ! empty( $pass1 ) && ! wp_check_password( $pass_cur, $current_user->user_pass, $current_user->ID ) ) {
			awebooking_user_add_alert( __( 'Your current password is incorrect.', 'awebooking-user-profile' ),
				'error' );
			$save_pass = false;
		}

		if ( ! empty( $pass_cur ) && empty( $pass1 ) && empty( $pass2 ) ) {
			awebooking_user_add_alert( __( 'Please fill out all password fields.', 'awebooking-user-profile' ),
				'error' );
			$save_pass = false;
		} elseif ( ! empty( $pass1 ) && empty( $pass_cur ) ) {
			awebooking_user_add_alert( __( 'Please enter your current password.', 'awebooking-user-profile' ),
				'error' );
			$save_pass = false;
		} elseif ( ! empty( $pass1 ) && empty( $pass2 ) ) {
			awebooking_user_add_alert( __( 'Please re-enter your password.', 'awebooking-user-profile' ), 'error' );
			$save_pass = false;
		} elseif ( ( ! empty( $pass1 ) || ! empty( $pass2 ) ) && $pass1 !== $pass2 ) {
			awebooking_user_add_alert( __( 'New passwords do not match.', 'awebooking-user-profile' ), 'error' );
			$save_pass = false;
		}

		if ( $pass1 && $save_pass ) {
			$user->user_pass = $pass1;
		}

		// Allow plugins to return their own errors.
		do_action_ref_array( 'awebooking\user\profile_errors', [ &$errors, &$user ] );

		if ( $errors->get_error_messages() ) {
			foreach ( $errors->get_error_messages() as $error ) {
				awebooking_user_add_alert( $error, 'error' );
			}
		}

		if ( awebooking_user_alert_count( 'error' ) === 0 ) {

			/**
			 * Fires before the page loads on the 'Your Profile' editing screen.
			 *
			 * The action only fires if the current user is editing their own profile.
			 *
			 * @since Wordpress 2.0.0
			 *
			 * @param int $user_id The user ID.
			 */
			do_action( 'awebooking\user\update', $user->ID );

			wp_update_user( $user );

			do_action( 'awebooking\user\save_profile', $user->ID );

			wp_safe_redirect( add_query_arg( [ 'action' => 'updated' ], awebooking_user_get_account_endpoint_url( 'profile' ) ) );
			exit();
		}
	}

	public function process_login() {
		$nonce_value = isset( $_POST['_wpnonce'] ) ? $_POST['_wpnonce'] : '';
		$nonce_value = isset( $_POST['awebooking_user-login-nonce'] ) ? $_POST['awebooking_user-login-nonce'] : $nonce_value;

		if ( ! empty( $_POST['login'] ) && wp_verify_nonce( $nonce_value, 'awebooking_user-login' ) ) {

			try {

				$user = awebooking_user_login( trim( $_POST['username'] ), $_POST['password'],
					isset( $_POST['rememberme'] ) );

				if ( $user ) {
					if ( isset( $_POST['redirect'] ) && $_POST['redirect'] ) {
						$redirect = esc_url_raw( $_POST['redirect'] );
					} elseif ( wp_get_referer() ) {
						$redirect = wp_get_referer();
					} else {
						$redirect = awebooking_user_get_page_permalink( 'user-profile' );
					}

					wp_safe_redirect( apply_filters( 'awebooking\user\login_redirect', $redirect, $user ) );
					exit;
				}
			} catch ( \Exception $e ) {
				awebooking_user_add_alert( apply_filters( 'awebooking\user\login_errors', $e->getMessage() ), 'error' );
			}
		}
	}

	/**
	 * Handle lost password form.
	 *
	 * @return void
	 */
	public function process_lost_password() {
		if ( isset( $_POST['awebooking_user_reset_password'] ) && isset( $_POST['user_login'] ) && isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'lost_password' ) ) {
			$success = Shortcodes::retrieve_password();

			// If successful, redirect to account with query arg set
			if ( $success ) {
				wp_redirect( add_query_arg( 'reset-link-sent', 'true', remove_query_arg( [ 'key', 'login', 'reset' ] ) ) );
				exit;
			}
		}
	}

	/**
	 * Handle reset password form.
	 *
	 * @return void
	 */
	public function process_reset_password() {
		$posted_fields = [
			'awebooking_user_reset_password',
			'password_1',
			'password_2',
			'reset_key',
			'reset_login',
			'_wpnonce',
		];

		foreach ( $posted_fields as $field ) {
			if ( ! isset( $_POST[ $field ] ) ) {
				return;
			}

			$posted_fields[ $field ] = $_POST[ $field ];
		}

		if ( ! wp_verify_nonce( $posted_fields['_wpnonce'], 'reset_password' ) ) {
			return;
		}

		try {
			$user = Shortcodes::check_password_reset_key( $posted_fields['reset_key'], $posted_fields['reset_login'] );
		} catch ( \Exception $ex ) {
			awebooking_user_add_alert( $ex->getMessage(), 'error' );
		}

		if ( isset( $user ) && $user instanceof \WP_User ) {
			if ( empty( $posted_fields['password_1'] ) ) {
				awebooking_user_add_alert( __( 'Please enter your password.', 'awebooking-user-profile' ), 'error' );
			}

			if ( $posted_fields['password_1'] !== $posted_fields['password_2'] ) {
				awebooking_user_add_alert( __( 'Passwords do not match.', 'awebooking-user-profile' ), 'error' );
			}

			$errors = new \WP_Error();

			do_action( 'validate_password_reset', $errors, $user );

			awebooking_user_add_wp_error_alerts( $errors );

			if ( 0 === awebooking_user_alert_count( 'error' ) ) {
				Shortcodes::reset_password( $user, $posted_fields['password_1'] );

				do_action( 'awebooking\user\reset_password', $user );

				wp_redirect( add_query_arg( 'reset', 'true',
					remove_query_arg( [ 'key', 'login', 'reset-link-sent' ] ) ) );
				exit;
			}
		}
	}

	/**
	 * Process save registration to database
	 *
	 * @return void
	 */
	public function redirect_verify_account() {
		if ( isset( $_GET['action'] ) && $_GET['action'] == 'register' ) {
			if ( is_awebooking_user_page() && ! empty( $_GET['key'] ) && ! empty( $_GET['login'] ) ) {
				/**
				 * Get verify userdata
				 */
				$userdata = get_transient( sprintf( 'awebooking_user_verify_%s', $_GET['key'] ) );

				if ( ! empty( $userdata ) ) {
					try {

						$validation_error = new \WP_Error();
						$validation_error = apply_filters( 'awebooking\user\process_registration_errors',
							$validation_error, $userdata );

						if ( $validation_error->get_error_code() ) {
							throw new \Exception( $validation_error->get_error_message() );
						}

						/**
						 * Create User
						 */
						$new_user = awebooking_user_create_user( sanitize_email( $userdata['user_email'] ),
							sanitize_text_field( $userdata['user_login'] ), base64_decode( $userdata['user_pass'] ) );

						/**
						 * Delete verify userdata
						 */
						delete_transient( sprintf( 'awebooking_user_verify_%s', $_GET['key'] ) );

						if ( is_wp_error( $new_user ) ) {
							throw new \Exception( $new_user->get_error_message() );
						}

						if ( apply_filters( 'awebooking\user\registration_auth_new_user', true, $new_user ) ) {
							awebooking_user_set_user_auth_cookie( $new_user );
						}

						wp_safe_redirect( apply_filters( 'awebooking_user_registration_redirect',
							wp_get_referer() ? wp_get_referer() : awebooking_user_get_page_permalink( 'profile' ) ) );
						exit;
					} catch ( \Exception $e ) {
						awebooking_user_add_alert( '<strong>' . __( 'Error',
								'awebooking-user-profile' ) . ':</strong> ' . $e->getMessage(), 'error' );
					}
				} elseif ( is_user_logged_in() ) {
					awebooking_user_add_alert( sprintf( __( 'Your account is logged in.', 'awebooking-user-profile' ) ),
						'warning' );
				} elseif ( get_user_by( 'login', sanitize_text_field( $_GET['login'] ) ) ) {
					awebooking_user_add_alert( sprintf( __( 'Account `%s` already existed. Please login.',
						'awebooking-user-profile' ), esc_html( $_GET['login'] ) ), 'error' );
				} else {
					awebooking_user_add_alert( sprintf( __( 'Invalid verify account `%s`. maybe your verify account has expired. Please register again.',
						'awebooking-user-profile' ), esc_html( $_GET['login'] ) ), 'error' );
				}
				wp_safe_redirect( awebooking_user_get_page_permalink( 'account' ) );
				exit();
			}
		}
	}

	/**
	 * Process the registration form.
	 *
	 * @return void
	 */
	public function process_registration() {

		$nonce_value = isset( $_POST['_wpnonce'] ) ? $_POST['_wpnonce'] : '';
		$nonce_value = isset( $_POST['awebooking_user-register-nonce'] ) ? $_POST['awebooking_user-register-nonce'] : $nonce_value;

		if ( ! isset( $_POST['register'] ) && isset( $_GET['register'] ) && $_GET['register'] == 'success' ) {

			$hash = isset( $_COOKIE['awebooking_user_verify'] ) ? sanitize_text_field( $_COOKIE['awebooking_user_verify'] ) : false;

			if ( $hash ) {
				$account = get_transient( sprintf( 'awebooking_user_verify_%s', $hash ) );
				$email   = isset( $account['user_email'] ) ? sanitize_text_field( $account['user_email'] ) : '';
				if ( $email ) {
					$timeout = get_option( '_transient_timeout_awebooking_user_verify_' . $hash );
					$timeout = human_time_diff( $timeout, current_time( 'timestamp' ) );
					awebooking_user_add_alert( sprintf( __( 'Registration successfully! A verify email was sent to %s. The verification will be expired after %s.',
						'awebooking-user-profile' ), '<strong>' . $email . '</strong>', $timeout ) );
				}
			}
		} elseif ( ! empty( $_POST['register'] ) && wp_verify_nonce( $nonce_value, 'awebooking_user-register' ) ) {

			$email            = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
			$username         = isset( $_POST['username'] ) ? $_POST['username'] : '';
			$password         = isset( $_POST['password'] ) ? $_POST['password'] : '';
			$confirm_password = isset( $_POST['confirm_password'] ) ? $_POST['confirm_password'] : '';


			try {

				$validation_error = new \WP_Error();
				$validation_error = apply_filters( 'awebooking\user\process_registration_errors', $validation_error,
					$username, $password, $email );

				if ( $validation_error->get_error_code() ) {
					throw new \Exception( $validation_error->get_error_message() );
				}

				$new_user = awebooking_user_verify_user( $email, sanitize_text_field( $username ), $password,
					$confirm_password );

				if ( is_wp_error( $new_user ) ) {
					throw new \Exception( $new_user->get_error_message() );
				}

				$url = wp_get_referer() ? wp_get_referer() : awebooking_user_get_page_permalink( 'user-profile' );

				wp_safe_redirect( apply_filters( 'awebooking\user\send_verify_registration_redirect',
					add_query_arg( [ 'register' => 'success' ], $url ) ) );

				exit;
			} catch ( \Exception $e ) {
				awebooking_user_add_alert( '<strong>' . __( 'Error',
						'awebooking-user-profile' ) . ':</strong> ' . $e->getMessage(), 'error' );
			}
		}
	}

	/**
	 * Create a new customer.
	 *
	 * @param  string $email Customer email.
	 * @param  string $username Customer username.
	 * @param  string $password Customer password.
	 * @return int|\WP_Error Returns WP_Error on failure, Int (user ID) on success.
	 */
	public static function create_new_customer( $email, $username = '', $password = '' ) {
		// Check the email address.
		if ( empty( $email ) || ! is_email( $email ) ) {
			return new \WP_Error( 'registration-error-invalid-email', __( 'Please provide a valid email address.', 'awebooking-user-profile' ) );
		}

		if ( email_exists( $email ) ) {
			return new \WP_Error( 'registration-error-email-exists', apply_filters( 'awebooking_registration_error_email_exists', __( 'An account is already registered with your email address. Please log in.', 'awebooking-user-profile' ), $email ) );
		}

		// Handle username creation.
		if ( empty( $username ) ) {
			$username = sanitize_user( current( explode( '@', $email ) ), true );

			// Ensure username is unique.
			$append     = 1;
			$o_username = $username;

			while ( username_exists( $username ) ) {
				$username = $o_username . $append;
				$append++;
			}
		}

		if ( empty( $password ) ) {
			// Handle password creation.
			$password           = wp_generate_password();
			$password_generated = true;
		}

		if ( empty( $password ) ) {
			return new \WP_Error( 'registration-error-missing-password', __( 'Please enter an account password.', 'awebooking-user-profile' ) );
		}

		// Use WP_Error to handle registration errors.
		$errors = new \WP_Error();

		do_action( 'awebooking_register_post', $username, $email, $errors );

		$errors = apply_filters( 'awebooking_registration_errors', $errors, $username, $email );

		if ( $errors->get_error_code() ) {
			return $errors;
		}

		$new_customer_data = apply_filters(
			'awebooking_new_customer_data', array(
				'user_login' => $username,
				'user_pass'  => $password,
				'user_email' => $email,
				'role'       => 'awebooking_customer',
			)
		);

		$customer_id = wp_insert_user( $new_customer_data );

		if ( is_wp_error( $customer_id ) ) {
			return new \WP_Error( 'registration-error', __( 'Couldn&#8217;t register you&hellip; please contact us if you continue to have problems.', 'awebooking-user-profile' ) );
		}

		/**
		 * Hooked: $this->send_created_account_mails();
		 */
		do_action( 'awebooking_created_customer', $customer_id, $new_customer_data, $password_generated );

		return $customer_id;
	}

	/**
	 * Send created account emails.
	 *
	 * @param $customer_id
	 * @param $new_customer_data
	 */
	public function send_created_account_mails( $customer_id, $new_customer_data ) {
		// User email.
		abrs_mailer( 'create_account' )->build( $customer_id, $new_customer_data )->send();

		// Admin email.
		wp_new_user_notification( $customer_id );
	}

	public function save_booking_info() {
		if ( 'POST' !== strtoupper( $_SERVER['REQUEST_METHOD'] ) ) {
			return;
		}

		if ( empty( $_POST['action'] ) || 'edit-booking' !== $_POST['action'] || empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'],
				'awebooking_user_edit_booking' ) ) {
			return;
		}


		$errors = new \WP_Error();
		$user   = new \stdClass();

		$user_id = (int) get_current_user_id();

		if ( $user_id <= 0 ) {
			return;
		}

		//Basic field
		$first_name = ! empty( $_POST['customer_first_name'] ) ? sanitize_text_field( $_POST['customer_first_name'] ) : '';
		$last_name  = ! empty( $_POST['customer_last_name'] ) ? sanitize_text_field( $_POST['customer_last_name'] ) : '';
		$email      = ! empty( $_POST['customer_email'] ) ? sanitize_email( $_POST['customer_email'] ) : '';
		$phone      = ! empty( $_POST['customer_phone'] ) ? sanitize_text_field( $_POST['customer_phone'] ) : '';
		$company    = ! empty( $_POST['customer_company'] ) ? sanitize_text_field( $_POST['customer_company'] ) : '';

		// Handle required fields
		$required_fields = apply_filters( 'awebooking/user/edit_booking_required_fields', [
			'customer_first_name' => __( 'First Name', 'awebooking-user-profile' ),
			'customer_last_name'  => __( 'Last Name', 'awebooking-user-profile' ),
			'customer_email'      => __( 'Email address', 'awebooking-user-profile' ),
			'customer_phone'      => __( 'Phone number', 'awebooking-user-profile' ),
		] );

		foreach ( $required_fields as $field_key => $field_name ) {
			$value = sanitize_text_field( $_POST[ $field_key ] );
			if ( empty( $value ) ) {
				awebooking_user_add_alert( '<strong>' . esc_html( $field_name ) . '</strong> ' . __( 'is a required field.', 'awebooking-user-profile' ), 'error' );
			}
		}

		if ( $email && ! is_email( $email ) ) {
			awebooking_user_add_alert( __( 'Please provide a valid email address.', 'awebooking-user-profile' ), 'error' );
		}

		if ( awebooking_user_alert_count() === 0 ) {

			update_user_meta( $user_id, 'customer_first_name', $first_name );
			update_user_meta( $user_id, 'customer_last_name', $last_name );
			update_user_meta( $user_id, 'customer_phone', $phone );
			update_user_meta( $user_id, 'customer_company', $company );
			update_user_meta( $user_id, 'customer_email', $email );

			do_action( 'awebooking\user\save_edit_booking', $user_id );

			wp_safe_redirect( add_query_arg(
				[ 'action' => 'updated' ], awebooking_user_get_account_endpoint_url( 'edit-booking' ) ) );
			exit();
		}
	}

	/**
	 * Handle cancel booking.
	 */
	public function cancel_booking() {
		$booking_id = get_query_var( 'view-booking' );

		if ( ! is_awebooking_user_page() || ! $booking_id || empty( $_GET['cancel'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( $_GET['cancel'], 'awebooking_user_booking_cancel' ) ) {
			return;
		}

		$booking = new Booking( $booking_id );

		if ( ! in_array( $booking->get_status(), abrs_get_cancellable_status() ) ) {
			return;
		}

		try {
			$booking->update_status( 'cancelled' );
			wp_safe_redirect( apply_filters( 'awebooking_user_registration_redirect', wp_get_referer() ? wp_get_referer() : awebooking_user_get_page_permalink( 'orders' ) ) );
			exit;
		} catch ( \Exception $e ) {
			// ...
		}
	}

	/**
	 * Fill checkout form data when user logged in.
	 *
	 * @param \AweBooking\Checkout\Form_Controls $form_controls Form controls.
	 */
	public function fill_checkout_form_data( $form_controls ) {
		if ( abrs_http_request()->old() || ! is_user_logged_in() ) {
			return $form_controls;
		}

		$model = $form_controls->object_id;

		if ( $model instanceof Fluent ) {
			$user_id = get_current_user_id();

			$data = abrs_get_default_user_meta_data( $user_id );

			foreach ( $data as $item => $value ) {
				$model[$item] = $value;
			}
		}

		return $form_controls;
	}
}
