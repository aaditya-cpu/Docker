<?php

namespace AweBooking\User_Profile;

use AweBooking\Checkout\Form_Controls;
use AweBooking\Support\Fluent;
use CMB2_hookup;

class Admin_Profile {

	/**
	 * Hook in tabs.
	 */
	public function __construct() {
		add_action( 'show_user_profile', [ $this, 'add_customer_meta_fields' ] );
		add_action( 'edit_user_profile', [ $this, 'add_customer_meta_fields' ] );

		add_action( 'personal_options_update', [ $this, 'save_customer_meta_fields' ] );
		add_action( 'edit_user_profile_update', [ $this, 'save_customer_meta_fields' ] );
	}

	/**
	 * Show Address Fields on edit user pages.
	 *
	 * @param \WP_User $user User.
	 */
	public function add_customer_meta_fields( $user ) {
		if ( ! current_user_can( 'manage_awebooking' ) ) {
			return;
		}

		$user_data = $this->get_user_object( $user );

		CMB2_hookup::enqueue_cmb_js();
		CMB2_hookup::enqueue_cmb_css();

		$controls = new Form_Controls( $user_data );
		$controls->prepare_fields();

		$customer_controls = $controls->get_section( 'customer' );

		if ( empty( $customer_controls->fields ) ) {
			return;
		}
		?>
		<h2><?php esc_html_e( 'Customer Address', 'awebooking-user-profile' ); ?></h2>
		<div class="postbox-container">
			<div class="cmb2-wrap">
				<div class="cmb2-metabox cmb-field-list">
					<?php
					foreach ( $customer_controls->fields as $field_args ) {
						$controls->show_field( $field_args );
					}
					?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Save Address Fields on edit user pages.
	 *
	 * @param int $user_id User ID of the user being saved.
	 */
	public function save_customer_meta_fields( $user_id ) {
		$controls = new Form_Controls;
		$controls->prepare_fields();

		$customer_controls = $controls->get_section( 'customer' );

		if ( empty( $customer_controls->fields ) ) {
			return;
		}

		$save_fields = $customer_controls->fields;

		foreach ( $save_fields as $key => $fieldset ) {
			if ( isset( $_POST[ $key ] ) ) {
				update_user_meta( $user_id, $key, $_POST[ $key ] );
			}
		}
	}

	/**
	 * Gets user object.
	 *
	 * @param \WP_User $user User.
	 *
	 * @return \AweBooking\Support\Fluent
	 */
	protected function get_user_object( $user ) {
		return new Fluent( abrs_get_default_user_meta_data( $user->ID ) );
	}
}
