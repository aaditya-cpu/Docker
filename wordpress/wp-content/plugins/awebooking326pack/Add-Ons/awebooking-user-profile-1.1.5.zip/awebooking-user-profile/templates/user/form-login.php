<?php
/**
 * Login form
 * 
 * @author 		Awethemes <awethemes.com>
 * @package 	AweBooking\User
 * @since 1.0
 */
if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

<?php do_action( 'awebooking\user\before_user_login_form' ); ?>

<?php awebooking_user_print_alerts(); ?>

<?php if ( get_option( 'users_can_register' ) ) : ?>
	<div class="row">
		<div class="col-md-6 col-xs-12">

		<?php endif; ?>
		<div id="member_login">
			<h2><?php echo esc_html__( 'Login', 'awebooking-user-profile' ); ?></h2>

			<form method="post" class="login">

				<?php do_action( 'awebooking\user\login_form_start' ); ?>

				<p class="form-row form-row-wide">
					<label for="username"><?php echo esc_html__( 'Username or email address', 'awebooking-user-profile' ); ?> <span class="required">*</span></label>
					<input type="text" class="input-text" name="username" id="username" value="<?php if ( !empty( $_POST['username'] ) ) echo esc_attr( $_POST['username'] ); ?>" />
				</p>
				<p class="form-row form-row-wide">
					<label for="password"><?php echo esc_html__( 'Password', 'awebooking-user-profile' ); ?> <span class="required">*</span></label>
					<input class="input-text" type="password" name="password" id="password" />
				</p>

				<?php do_action( 'awebooking\user\login_form' ); ?>

				<p class="form-row">
					<?php wp_nonce_field( 'awebooking_user-login', 'awebooking_user-login-nonce' ); ?>
					<input type="submit" class="awebooking_user-button button" name="login" value="<?php esc_attr_e( 'Login', 'awebooking-user-profile' ); ?>" />
					<label for="rememberme" class="inline">
						<input class="awebooking_user-input--checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <?php echo esc_html__( 'Remember me', 'awebooking-user-profile' ); ?>
					</label>
				</p>

				<p class="lost_password">
					<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php echo esc_html__( 'Lost your password?', 'awebooking-user-profile' ); ?></a>
				</p>

				<input type="hidden" name="redirect" value="<?php echo isset( $_REQUEST['referer'] ) ? abrs_get_page_permalink( $_REQUEST['referer'] ) : ''; ?>">

				<?php do_action( 'awebooking\user\login_form_end' ); ?>

			</form>
		</div>

		<?php if ( get_option( 'users_can_register' ) ) : ?>

		</div>

		<div class="col-md-6 col-xs-12">
			<div id="member_register">

				<h2><?php echo esc_html__( 'Register', 'awebooking-user-profile' ); ?></h2>

				<form method="post" class="register">

					<?php do_action( 'awebooking\user\register_form_start' ); ?>

					<p class="form-row form-row-wide">
						<label for="reg_email"><?php echo esc_html__( 'Email address', 'awebooking-user-profile' ); ?> <span class="required">*</span></label>
						<input type="email" data-create_user="#reg_username" class="input-text js-validate_email" name="email" id="reg_email" value="<?php if ( !empty( $_POST['email'] ) ) echo esc_attr( $_POST['email'] ); ?>" />
					</p>

					<p class="form-row form-row-wide">
						<label for="reg_username"><?php echo esc_html__( 'Username', 'awebooking-user-profile' ); ?> <span class="required">*</span></label>
						<input type="text" class="input-text js-validate_username" name="username" id="reg_username" value="<?php if ( !empty( $_POST['username'] ) ) echo esc_attr( $_POST['username'] ); ?>" />
					</p>

					<p class="form-row form-row-wide">
						<label for="reg_password"><?php echo esc_html__( 'Password', 'awebooking-user-profile' ); ?> <span class="required">*</span></label>
						<input type="password" class="input-text js-password_meter" name="password" id="reg_password" />
					</p>

					<p class="form-row form-row-wide">
						<label for="confirm_password"><?php echo esc_html__( 'Confirm Password', 'awebooking-user-profile' ); ?> <span class="required">*</span></label>
						<input type="password" class="input-text js-confirm_pwd" data-confirm="#reg_password" name="confirm_password" id="confirm_password" />
					</p>

					<!-- Spam Trap -->
					<div style="<?php echo ( ( is_rtl() ) ? 'right' : 'left' ); ?>: -999em; position: absolute;"><label for="trap"><?php echo esc_html__( 'Anti-spam', 'awebooking-user-profile' ); ?></label><input type="text" name="email_2" id="trap" tabindex="-1" /></div>

					<?php do_action( 'awebooking\user\register_form' ); ?>

					<?php do_action( 'register_form' ); ?>

					<p class="form-row">
						<?php wp_nonce_field( 'awebooking_user-register', 'awebooking_user-register-nonce' ); ?>
						<input type="submit" class="awebooking_user-button button" name="register" value="<?php esc_attr_e( 'Register', 'awebooking-user-profile' ); ?>" />
					</p>

					<?php do_action( 'awebooking\user\register_form_end' ); ?>

				</form>
			</div>
		</div>
	</div>
<?php endif; 


do_action( 'awebooking\user\after_login_form' );
