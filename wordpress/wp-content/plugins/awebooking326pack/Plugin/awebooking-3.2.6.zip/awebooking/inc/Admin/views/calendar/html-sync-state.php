<?php
/* @vars $calr, $event, $calendar, $scheduler, $attributes */

?>
<div <?php echo abrs_html_attributes( $attributes ); // WPCS: XSS OK. ?>>
	<span class="scheduler-inline-text"></span>
</div>
