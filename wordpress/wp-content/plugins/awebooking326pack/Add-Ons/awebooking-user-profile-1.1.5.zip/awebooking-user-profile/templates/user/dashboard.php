<?php
/**
 * Account dashboard - Default Account Page
 *
 * @author        Awethemes <awethemes.com>
 * @package       AweBooking\User
 * @since         1.1.3
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


?>

<p class="dashboard-heading">
	<?php
	printf( esc_html__( 'Hello %s%s%s (not %2$s? %sSign out%s)', 'awebooking-user-profile' ),
		'<strong>',
		esc_html( $current_user->display_name ),
		'</strong>',
		'<a href="' . esc_url( awebooking_user_get_account_endpoint_url( 'user-logout' ) ) . '">', '</a>' );
	?>
</p>

<p class="dashboard-content">
	<?php printf( __( 'You can create <a href="%1$s">a new booking</a> or review your <a href="%2$s">bookings</a>.', 'awebooking-user-profile' ),
		esc_url( abrs_get_page_permalink( 'search' ) ),
		esc_url( awebooking_user_get_account_endpoint_url( 'orders' ) )
	); ?>
</p>
