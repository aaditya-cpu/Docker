<?php
namespace AweBooking\Payment\Gateways\Unofficial;

use Awethemes\Http\Request;
use AweBooking\Model\Booking;
use AweBooking\Payment\Gateways\Omnipay_Gateway;

class PayU_India_Gateway extends Omnipay_Gateway {
	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->method       = 'payu_india';
		$this->supports     = [ 'transaction_id' ];
		$this->method_title = esc_html__( 'PayU (India)', 'awebooking-payment' );

		// $message = abrs_esc_text( 'If you do not already have PayU merchant account, please register in <a href="https://secure.payu.com/boarding/#/form" target="_blank">Production</a> or <a href="https://secure.snd.payu.com/boarding/#/form" target="_blank">Sandbox</a>.', 'awebooking-payment' );
		$this->method_description = esc_html__( 'PayU (India) payment gateway.', 'awebooking-payment' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function setup() {
		$this->setting_fields();

		$this->enabled     = $this->get_option( 'enabled' );
		$this->title       = esc_html( $this->get_option( 'title' ) );
		$this->description = esc_textarea( $this->get_option( 'description' ) );

		$keys = [ $this->get_option( 'api_key' ), $this->get_option( 'salt' ) ];

		// @see https://developer.payumoney.com/general/
		// @see https://documentation.payubiz.in/hosted-page-copy/
		if ( $this->sandbox() ) {
			$keys = 'biz' === $this->get_option( 'service_provider' )
				? [ 'gtKFFx', 'eCwWELxi' ]
				: [ 'rjQUPktU', 'e5iIg1jwi8' ];
		}

		$this->gateway = $this->create_gateway( 'PayUBiz', [
			'key'       => $keys[0],
			'salt'      => $keys[1],
			'payuPaisa' => 'money' === $this->get_option( 'service_provider' ),
			'testMode'  => $this->sandbox(),
		]);
	}

	/**
	 * Set the gateway settings fields.
	 *
	 * @return void
	 */
	protected function setting_fields() {
		$this->setting_fields = [
			'enabled' => [
				'name'    => esc_html__( 'Enable / Disable', 'awebooking-payment' ),
				'type'    => 'toggle',
				'label'   => esc_html__( 'Enable check payments', 'awebooking-payment' ),
				'default' => 'off',
			],
			'title' => [
				'name'        => esc_html__( 'Title', 'awebooking-payment' ),
				'type'        => 'text',
				'description' => esc_html__( 'This controls the title which the user sees during checkout.', 'awebooking-payment' ),
				'default'     => _x( 'PayU (India)', 'PayU payment method', 'awebooking-payment' ),
			],
			'description' => [
				'name'        => esc_html__( 'Description', 'awebooking-payment' ),
				'type'        => 'textarea',
				'description' => esc_html__( 'Payment method description that the customer will see on your checkout.', 'awebooking-payment' ),
				'default'     => esc_html__( 'PayU is a leading payment services provider with presence in 16 growth markets across the world', 'awebooking-payment' ),
			],
			'service_provider' => [
				'name'    => esc_html__( 'Service Provider', 'awebooking-payment' ),
				'type'    => 'select',
				'default' => 'biz',
				'options' => [
					'biz'   => 'PayUbiz',
					'money' => 'PayUmoney',
				],
			],
			'sandbox' => [
				'type'    => 'toggle',
				'name'    => esc_html__( 'Sandbox?', 'awebooking-payment' ),
				'default' => 'off',
				'after' => function() {
					if ( ! $this->sandbox() ) {
						return;
					}

					?><div class="abrs-note abrs-mt1">
						<h4>Test Mode is <strong>ACTIVE</strong>, use following <u>Credit Card:</u></h4>
						<ul>
							<li>Name: <strong><em>any name</em></strong></li>
							<li>Number: <strong>5123 4567 8901 234<u>6</u></strong> <small><em>(last is 6 not <s>5</s>)</em></small></li>
							<li>CVV: <strong>123</strong></li>
							<li>Expiry: <strong>12/<?php echo esc_html( date( 'y', strtotime( '+1 year' ) ) ); ?></strong></li>
						</ul>
					</div><?php // @codingStandardsIgnoreLine
				},
			],
			'api_key' => [
				'type'       => 'text',
				'name'       => esc_html__( 'Key', 'awebooking-payment' ),
				'show_on_cb' => function () {
					return ! $this->sandbox();
				},
			],
			'salt' => [
				'type'       => 'text',
				'name'       => esc_html__( 'Salt', 'awebooking-payment' ),
				'show_on_cb' => function () {
					return ! $this->sandbox();
				},
			],
		];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_purchase_parameters( Booking $booking, Request $request ) {
		return [
			'email'         => $booking->get('customer_email'),
			'name'          => $booking->get_customer_fullname(),
			'description'   => 'reservation',
			'transactionId' => uniqid($booking->get_booking_number() . '_', true),
		];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_complete_purchase_parameters( Booking $booking ) {
		return [];
	}
}
