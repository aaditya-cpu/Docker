import $ from 'jquery'
import QueryBuilder from './builder'

$(function () {
  $('[data-init="awebooking-rules"]').each(function (index, element) {
    $(element).data('query-builder', new QueryBuilder(element))
  })

  // Support saving in edit-post.php
  const $post = $('#post');

  if ($post.length > 0) {
    $post.on('submit', function (e) {
      let isValid = false
      QueryBuilder.instances.forEach(e => isValid = e.validate())

      if (!isValid) {
        e.preventDefault()
      }

      QueryBuilder.instances.forEach(e => isValid = e.updateInputRules())
    });
  }

})
