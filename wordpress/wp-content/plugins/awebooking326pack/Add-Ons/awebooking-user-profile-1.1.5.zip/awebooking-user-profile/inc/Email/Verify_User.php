<?php
namespace AweBooking\User_Profile\Email;

use AweBooking\Email\Mailable;

class Verify_User extends Mailable {
	/**
	 * The data.
	 *
	 * @var array
	 */
	protected $data;

	/**
	 * {@inheritdoc}
	 */
	public function setup() {
		$this->id             = 'verify_user';
		$this->title          = esc_html__( 'Verify user', 'awebooking-user-profile' );
		$this->description    = esc_html__( 'Verify user emails are sent to user when their registed.', 'awebooking-user-profile' );
		$this->customer_email = true;
		$this->placeholders   = [];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function prepare_data( $data ) {
		$this->data      = $data;
		$this->recipient = $data['user_email'];
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_default_subject() {
		return esc_html__( 'Verify your accountt on {site_title}', 'awebooking-user-profile' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_content_html() {
		return awebooking_user_get_template( 'user/emails/user-verify-account.php', array_merge( $this->data, [
			'email' => $this,
		] ) );
	}
}
