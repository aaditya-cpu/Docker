<?php

/**
 * Get the count of alerts added, either for all alerts (default) or for one.
 * particular alert type specified by $alert_type.
 *
 * @since 1.0
 *
 * @param string $alert_type The name of the alert type - either error, success or alert. [optional]
 *
 * @return int
 */
function awebooking_user_alert_count( $alert_type = '' ) {
	$messages = abrs_flash()->all();

	return ! $alert_type
		? $messages->count()
		: $messages->where( 'level', $alert_type )->count();
}

/**
 * Check if a alert has already been added.
 *
 * @since 1.0
 *
 * @param string $message    The text to display in the alert.
 * @param string $alert_type The singular name of the alert type - either error, success or alert. [optional]
 *
 * @return bool
 */
function awebooking_user_has_alert( $message, $alert_type = 'success' ) {
	if ( ! awebooking_user_alert_count( $alert_type ) ) {
		return false;
	}

	$alerts = abrs_flash()
		->all()
		->where( 'level', $alert_type )
		->where( 'message', $message );

	return $alerts->count() > 0;
}

/**
 * Add and store a alert.
 *
 * @since 1.0
 *
 * @param string $message    The text to display in the alert.
 * @param string $alert_type The singular name of the alert type - either error, success or alert. [optional]
 */
function awebooking_user_add_alert( $message, $alert_type = 'success' ) {
	abrs_add_notice( $message, $alert_type );
}

/**
 * Prints messages and errors which are stored in the session, then clears them.
 *
 * @since 1.0
 */
function awebooking_user_print_alerts() {
	abrs_print_notices();
}

/**
 * Print a single alert immediately.
 *
 * @since 1.0
 *
 * @param string $message    The text to display in the alert.
 * @param string $alert_type The singular name of the alert type - either error, success or alert. [optional]
 */
function awebooking_user_print_alert( $message, $alert_type = 'success' ) {
	if ( 'success' === $alert_type ) {
		$message = apply_filters( 'awebooking\user\add_message', $message );
	}

	abrs_get_template( "user/alerts/{$alert_type}.php", [
		'messages' => [ apply_filters( 'awebooking_user_add_' . $alert_type, $message ) ],
	] );
}

/**
 * Returns all queued alerts, optionally filtered by a alert type.
 *
 * @since 1.0
 *
 * @param string $alert_type The singular name of the alert type - either error, success or alert.
 *
 * @return array
 */
function awebooking_user_get_alerts( $alert_type = '' ) {
	return abrs_flash()
		->all()
		->where( 'level', $alert_type )
		->all();
}

/**
 * Add alerts for WP Errors.
 *
 * @param  WP_Error $errors
 */
function awebooking_user_add_wp_error_alerts( $errors ) {
	if ( is_wp_error( $errors ) && $errors->get_error_messages() ) {
		foreach ( $errors->get_error_messages() as $error ) {
			awebooking_user_add_alert( $error, 'error' );
		}
	}
}
