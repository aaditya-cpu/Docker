<?php
/**
 * Plugin Name:     AweBooking Simple Reservation
 * Plugin URI:      http://awethemes.com/plugins/awebooking
 * Description:     Customers just simply send contact and booking request email to admin to get support without any hassle of multiple booking steps.
 * Author:          awethemes
 * Author URI:      http://awethemes.com
 * Text Domain:     awebooking-simple-reservation
 * Domain Path:     /languages
 * Version:         1.0.0
 *
 * @package         AweBooking/Simple_Reservation
 */

add_action( 'awebooking_init', function ( $awebooking ) {
	require_once trailingslashit( __DIR__ ) . 'vendor/autoload.php';

	$awebooking->provider( \AweBooking\Simple_Reservation\Service_Provider::class );
});
