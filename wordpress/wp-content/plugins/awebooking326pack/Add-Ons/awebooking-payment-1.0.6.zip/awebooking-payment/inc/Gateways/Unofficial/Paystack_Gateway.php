<?php
namespace AweBooking\Payment\Gateways\Unofficial;

use Awethemes\Http\Request;
use AweBooking\Model\Booking;
use AweBooking\Payment\Gateways\Omnipay_Gateway;

class Paystack_Gateway extends Omnipay_Gateway {
	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->method             = 'paystack';
		$this->supports           = [ 'transaction_id' ];
		$this->method_title       = esc_html__( 'Paystack', 'awebooking-payment' );
		$this->method_description = esc_html__( 'Modern online and offline payments for Africa.', 'awebooking-payment' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function setup() {
		$this->setting_fields();

		$this->enabled     = $this->get_option( 'enabled' );
		$this->title       = esc_html( $this->get_option( 'title' ) );
		$this->description = esc_textarea( $this->get_option( 'description' ) );

		$this->gateway = $this->create_gateway( 'Paystack', [
			'secretKey' => $this->get_option( 'secret_key' ),
			'publicKey' => $this->get_option( 'public_key' ),
			'testMode'  => $this->sandbox(),
		] );
	}

	/**
	 * Set the gateway settings fields.
	 *
	 * @return void
	 */
	protected function setting_fields() {
		$this->setting_fields = [
			'enabled' => [
				'name'    => esc_html__( 'Enable / Disable', 'awebooking-payment' ),
				'type'    => 'toggle',
				'label'   => esc_html__( 'Enable check payments', 'awebooking-payment' ),
				'default' => 'off',
			],
			'title' => [
				'name'        => esc_html__( 'Title', 'awebooking-payment' ),
				'type'        => 'text',
				'description' => esc_html__( 'This controls the title which the user sees during checkout.', 'awebooking-payment' ),
				'default'     => _x( 'Paystack', 'Paystack payment method', 'awebooking-payment' ),
			],
			'description' => [
				'name'        => esc_html__( 'Description', 'awebooking-payment' ),
				'type'        => 'textarea',
				'description' => esc_html__( 'Payment method description that the customer will see on your checkout.', 'awebooking-payment' ),
			],
			'sandbox' => [
				'type'    => 'toggle',
				'name'    => esc_html__( 'Sandbox', 'awebooking-payment' ),
				'default' => 'off',
			],
			'secret_key' => [
				'type' => 'text',
				'name' => esc_html__( 'Secret Key', 'awebooking-payment' ),
			],
			'public_key' => [
				'type' => 'text',
				'name' => esc_html__( 'Public Key', 'awebooking-payment' ),
			],
		];
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_purchase_parameters( Booking $booking, Request $request ) {
		return [
			'email' => $booking->get( 'customer_email' ),
		];
	}
}
