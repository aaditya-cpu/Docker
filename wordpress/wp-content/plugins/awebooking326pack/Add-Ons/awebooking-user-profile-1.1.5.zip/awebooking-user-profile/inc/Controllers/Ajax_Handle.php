<?php
namespace AweBooking\User_Profile\Controllers;

use AweBooking\Booking\Booking;

class Ajax_Handle {
	/**
	 * Hook in ajax handlers.
	 *
	 * @return void
	 */
	public static function init() {
		self::add_ajax_events( [
			'edit_customer_note' => false,
		] );
	}

	/**
	 * Hook in methods - uses WordPress ajax handlers (admin-ajax).
	 *
	 * @param array $ajax_events
	 *
	 * @return void
	 */
	public static function add_ajax_events( $ajax_events ) {
		foreach ( $ajax_events as $ajax_event => $nopriv ) {
			add_action( 'wp_ajax_awebooking_user_' . $ajax_event, [ __CLASS__, $ajax_event ] );

			if ( $nopriv ) {
				add_action( 'wp_ajax_nopriv_awebooking_user_' . $ajax_event, [ __CLASS__, $ajax_event ] );
			}
		}
	}

	public function edit_customer_note() {
		if ( empty( $_POST['nonce'] ) || empty( $_POST['id_booking'] ) ) {
			return;
		}

		if ( ! check_ajax_referer( 'awebooking_user_edit_customer_note', 'nonce' ) ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			return;
		}

		$booking = new Booking( sanitize_key( $_POST['id_booking'] ) );
		if ( ! $booking->exists() ) {
			wp_send_json_error();
		}

		if ( $booking->is_editable() ) {
			$note = isset( $_POST['customer_note'] ) ? sanitize_textarea_field( $_POST['customer_note'] ) : '';

			$booking['customer_note'] = $note;
			$booking->save();

			wp_send_json_success( $note );
		}

		wp_send_json_error();
	}
}
